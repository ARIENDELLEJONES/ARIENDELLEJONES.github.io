---
title: "question, does it have a backend? if no backend save this one locally"
created: 2026-03-10T01:49:06.430Z
updated: 2026-03-10T02:10:50.962Z
source: "Blackbox AI"
model: "minimax-m2-minimax-m2"
---

# question, does it have a backend? if no backend save this one locally

**Created**: 3/10/2026, 9:49:06 AM
**Messages**: 62 (User: 31, Assistant: 31)
**Session ID**: `1773107346407`
**Model**: minimax-m2-minimax-m2


---

## 💬 User #1

_2026-03-12 06:37:03Z_

<task>
question, does it have a backend? if no backend save this one locally
</task>

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

# Current Working Directory (c:/Users/ACER/Desktop/EDC,LTD) Files
admin.html
index.html
navbar.html
package-lock.json
package.json
README.md
server.js
TODO.md
css/
css/admin.css
css/style.css
data/
data/site-config.json
images/
images/favicon.svg
images/intro.jpg
images/logo.svg
images/gallery/
js/
js/admin-editor.js
js/animations.js
js/github-publisher.js
js/load-site.js
js/navbar-loader.js
js/popup.js

## 🤖 Assistant #2

_2026-03-12 06:37:03Z_

💭 思考过程：
The user wants to know if this project has a backend, and if not, save "this one" locally. Let me analyze the task:

1. First, I need to understand what "this one" refers to - it seems to be a website/project
2. I need to check if there's a backend by examining the files

Looking at the file structure:
- `server.js` - this could be a backend server file
- `package.json` - could have backend dependencies
- The other files seem to be frontend (HTML, CSS, JS)

Let me read the key files to understand:
1. `server.js` - to see if it's a backend
2. `package.json` - to see dependencies

This is a small project (less than 10 files visible in environment_details), so I don't need to use search_files.

Let me read the relevant files to determine if there's a backend.

I'll analyze the project to determine if it has a backend. Let me examine the key files.


🔧 工具调用: read_file

🔧 工具调用: read_file

## 💬 User #3

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #4

_2026-03-12 06:37:03Z_

💭 思考过程：
Based on my analysis, I can see that this project DOES have a backend:

1. **server.js** - A full Express.js backend server with:
   - API routes for config management (`/api/config`, `/api/save-config`)
   - Image upload endpoints (`/api/upload-image`, `/api/upload-gallery`, `/api/upload-team`, etc.)
   - File management endpoints (`/api/file/:filename`, `/api/save-file`)
   - Image listing and deletion endpoints
   - Serves both `index.html` and `admin.html`

2. **package.json** - Shows Node.js dependencies:
   - express
   - cors
   - body-parser
   - multer

So the answer to the user's question "does it have a backend?" is **YES**.

Since it already has a backend, there's no need to save anything locally - the application is complete with a working Node.js/Express backend server.

Based on my analysis, **YES, this project does have a backend**.

The project includes:
- **server.js** - A complete Express.js backend server with API routes for:
  - Configuration management (`/api/config`, `/api/save-config`)
  - Image uploads (gallery, team, hero, intro, popup images)
  - File management and serving
  - Admin panel serving

- **package.json** - Node.js dependencies:
  - express
  - cors
  - body-parser
  - multer

The backend is fully functional. To run it, you would need to:
1. Install dependencies: `npm install`
2. Start the server: `npm start`

This would start the server at `http://localhost:3000` with:
- Public website at `/index.html`
- Admin panel at `/admin.html`

Since the project already has a working backend, there's no need to save anything locally - it's already complete.


🔧 工具调用: attempt_completion

## 💬 User #5

_2026-03-12 06:37:03Z_

[attempt_completion] Result:

The user has provided feedback on the results. Consider their input to continue the task, and then attempt completion again.
<feedback>
can you do it?
</feedback>

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #6

_2026-03-12 06:37:03Z_

💭 思考过程：
The user is asking "can you do it?" - they want me to run the project. Let me install the dependencies and start the server.

I'll install the dependencies and start the backend server for you.


🔧 工具调用: execute_command

## 💬 User #7

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #8

_2026-03-12 06:37:03Z_

💭 思考过程：
The command failed due to PowerShell syntax issues. Let me try running the commands separately or use a different approach.

🔧 工具调用: execute_command

## 💬 User #9

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #10

_2026-03-12 06:37:03Z_

💭 思考过程：
Dependencies are installed. Now I need to start the server. I'll run npm start to start the backend server.

Dependencies are already installed. Now I'll start the backend server:


🔧 工具调用: execute_command

## 💬 User #11

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #12

_2026-03-12 06:37:03Z_

💭 思考过程：
The port 3000 is already in use, which means the server is already running! The backend is already active. This confirms that the backend is already running and serving the website.

The backend is **already running**! Port 3000 is in use, which means the server is currently active and serving the website.


🔧 工具调用: attempt_completion

## 💬 User #13

_2026-03-12 06:37:03Z_

[attempt_completion] Result:

The user has provided feedback on the results. Consider their input to continue the task, and then attempt completion again.
<feedback>
Failed to load resource: the server responded with a status of 404 (Not Found)Understand this error
admin-editor.js:1350 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1350:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1350
onclick @ admin.html:1Understand this error
admin-editor.js:1353 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1353:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1353
onclick @ admin.html:1Understand this error
admin-editor.js:1356 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1356:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1356
onclick @ admin.html:1Understand this error
admin-editor.js:1368 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1368:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1368
onclick @ admin.html:1Understand this error
admin-editor.js:1359 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1359:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1359
onclick @ admin.html:1Understand this error
admin-editor.js:1362 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1362:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1362
onclick @ admin.html:1Understand this error
admin-editor.js:1365 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1365:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
switchContentTab @ admin-editor.js:1365
onclick @ admin.html:1Understand this error
admin-editor.js:1350 Uncaught TypeError: this.renderClientsEditor is not a function
    at Object.switchContentTab (admin-editor.js:1350:256)
    at HTMLButtonElement.onclick (admin.html:1:13)
</feedback>

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #14

_2026-03-12 06:37:03Z_

💭 思考过程：
The user is reporting JavaScript errors in the admin panel. The main error is:
`TypeError: this.renderClientsEditor is not a function`

This indicates that the `renderClientsEditor` method is missing from the AdminEditor class in `admin-editor.js`. Let me examine the file to understand the issue and fix it.

The error happens when clicking on the Clients tab in the admin panel - the method is being called but doesn't exist.

I see there are JavaScript errors in the admin panel - specifically `this.renderClientsEditor is not a function`. Let me examine and fix the issue in the admin-editor.js file:


🔧 工具调用: read_file

## 💬 User #15

_2026-03-12 06:37:03Z_

Messages truncated due to length. Find the summary of the truncated content (Open the relevant code files with read_file if you want to understand the contents.):

I'll analyze the task and examine the relevant files to understand how image uploads are currently handled.

## 🤖 Assistant #16

_2026-03-12 06:37:03Z_

💭 思考过程：
The user wants to make all images support all file types. I need to look at the server.js file to check the image upload configuration and update it to support more image types.

Let me examine the server.js file to see the current image upload configuration.

I'll update the server to support all image file types. Let me check the current configuration in server.js:


🔧 工具调用: search_files

## 💬 User #17

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js

## 🤖 Assistant #18

_2026-03-12 06:37:03Z_

💭 思考过程：
Now I need to update the server.js file to support all image types. I'll need to update the allowed file types in the multer configuration. Let me find the exact line and update it.

I'll update the server.js to support all image types:


🔧 工具调用: edit_file

## 💬 User #19

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
server.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #20

_2026-03-12 06:37:03Z_

💭 思考过程：
I also need to update the image listing API to support all image types. Let me update that as well.

Now let me also update the image listing API to support all image types:


🔧 工具调用: edit_file

## 💬 User #21

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
server.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #22

_2026-03-12 06:37:03Z_

💭 思考过程：
I've updated both the upload filter and the image listing to support all image types. Now I should also update the admin-editor.js to accept all image types in the file inputs. Let me do that.

Now let me also update the admin-editor.js to accept all image types in file inputs:


🔧 工具调用: edit_file

## 💬 User #23

_2026-03-12 06:37:03Z_

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #24

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<invoke name="search_files">
<parameter name="path">c:/Users/ACER/Desktop/EDC,LTD/js</parameter>
<parameter name="regex">accept="image/</parameter>
</invoke>
</minimax:tool_call>

## 💬 User #25

_2026-03-12 06:37:03Z_

[ERROR] You did not use a tool in your previous response! Please retry with a tool use.Do not repeat any of the previous successful tool calls with same parameters, unless it is absolutely necessary.
# Reminder: Instructions for Tool Use
Always adhere to the tool use format for all tool uses to ensure proper parsing and execution.
# Next Steps

If you have completed the user's task, use the attempt_completion tool. 
If you require additional information from the user, use the ask_followup_question tool. 
Otherwise, if you have not completed the task and do not need additional information, then proceed with the next step of the task. 
(This is an automated message, so do not respond to it conversationally.)

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #26

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<invoke name="search_files">
<parameter name="path">c:/Users/ACER/Desktop/EDC,LTD/js</parameter>
<parameter name="regex">accept="image/</parameter>
</invoke>
</minimax:tool_call>

## 💬 User #27

_2026-03-12 06:37:03Z_

[ERROR] You did not use a tool in your previous response! Please retry with a tool use.Do not repeat any of the previous successful tool calls with same parameters, unless it is absolutely necessary.
# Reminder: Instructions for Tool Use
Always adhere to the tool use format for all tool uses to ensure proper parsing and execution.
# Next Steps

If you have completed the user's task, use the attempt_completion tool. 
If you require additional information from the user, use the ask_followup_question tool. 
Otherwise, if you have not completed the task and do not need additional information, then proceed with the next step of the task. 
(This is an automated message, so do not respond to it conversationally.)


[ERROR CORRECTION MODE ACTIVATED]

You have made 2 consecutive mistakes. Let's pause and reassess:

1. **Review Recent Actions**: Look at your last 2 tool uses and identify what went wrong.
2. **Common Mistakes to Check**:
   - Are you using the correct tool for the task?
   - Did you read the file before editing it?
   - Are your file paths correct and relative to c:/Users/ACER/Desktop/EDC,LTD?
   - Are you following the proper tool format (XML tags)?
   - Did you wait for confirmation before proceeding?
   - Are you trying to edit a file that doesn't exist? (use create_file instead)
   - Did you use execute_command without command parameter?
   - Are you providing complete file content when using create_file?

3. **Corrective Actions**:
   - If editing files: First use read_file to get current content, then use the appropriate tool
   - If paths are wrong: Use list_files to verify the correct path
   - If tool format is wrong: Review the tool documentation and ensure proper usage.
   - If the task is complex: Break it down into smaller, manageable steps

4. **Alternative Approach**: Consider using a different tool or strategy:
   - Instead of edit_file, try create_file with complete content
   - Instead of complex edits, break into multiple smaller edits
   - Use search_files to find the right location before editing
   - Ask the user for clarification if the requirements are unclear

Please take a moment to analyze what went wrong and try a different approach. Focus on one small, correct step at a time.


Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #28

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<invoke name="search_files">
<parameter name="path">c:/Users/ACER/Desktop/EDC,LTD/js</parameter>
<parameter name="regex>accept="</parameter>
</invoke>
</minimax:tool_call>

## 💬 User #29

_2026-03-12 06:37:03Z_

[ERROR] You did not use a tool in your previous response! Please retry with a tool use.Do not repeat any of the previous successful tool calls with same parameters, unless it is absolutely necessary.
# Reminder: Instructions for Tool Use
Always adhere to the tool use format for all tool uses to ensure proper parsing and execution.
# Next Steps

If you have completed the user's task, use the attempt_completion tool. 
If you require additional information from the user, use the ask_followup_question tool. 
Otherwise, if you have not completed the task and do not need additional information, then proceed with the next step of the task. 
(This is an automated message, so do not respond to it conversationally.)

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #30

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<search_files>
<path>c:/Users/ACER/Desktop/EDC,LTD/js</path>
<regex>accept=</regex>
</search_files>

## 💬 User #31

_2026-03-12 06:37:03Z_

[search_files for 'accept='] Result:

Found 8 results.

js/admin-editor.js
│----
│<input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'team', ${index})">
│                                ${member.image ? `<img src="${member.image}" alt="${member.name}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
│                                <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
│----
│                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'gallery', ${index})">
│                            </div>
│                                <input type="text" value="${client.logo}" onchange="AdminEditor.updateConfig('clients.items[${index}].logo', this.value)">
│----
│                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'client', ${index})">
│                            </div>
│                    <h3>Hero Background</h3>
│----
│                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'hero')">
│                    <input type="text" value="${this.config.hero.backgroundImage}" placeholder="Or enter image URL">
│                    <h3>Introduction Image</h3>
│----
│                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'intro')">
│                    <input type="text" value="${this.config.introduction.image}" placeholder="Or enter image URL">
│                    <h3>Popup Image</h3>
│----
│                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'popup')">
│                    <input type="text" value="${this.config.popup.image}" placeholder="Or enter image URL">
│                            <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
│----
│                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'team', ${index})">
│                        </div>
│                            <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
│----
│                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'gallery', ${index})">
│                        </div>
│----

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #32

_2026-03-12 06:37:03Z_

The file inputs already use `accept="image/*"` which accepts all image types. The server-side fix I made should work. Let me restart the server to apply the changes:

<minimax:tool_call>
<execute_command>
<command>cd "c:/Users/ACER/Desktop/EDC,LTD" && taskkill /F /IM node.exe 2>nul & node server.js</parameter>
</invoke>
</minimax:tool_call>

## 💬 User #33

_2026-03-12 06:37:03Z_

[execute_command for 'cd "c:/Users/ACER/Desktop/EDC,LTD" && taskkill /F /IM node.exe 2>nul & node server.js</parameter>
</invoke>
</minimax:tool_call>'] Result:

Command executed.
Output:
At line:1 char:36
+ cd "c:/Users/ACER/Desktop/EDC,LTD" && taskkill /F /IM node.exe 2>nul  ...
+                                    ~~
The token '&&' is not a valid statement separator in this version.
At line:1 char:70
+ ... ers/ACER/Desktop/EDC,LTD" && taskkill /F /IM node.exe 2>nul & node se ...
+                                                                 ~
The ampersand (&) character is not allowed. The & operator is reserved for future use; wrap an ampersand in double quotation marks
("&") to pass it as part of a string.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : InvalidEndOfLine

< : The term '<' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the spelling of the
name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ </invoke>
+ ~
    + CategoryInfo          : ObjectNotFound: (<:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException

< : The term '<' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the spelling of the
name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ </minimax:tool_call>
+ ~
    + CategoryInfo          : ObjectNotFound: (<:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #34

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<execute_command>
<command>taskkill /F /IM node.exe</parameter>
</invoke>
</minimax:tool_call>

## 💬 User #35

_2026-03-12 06:37:03Z_

[execute_command for 'taskkill /F /IM node.exe</parameter>
</invoke>
</minimax:tool_call>'] Result:

Command executed.
Output:
ERROR: The process "node.exe</parameter>" not found.
< : The term '<' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the spelling of the
name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ </invoke>
+ ~
    + CategoryInfo          : ObjectNotFound: (<:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException

< : The term '<' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the spelling of the
name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ </minimax:tool_call>
+ ~
    + CategoryInfo          : ObjectNotFound: (<:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #36

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<execute_command>
<command>cd "c:/Users/ACER/Desktop/EDC,LTD" & node server.js</command>
</invoke>
</minimax:tool_call>

## 💬 User #37

_2026-03-12 06:37:03Z_

[execute_command for 'cd "c:/Users/ACER/Desktop/EDC,LTD" & node server.js'] Result:

Command executed.
Output:
At line:1 char:36
+ cd "c:/Users/ACER/Desktop/EDC,LTD" & node server.js
+                                    ~
The ampersand (&) character is not allowed. The & operator is reserved for future use; wrap an ampersand in double quotation marks  
("&") to pass it as part of a string.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : AmpersandNotAllowed

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #38

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<execute_command>
<command>cmd /c "cd /d c:\Users\ACER\Desktop\EDC,LTD && node server.js"</command>
</invoke>
</minimax:tool_call>

## 💬 User #39

_2026-03-12 06:37:03Z_

[execute_command for 'cmd /c "cd /d c:\Users\ACER\Desktop\EDC,LTD && node server.js"'] Result:

Command executed.
Output:
node:events:486
      throw er; // Unhandled 'error' event
      ^

Error: listen EADDRINUSE: address already in use :::3000
    at Server.setupListenHandle [as _listen2] (node:net:1940:16)
    at listenInCluster (node:net:1997:12)
    at Server.listen (node:net:2102:7)
    at app.listen (c:\Users\ACER\Desktop\EDC,LTD\node_modules\express\lib\application.js:635:24)
    at Object.<anonymous> (c:\Users\ACER\Desktop\EDC,LTD\server.js:594:5)
    at Module._compile (node:internal/modules/cjs/loader:1804:14)
    at Object..js (node:internal/modules/cjs/loader:1936:10)
    at Module.load (node:internal/modules/cjs/loader:1525:32)
    at Module._load (node:internal/modules/cjs/loader:1327:12)
    at TracingChannel.traceSync (node:diagnostics_channel:328:14)
Emitted 'error' event on Server instance at:
    at emitErrorNT (node:net:1976:8)
    at process.processTicksAndRejections (node:internal/process/task_queues:89:21) {
  code: 'EADDRINUSE',
  errno: -4091,
  syscall: 'listen',
  address: '::',
  port: 3000
}

Node.js v24.13.1

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #40

_2026-03-12 06:37:03Z_

The server is already running on port 3000. The changes I made to server.js will take effect after a restart. Let me also check the 404 error and the JavaScript function error:

<minimax:tool_call>
<search_files>
<path>c:/Users/ACER/Desktop/EDC,LTD</path>
<regex>renderClientsEditor</regex>
</search_files>

## 💬 User #41

_2026-03-12 06:37:03Z_

[search_files for 'renderClientsEditor'] Result:

Found 104 results.

js/admin-editor.js
│----
│    renderClientsEditor: function() {
│        const clients = this.config.clients;
│                case 'introduction':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'overview':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'services':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'team':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'gallery':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'contact':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'footer':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'clients':
│----
│- `renderFooterEditor()` - exists
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│----

.llm-chat-history/history/2026-03-07_05-57-08Z-in-the-content-edit-navigations-in-the-admin.html,.md
│----
│- `renderClientsEditor()` - exists
│
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
│<parameter name="path">c:/Users/ACER/Desktop/EDC,LTD/js</parameter>
│----

.llm-chat-history/history/2026-03-07_06-08-58Z-can-you-include-on-the-content-editor-on-how-will-.md
│----
│<parameter name="regex">renderClientsEditor</parameter>
│<parameter name="file_pattern">*.js</parameter>
│<parameter name="path>js</parameter>
│----
│<parameter name="regex>renderClientsEditor</parameter>
│<parameter name="file_pattern>*.js</parameter>
│     */
│----
│    renderClientsEditor: function() {
│        const clients = this.config.clients;
│                case 'introduction':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'overview':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'services':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'team':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'gallery':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'contact':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'footer':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│                case 'clients':
│----
│                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
│                    break;
│2. The Services editor already has layout controls (I can see `renderServicesEditor` function with layout settings)
│----
│3. The Clients editor does NOT have layout controls (I can see `renderClientsEditor` function without layout settings)
│4. The Gallery editor does NOT have layout controls (I can see `renderGalleryEditor` function without layout settings)
│💭 思考过程：
│----
│I keep getting this error. Let me try to search for the clients section in the admin-editor.js to find the right location to add layout controls, since I already have that file content. Looking at the admin-editor.js I read earlier, I can see the renderClientsEditor function starting around line 530. Let me add layout controls there directly.
│
│<regex>
│----
│renderClientsEditor
│</regex>
││----
│----
││    renderClientsEditor: function() {
││        const clients = this.config.clients;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
││                    break;
││----
│----
││                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + th

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #42

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<search_files>
<parameter name="path>c:/Users/ACER/Desktop/EDC,LTD/js</path>
<regex>switchContentTab</regex>
</search_files>

## 💬 User #43

_2026-03-12 06:37:03Z_

[search_files for 'switchContentTab'] Result:

The tool execution failed with the following error:
<error>
Missing value for required parameter 'path'. Please retry with complete response.

# Reminder: Instructions for Tool Use

Tool uses are formatted using XML-style tags. The tool name is enclosed in opening and closing tags, and each parameter is similarly enclosed within its own set of tags. Here's the structure:

<tool_name>
<parameter1_name>value1</parameter1_name>
<parameter2_name>value2</parameter2_name>
...
</tool_name>

For example:

<attempt_completion>
<result>
I have completed the task...
</result>
</attempt_completion>

Always adhere to this format for all tool uses to ensure proper parsing and execution.
</error> Try again the tool call with corrections.  Do not repeat any of the previous successful tool calls with same parameters, unless it is absolutely necessary

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #44

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<search_files>
<path>c:/Users/ACER/Desktop/EDC,LTD/js</path>
<regex>switchContentTab</regex>
</search_files>

## 💬 User #45

_2026-03-12 06:37:03Z_

[search_files for 'switchContentTab'] Result:

Found 9 results.

js/admin-editor.js
│----
│                <button class="tab-btn active" data-tab="introduction" onclick="AdminEditor.switchContentTab('introduction')">Introduction</button>
│----
│                <button class="tab-btn" data-tab="overview" onclick="AdminEditor.switchContentTab('overview')">Overview</button>
│----
│                <button class="tab-btn" data-tab="services" onclick="AdminEditor.switchContentTab('services')">Services</button>
│----
│                <button class="tab-btn" data-tab="team" onclick="AdminEditor.switchContentTab('team')">Team</button>
│----
│                <button class="tab-btn" data-tab="clients" onclick="AdminEditor.switchContentTab('clients')">Clients</button>
│----
│                <button class="tab-btn" data-tab="gallery" onclick="AdminEditor.switchContentTab('gallery')">Gallery</button>
│----
│                <button class="tab-btn" data-tab="contact" onclick="AdminEditor.switchContentTab('contact')">Contact</button>
│----
│                <button class="tab-btn" data-tab="footer" onclick="AdminEditor.switchContentTab('footer')">Footer</button>
│            </div>
│     */
│----
│    switchContentTab: function(tab) {
│        document.querySelectorAll('.tab-btn').forEach(btn => {
│----

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #46

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<search_files>
<path>c:/Users/ACER/Desktop/EDC,LTD/js</path>
<regex>switchContentTab.*function</regex>
</search_files>

## 💬 User #47

_2026-03-12 06:37:03Z_

[search_files for 'switchContentTab.*function'] Result:

Found 1 result.

js/admin-editor.js
│----
│    switchContentTab: function(tab) {
│        document.querySelectorAll('.tab-btn').forEach(btn => {
│----

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #48

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<read_file>
<path>c:/Users/ACER/Desktop/EDC,LTD/js/admin-editor.js</path>
</read_file>

## 💬 User #49

_2026-03-12 06:37:03Z_

[read_file for 'c:/Users/ACER/Desktop/EDC,LTD/js/admin-editor.js'] Result:

/**
 * ============================================
 * ADMIN EDITOR - Visual Content Editor
 * Allows editing all site configuration from admin panel
 * ============================================
 */

const AdminEditor = {
    config: null,
    currentSection: 'general',
    hasChanges: false,
    
    /**
     * Initialize the admin editor
     */
    init: async function() {
        const config = await this.loadConfig();
        if (!config) {
            this.showNotification('Error loading configuration. Please ensure the server is running!', 'error');
            return;
        }
        this.setupEventListeners();
        this.renderCurrentSection();
        this.setupAutoSave();
    },
    
    /**
     * Load configuration from server
     */
    loadConfig: async function() {
        try {
            // Use server API endpoint - works with both server and direct file access
            // when the server is running
            const response = await fetch('/api/config');
            if (!response.ok) {
                throw new Error('Failed to fetch config');
            }
            this.config = await response.json();
            return this.config;
        } catch (error) {
            console.error('Error loading config:', error);
            this.showNotification('Error loading configuration. Make sure the server is running!', 'error');
            return null;
        }
    },
    
    /**
     * Save configuration to server
     */
    saveConfig: async function(showMessage = true) {
        try {
            const response = await fetch('/api/save-config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.config)
            });
            
            if (!response.ok) {
                throw new Error('Failed to save configuration');
            }
            
            this.hasChanges = false;
            if (showMessage) {
                this.showNotification('Configuration saved successfully!', 'success');
            }
            
            // Update last updated timestamp
            this.config.lastUpdated = new Date().toISOString();
            
            return true;
        } catch (error) {
            console.error('Error saving config:', error);
            this.showNotification('Error saving configuration: ' + error.message, 'error');
            return false;
        }
    },
    
    /**
     * Setup event listeners
     */
    setupEventListeners: function() {
        // Section navigation
        document.querySelectorAll('.admin-nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                this.switchSection(section);
            });
        });
        
        // Save button
        document.getElementById('save-btn')?.addEventListener('click', () => {
            this.saveConfig();
        });
        
        // Preview button
        document.getElementById('preview-btn')?.addEventListener('click', () => {
            this.previewSite();
        });
        
        // Reset button
        document.getElementById('reset-btn')?.addEventListener('click', () => {
            if (confirm('Are you sure you want to reset all changes?')) {
                this.loadConfig().then(() => {
                    this.renderCurrentSection();
                    this.showNotification('Changes reset', 'info');
                });
            }
        });
        
        // Handle before unload if there are unsaved changes
        window.addEventListener('beforeunload', (e) => {
            if (this.hasChanges) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    },
    
    /**
     * Switch admin section
     */
    switchSection: function(section) {
        // Update active nav item
        document.querySelectorAll('.admin-nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.section === section);
        });
        
        this.currentSection = section;
        this.renderCurrentSection();
    },
    
    /**
     * Render current section
     */
    renderCurrentSection: function() {
        const container = document.getElementById('editor-content');
        if (!container) return;
        
        switch (this.currentSection) {
            case 'general':
                container.innerHTML = this.renderGeneralSettings();
                break;
            case 'navigation':
                container.innerHTML = this.renderNavigationSettings();
                break;
            case 'hero':
                container.innerHTML = this.renderHeroSettings();
                break;
            case 'content':
                container.innerHTML = this.renderContentSettings();
                break;
            case 'theme':
                container.innerHTML = this.renderThemeSettings();
                break;
            case 'images':
                container.innerHTML = this.renderImageSettings();
                break;
            case 'popup':
                container.innerHTML = this.renderPopupSettings();
                break;
            case 'github':
                container.innerHTML = this.renderGitHubSettings();
                break;
            default:
                container.innerHTML = '<p>Section not found</p>';
        }
        
        // Setup section-specific event listeners
        this.setupSectionListeners();
    },
    
    /**
     * Render General Settings
     */
    renderGeneralSettings: function() {
        return `
            <h2>General Settings</h2>
            <div class="form-section">
                <div class="form-group">
                    <label>Site Name</label>
                    <input type="text" id="site-name" value="${this.config.site.name}" onchange="AdminEditor.updateConfig('site.name', this.value)">
                </div>
                <div class="form-group">
                    <label>Site Description</label>
                    <textarea id="site-description" onchange="AdminEditor.updateConfig('site.description', this.value)">${this.config.site.description}</textarea>
                </div>
                <div class="form-group">
                    <label>Logo URL</label>
                    <input type="text" id="site-logo" value="${this.config.site.logo}" onchange="AdminEditor.updateConfig('site.logo', this.value)">
                </div>
                <div class="form-group">
                    <label>Favicon URL</label>
                    <input type="text" id="site-favicon" value="${this.config.site.favicon}" onchange="AdminEditor.updateConfig('site.favicon', this.value)">
                </div>
            </div>
        `;
    },
    
    /**
     * Render Navigation Settings
     */
    renderNavigationSettings: function() {
        const nav = this.config.navigation;
        return `
            <h2>Navigation Settings</h2>
            <div class="form-section">
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${nav.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('navigation.enabled', this.checked)">
                        Enable Navigation
                    </label>
                </div>
                <h3>Logo</h3>
                <div class="form-group">
                    <label>Logo Text</label>
                    <input type="text" value="${nav.logo.text}" onchange="AdminEditor.updateConfig('navigation.logo.text', this.value)">
                </div>
                <div class="form-group">
                    <label>Logo Link</label>
                    <input type="text" value="${nav.logo.link}" onchange="AdminEditor.updateConfig('navigation.logo.link', this.value)">
                </div>
                Menu Items</h3>
                <div id="menu-items-editor">
                    ${nav.menu.sort((a, b) => a.order - b.order).map((item, index) => `
                        <div class="menu-item-editor">
                            <div class="form-row">
                                <input type="text" placeholder="Text" value="${item.text}" onchange="AdminEditor.updateMenuItem(${index}, 'text', this.value)">
                                <input type="text" placeholder="Link" value="${item.link}" onchange="AdminEditor.updateMenuItem(${index}, 'link', this.value)">
                                <input type="number" placeholder="Order" value="${item.order}" min="1" onchange="AdminEditor.updateMenuItem(${index}, 'order', parseInt(this.value))">
                                <button type="button" class="btn-danger" onclick="AdminEditor.removeMenuItem(${index})">Remove</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addMenuItem()">+ Add Menu Item</button>
                
                <h3>Apply Button</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${nav.applyButton.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('navigation.applyButton.enabled', this.checked)">
                        Enable Apply Button
                    </label>
                </div>
                <div class="form-group">
                    <label>Button Text</label>
                    <input type="text" value="${nav.applyButton.text}" onchange="AdminEditor.updateConfig('navigation.applyButton.text', this.value)">
                </div>
                <div class="form-group">
                    <label>Button Link</label>
                    <input type="text" value="${nav.applyButton.link}" onchange="AdminEditor.updateConfig('navigation.applyButton.link', this.value)">
                </div>
                
                <h3>Navigation Style</h3>
                <div class="form-group">
                    <label>Font Family</label>
                    <select onchange="AdminEditor.updateConfig('navigation.style.fontFamily', this.value)">
                        <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" ${nav.style.fontFamily.includes('Segoe UI') ? 'selected' : ''}>Segoe UI</option>
                        <option value="'Arial', sans-serif" ${nav.style.fontFamily.includes('Arial') ? 'selected' : ''}>Arial</option>
                        <option value="'Roboto', sans-serif" ${nav.style.fontFamily.includes('Roboto') ? 'selected' : ''}>Roboto</option>
                        <option value="'Open Sans', sans-serif" ${nav.style.fontFamily.includes('Open Sans') ? 'selected' : ''}>Open Sans</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Text Color</label>
                    <input type="color" value="${nav.style.textColor}" onchange="AdminEditor.updateConfig('navigation.style.textColor', this.value)">
                </div>
                <div class="form-group">
                    <label>Background Color</label>
                    <input type="color" value="${nav.style.backgroundColor}" onchange="AdminEditor.updateConfig('navigation.style.backgroundColor', this.value)">
                </div>
                <div class="form-group">
                    <label>Hover Color</label>
                    <input type="color" value="${nav.style.hoverColor}" onchange="AdminEditor.updateConfig('navigation.style.hoverColor', this.value)">
                </div>
            </div>
        `;
    },
    
    /**
     * Render Hero Settings
     */
    renderHeroSettings: function() {
        const hero = this.config.hero;
        return `
            <h2>Hero Section</h2>
            <div class="form-section">
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${hero.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('hero.enabled', this.checked)">
                        Enable Hero Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${hero.title}" onchange="AdminEditor.updateConfig('hero.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Tagline</label>
                    <input type="text" value="${hero.tagline}" onchange="AdminEditor.updateConfig('hero.tagline', this.value)">
                </div>
                <div class="form-group">
                    <label>Button Text</label>
                    <input type="text" value="${hero.buttonText}" onchange="AdminEditor.updateConfig('hero.buttonText', this.value)">
                </div>
                <div class="form-group">
                    <label>Button Link</label>
                    <input type="text" value="${hero.buttonLink}" onchange="AdminEditor.updateConfig('hero.buttonLink', this.value)">
                </div>
                <div class="form-group">
                    <label>Background Image</label>
                    <input type="text" value="${hero.backgroundImage}" onchange="AdminEditor.updateConfig('hero.backgroundImage', this.value)">
                    <small>Image path relative to project root</small>
                </div>
                <div class="form-group">
                    <label>Overlay Color</label>
                    <input type="color" value="${this.hexToRgba(hero.overlayColor)}" onchange="AdminEditor.updateConfig('hero.overlayColor', this.value)">
                </div>
                <div class="form-group">
                    <label>Text Color</label>
                    <input type="color" value="${hero.textColor}" onchange="AdminEditor.updateConfig('hero.textColor', this.value)">
                </div>
            </div>
        `;
    },
    
    /**
     * Render Content Settings (Introduction, Overview, Services, etc.)
     */
    renderContentSettings: function() {
        return `
            <h2>Content Editor</h2>
            
            <div class="content-tabs">
                <button class="tab-btn active" data-tab="introduction" onclick="AdminEditor.switchContentTab('introduction')">Introduction</button>
                <button class="tab-btn" data-tab="overview" onclick="AdminEditor.switchContentTab('overview')">Overview</button>
                <button class="tab-btn" data-tab="services" onclick="AdminEditor.switchContentTab('services')">Services</button>
                <button class="tab-btn" data-tab="team" onclick="AdminEditor.switchContentTab('team')">Team</button>
                <button class="tab-btn" data-tab="clients" onclick="AdminEditor.switchContentTab('clients')">Clients</button>
                <button class="tab-btn" data-tab="gallery" onclick="AdminEditor.switchContentTab('gallery')">Gallery</button>
                <button class="tab-btn" data-tab="contact" onclick="AdminEditor.switchContentTab('contact')">Contact</button>
                <button class="tab-btn" data-tab="footer" onclick="AdminEditor.switchContentTab('footer')">Footer</button>
            </div>
            
            <div id="content-editor-area">
                ${this.renderIntroductionEditor()}
            </div>
        `;
    },
    
    /**
     * Render Introduction Editor
     */
    renderIntroductionEditor: function() {
        const intro = this.config.introduction;
        return `
            <div class="form-section content-tab-panel" id="tab-introduction">
                <h3>Introduction Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${intro.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('introduction.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${intro.title}" onchange="AdminEditor.updateConfig('introduction.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Content Paragraphs</label>
                    ${intro.content.map((p, i) => `
                        <textarea rows="3" onchange="AdminEditor.updateConfig('introduction.content[${i}]', this.value)">${p}</textarea>
                    `).join('')}
                </div>
                <div class="form-group">
                    <label>Image</label>
                    <input type="text" value="${intro.image}" onchange="AdminEditor.updateConfig('introduction.image', this.value)">
                </div>
            </div>
        `;
    },
    
    /**
     * Render Services Editor
     */
    renderServicesEditor: function() {
        const services = this.config.services;
        const layout = services.layout || { columns: 4, alignment: 'left', itemAlignment: 'left' };
        return `
            <div class="form-section content-tab-panel" id="tab-services" style="display:none;">
                <h3>Services Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${services.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('services.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${services.title}" onchange="AdminEditor.updateConfig('services.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Subtitle</label>
                    <input type="text" value="${services.subtitle}" onchange="AdminEditor.updateConfig('services.subtitle', this.value)">
                </div>
                
                <!-- Layout Settings -->
                <div class="layout-settings">
                    <h4>📐 Layout Settings</h4>
                    <div class="layout-controls">
                        <div class="form-group">
                            <label>Number of Columns</label>
                            <select onchange="AdminEditor.updateConfig('services.layout.columns', parseInt(this.value))">
                                <option value="1" ${layout.columns === 1 ? 'selected' : ''}>1 Column</option>
                                <option value="2" ${layout.columns === 2 ? 'selected' : ''}>2 Columns</option>
                                <option value="3" ${layout.columns === 3 ? 'selected' : ''}>3 Columns</option>
                                <option value="4" ${layout.columns === 4 ? 'selected' : ''}>4 Columns</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Section Alignment</label>
                            <select onchange="AdminEditor.updateConfig('services.layout.alignment', this.value)">
                                <option value="left" ${layout.alignment === 'left' ? 'selected' : ''}>Align Left</option>
                                <option value="center" ${layout.alignment === 'center' ? 'selected' : ''}>Align Center</option>
                                <option value="right" ${layout.alignment === 'right' ? 'selected' : ''}>Align Right</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Item Alignment</label>
                            <select onchange="AdminEditor.updateConfig('services.layout.itemAlignment', this.value)">
                                <option value="left" ${layout.itemAlignment === 'left' ? 'selected' : ''}>Items Align Left</option>
                                <option value="center" ${layout.itemAlignment === 'center' ? 'selected' : ''}>Items Align Center</option>
                                <option value="right" ${layout.itemAlignment === 'right' ? 'selected' : ''}>Items Align Right</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <h4>Service Items</h4>
                <div id="services-editor">
                    ${services.items.map((service, index) => {
                        const serviceLayout = service.layout || { column: (index % layout.columns) + 1, order: index + 1 };
                        return `
                        <div class="item-editor">
                            <h5>Service ${index + 1}</h5>
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" value="${service.title}" onchange="AdminEditor.updateConfig('services.items[${index}].title', this.value)">
                            </div>
                            <div class="form-group">
                                <label>Icon (emoji)</label>
                                <input type="text" value="${service.icon}" onchange="AdminEditor.updateConfig('services.items[${index}].icon', this.value)">
                            </div>
                            <div class="form-group">
                                <label>Content</label>
                                <textarea rows="4" onchange="AdminEditor.updateConfig('services.items[${index}].content', this.value)">${service.content}</textarea>
                            </div>
                            <div class="item-layout-controls">
                                <div class="form-group">
                                    <label>Column</label>
                                    <select onchange="AdminEditor.updateConfig('services.items[${index}].layout.column', parseInt(this.value))">
                                        ${[1,2,3,4].map(col => `<option value="${col}" ${serviceLayout.column === col ? 'selected' : ''}>Column ${col}</option>`).join('')}
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Order/Row</label>
                                    <input type="number" value="${serviceLayout.order}" min="1" onchange="AdminEditor.updateConfig('services.items[${index}].layout.order', parseInt(this.value))">
                                </div>
                            </div>
                            <button type="button" class="btn-danger" onclick="AdminEditor.removeService(${index})">Remove Service</button>
                        </div>
                    `}).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addService()">+ Add Service</button>
            </div>
        `;
    },
    
    /**
     * Render Overview Editor
     */
    renderOverviewEditor: function() {
        const overview = this.config.overview;
        return `
            <div class="form-section content-tab-panel" id="tab-overview" style="display:none;">
                <h3>Company Overview</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${overview.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('overview.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${overview.title}" onchange="AdminEditor.updateConfig('overview.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Subtitle</label>
                    <input type="text" value="${overview.subtitle}" onchange="AdminEditor.updateConfig('overview.subtitle', this.value)">
                </div>
                <h4>Mission</h4>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${overview.mission.title}" onchange="AdminEditor.updateConfig('overview.mission.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Icon</label>
                    <input type="text" value="${overview.mission.icon}" onchange="AdminEditor.updateConfig('overview.mission.icon', this.value)">
                </div>
                <div class="form-group">
                    <label>Content</label>
                    <textarea rows="4" onchange="AdminEditor.updateConfig('overview.mission.content', this.value)">${overview.mission.content}</textarea>
                </div>
                <h4>Vision</h4>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${overview.vision.title}" onchange="AdminEditor.updateConfig('overview.vision.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Icon</label>
                    <input type="text" value="${overview.vision.icon}" onchange="AdminEditor.updateConfig('overview.vision.icon', this.value)">
                </div>
                <div class="form-group">
                    <label>Content</label>
                    <textarea rows="4" onchange="AdminEditor.updateConfig('overview.vision.content', this.value)">${overview.vision.content}</textarea>
                </div>
            </div>
        `;
    },
    
    /**
     * Render Team Editor
     */
    renderTeamEditor: function() {
        const team = this.config.team;
        const layout = team.layout || { columns: 4, alignment: 'center', itemAlignment: 'center' };
        return `
            <div class="form-section content-tab-panel" id="tab-team" style="display:none;">
                <h3>Team Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${team.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('team.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${team.title}" onchange="AdminEditor.updateConfig('team.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Subtitle</label>
                    <input type="text" value="${team.subtitle}" onchange="AdminEditor.updateConfig('team.subtitle', this.value)">
                </div>
                
                <!-- Layout Settings -->
                <div class="layout-settings">
                    <h4>📐 Layout Settings</h4>
                    <div class="layout-controls">
                        <div class="form-group">
                            <label>Number of Columns</label>
                            <select onchange="AdminEditor.updateConfig('team.layout.columns', parseInt(this.value))">
                                <option value="1" ${layout.columns === 1 ? 'selected' : ''}>1 Column</option>
                                <option value="2" ${layout.columns === 2 ? 'selected' : ''}>2 Columns</option>
                                <option value="3" ${layout.columns === 3 ? 'selected' : ''}>3 Columns</option>
                                <option value="4" ${layout.columns === 4 ? 'selected' : ''}>4 Columns</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Section Alignment</label>
                            <select onchange="AdminEditor.updateConfig('team.layout.alignment', this.value)">
                                <option value="left" ${layout.alignment === 'left' ? 'selected' : ''}>Align Left</option>
                                <option value="center" ${layout.alignment === 'center' ? 'selected' : ''}>Align Center</option>
                                <option value="right" ${layout.alignment === 'right' ? 'selected' : ''}>Align Right</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Item Alignment</label>
                            <select onchange="AdminEditor.updateConfig('team.layout.itemAlignment', this.value)">
                                <option value="left" ${layout.itemAlignment === 'left' ? 'selected' : ''}>Items Align Left</option>
                                <option value="center" ${layout.itemAlignment === 'center' ? 'selected' : ''}>Items Align Center</option>
                                <option value="right" ${layout.itemAlignment === 'right' ? 'selected' : ''}>Items Align Right</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <h4>Team Members</h4>
                <div id="team-editor">
                    ${team.members.map((member, index) => {
                        const memberLayout = member.layout || { column: (index % layout.columns) + 1, order: index + 1 };
                        return `
                        <div class="item-editor">
                            <h5>Team Member ${index + 1}</h5>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" value="${member.name}" onchange="AdminEditor.updateConfig('team.members[${index}].name', this.value)">
                            </div>
                            <div class="form-group">
                                <label>Position</label>
                                <input type="text" value="${member.position}" onchange="AdminEditor.updateConfig('team.members[${index}].position', this.value)">
                            </div>
                            <div class="form-group">
                                <label>Photo</label>
                                <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
<input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'team', ${index})">
                                ${member.image ? `<img src="${member.image}" alt="${member.name}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
                            </div>
                            <div class="item-layout-controls">
                                <div class="form-group">
                                    <label>Column</label>
                                    <select onchange="AdminEditor.updateConfig('team.members[${index}].layout.column', parseInt(this.value))">
                                        ${[1,2,3,4].map(col => `<option value="${col}" ${memberLayout.column === col ? 'selected' : ''}>Column ${col}</option>`).join('')}
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Order/Row</label>
                                    <input type="number" value="${memberLayout.order}" min="1" onchange="AdminEditor.updateConfig('team.members[${index}].layout.order', parseInt(this.value))">
                                </div>
                            </div>
                            <button type="button" class="btn-danger" onclick="AdminEditor.removeTeamMember(${index})">Remove Member</button>
                        </div>
                    `}).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addTeamMember()">+ Add Team Member</button>
            </div>
        `;
    },
    
    /**
     * Render Gallery Editor
     */
    renderGalleryEditor: function() {
        const gallery = this.config.gallery;
        return `
            <div class="form-section content-tab-panel" id="tab-gallery" style="display:none;">
                <h3>Gallery Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${gallery.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('gallery.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${gallery.title}" onchange="AdminEditor.updateConfig('gallery.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Subtitle</label>
                    <input type="text" value="${gallery.subtitle}" onchange="AdminEditor.updateConfig('gallery.subtitle', this.value)">
                </div>
                <h4>Gallery Images</h4>
                <div id="gallery-editor">
                    ${gallery.images.map((img, index) => `
                        <div class="item-editor">
                            <h5>Image ${index + 1}</h5>
                            <div class="form-group">
                                <label>Image Source</label>
                                <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'gallery', ${index})">
                            </div>
                            <div class="form-group">
                                <label>Alt Text</label>
                                <input type="text" value="${img.alt}" onchange="AdminEditor.updateConfig('gallery.images[${index}].alt', this.value)">
                            </div>
                            ${img.src ? `<img src="${img.src}" alt="${img.alt}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
                            <button type="button" class="btn-danger" onclick="AdminEditor.removeGalleryImage(${index})">Remove Image</button>
                        </div>
                    `).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addGalleryImage()">+ Add Gallery Image</button>
            </div>
        `;
    },
    
    /**
     * Render Contact Editor
     */
    renderContactEditor: function() {
        const contact = this.config.contact;
        return `
            <div class="form-section content-tab-panel" id="tab-contact" style="display:none;">
                <h3>Contact Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${contact.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('contact.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${contact.title}" onchange="AdminEditor.updateConfig('contact.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Subtitle</label>
                    <input type="text" value="${contact.subtitle}" onchange="AdminEditor.updateConfig('contact.subtitle', this.value)">
                </div>
                <h4>Contact Information</h4>
                <div class="form-group">
                    <label>Company Name</label>
                    <input type="text" value="${contact.company}" onchange="AdminEditor.updateConfig('contact.company', this.value)">
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" value="${contact.phone}" onchange="AdminEditor.updateConfig('contact.phone', this.value)">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" value="${contact.email}" onchange="AdminEditor.updateConfig('contact.email', this.value)">
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" value="${contact.address}" onchange="AdminEditor.updateConfig('contact.address', this.value)">
                </div>
                <h4>Contact Form</h4>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${contact.form.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('contact.form.enabled', this.checked)">
                        Enable Contact Form
                    </label>
                </div>
                <div class="form-group">
                    <label>Email To</label>
                    <input type="text" value="${contact.form.emailTo}" onchange="AdminEditor.updateConfig('contact.form.emailTo', this.value)">
                </div>
            </div>
        `;
    },
    
    /**
     * Render Footer Editor
     */
    renderFooterEditor: function() {
        const footer = this.config.footer;
        return `
            <div class="form-section content-tab-panel" id="tab-footer" style="display:none;">
                <h3>Footer Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${footer.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('footer.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <h4>About Section</h4>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${footer.about.title}" onchange="AdminEditor.updateConfig('footer.about.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Content</label>
                    <textarea rows="3" onchange="AdminEditor.updateConfig('footer.about.content', this.value)">${footer.about.content}</textarea>
                </div>
                <h4>Quick Links</h4>
                <div id="footer-quicklinks-editor">
                    ${footer.quickLinks.map((link, index) => `
                        <div class="form-row">
                            <input type="text" placeholder="Text" value="${link.text}" onchange="AdminEditor.updateConfig('footer.quickLinks[${index}].text', this.value)">
                            <input type="text" placeholder="Link" value="${link.link}" onchange="AdminEditor.updateConfig('footer.quickLinks[${index}].link', this.value)">
                            <button type="button" class="btn-danger" onclick="AdminEditor.removeFooterQuickLink(${index})">Remove</button>
                        </div>
                    `).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addFooterQuickLink()">+ Add Quick Link</button>
                <h4>Services Links</h4>
                <div id="footer-services-editor">
                    ${footer.services.map((link, index) => `
                        <div class="form-row">
                            <input type="text" placeholder="Text" value="${link.text}" onchange="AdminEditor.updateConfig('footer.services[${index}].text', this.value)">
                            <input type="text" placeholder="Link" value="${link.link}" onchange="AdminEditor.updateConfig('footer.services[${index}].link', this.value)">
                            <button type="button" class="btn-danger" onclick="AdminEditor.removeFooterServiceLink(${index})">Remove</button>
                        </div>
                    `).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addFooterServiceLink()">+ Add Service Link</button>
                <h4>Social Media</h4>
                <div class="form-group">
                    <label>Facebook</label>
                    <input type="text" value="${footer.social.facebook}" onchange="AdminEditor.updateConfig('footer.social.facebook', this.value)">
                </div>
                <div class="form-group">
                    <label>Twitter</label>
                    <input type="text" value="${footer.social.twitter}" onchange="AdminEditor.updateConfig('footer.social.twitter', this.value)">
                </div>
                <div class="form-group">
                    <label>LinkedIn</label>
                    <input type="text" value="${footer.social.linkedin}" onchange="AdminEditor.updateConfig('footer.social.linkedin', this.value)">
                </div>
                <div class="form-group">
                    <label>Instagram</label>
                    <input type="text" value="${footer.social.instagram}" onchange="AdminEditor.updateConfig('footer.social.instagram', this.value)">
                </div>
                <h4>Copyright</h4>
                <div class="form-group">
                    <label>Copyright Text</label>
                    <input type="text" value="${footer.copyright}" onchange="AdminEditor.updateConfig('footer.copyright', this.value)">
                </div>
            </div>
        `;
    },
    
    /**
     * Render Clients Editor
     */
    renderClientsEditor: function() {
        const clients = this.config.clients;
        return `
            <div class="form-section content-tab-panel" id="tab-clients" style="display:none;">
                <h3>Clients Section</h3>
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${clients.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('clients.enabled', this.checked)">
                        Enable Section
                    </label>
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${clients.title}" onchange="AdminEditor.updateConfig('clients.title', this.value)">
                </div>
                <div class="form-group">
                    <label>Subtitle</label>
                    <input type="text" value="${clients.subtitle}" onchange="AdminEditor.updateConfig('clients.subtitle', this.value)">
                </div>
                <h4>Clients</h4>
                <div id="clients-editor">
                    ${clients.items.map((client, index) => `
                        <div class="item-editor">
                            <h5>Client ${index + 1}</h5>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" value="${client.name}" onchange="AdminEditor.updateConfig('clients.items[${index}].name', this.value)">
                            </div>
                            <div class="form-group">
                                <label>Logo</label>
                                <input type="text" value="${client.logo}" onchange="AdminEditor.updateConfig('clients.items[${index}].logo', this.value)">
                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'client', ${index})">
                            </div>
                            <button type="button" class="btn-danger" onclick="AdminEditor.removeClient(${index})">Remove Client</button>
                        </div>
                    `).join('')}
                </div>
                <button type="button" class="btn-secondary" onclick="AdminEditor.addClient()">+ Add Client</button>
            </div>
        `;
    },
    
    /**
     * Add team member
     */
    addTeamMember: function() {
        const layout = this.config.team.layout || { columns: 4 };
        const newMember = {
            name: 'New Team Member',
            position: 'Position',
            image: 'images/intro.jpg',
            layout: {
                column: (this.config.team.members.length % layout.columns) + 1,
                order: this.config.team.members.length + 1
            }
        };
        this.config.team.members.push(newMember);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Remove team member
     */
    removeTeamMember: function(index) {
        if (confirm('Remove this team member?')) {
            this.config.team.members.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Add gallery image
     */
    addGalleryImage: function() {
        const newImage = {
            src: 'images/intro.jpg',
            alt: 'New Gallery Image'
        };
        this.config.gallery.images.push(newImage);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Remove gallery image
     */
    removeGalleryImage: function(index) {
        if (confirm('Remove this image?')) {
            this.config.gallery.images.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Add client
     */
    addClient: function() {
        const newClient = {
            name: 'New Client',
            logo: ''
        };
        this.config.clients.items.push(newClient);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Remove client
     */
    removeClient: function(index) {
        if (confirm('Remove this client?')) {
            this.config.clients.items.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Add footer quick link
     */
    addFooterQuickLink: function() {
        const newLink = {
            text: 'New Link',
            link: '#'
        };
        this.config.footer.quickLinks.push(newLink);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Remove footer quick link
     */
    removeFooterQuickLink: function(index) {
        if (confirm('Remove this link?')) {
            this.config.footer.quickLinks.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Add footer service link
     */
    addFooterServiceLink: function() {
        const newLink = {
            text: 'New Service',
            link: '#'
        };
        this.config.footer.services.push(newLink);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Remove footer service link
     */
    removeFooterServiceLink: function(index) {
        if (confirm('Remove this service link?')) {
            this.config.footer.services.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Render Theme Settings
     */
    renderThemeSettings: function() {
        const theme = this.config.theme;
        return `
            <h2>Theme & Colors</h2>
            <div class="form-section">
                <h3>Primary Colors</h3>
                <div class="color-grid">
                    <div class="form-group">
                        <label>Primary</label>
                        <input type="color" value="${theme.colors.primary}" onchange="AdminEditor.updateConfig('theme.colors.primary', this.value)">
                        <input type="text" value="${theme.colors.primary}" onchange="AdminEditor.updateConfig('theme.colors.primary', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Primary Light</label>
                        <input type="color" value="${theme.colors.primaryLight}" onchange="AdminEditor.updateConfig('theme.colors.primaryLight', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Primary Dark</label>
                        <input type="color" value="${theme.colors.primaryDark}" onchange="AdminEditor.updateConfig('theme.colors.primaryDark', this.value)">
                    </div>
                </div>
                
                <h3>Secondary Colors</h3>
                <div class="color-grid">
                    <div class="form-group">
                        <label>Secondary</label>
                        <input type="color" value="${theme.colors.secondary}" onchange="AdminEditor.updateConfig('theme.colors.secondary', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Secondary Light</label>
                        <input type="color" value="${theme.colors.secondaryLight}" onchange="AdminEditor.updateConfig('theme.colors.secondaryLight', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Secondary Dark</label>
                        <input type="color" value="${theme.colors.secondaryDark}" onchange="AdminEditor.updateConfig('theme.colors.secondaryDark', this.value)">
                    </div>
                </div>
                
                <h3>Background Colors</h3>
                <div class="color-grid">
                    <div class="form-group">
                        <label>Background Light</label>
                        <input type="color" value="${theme.colors.backgroundLight}" onchange="AdminEditor.updateConfig('theme.colors.backgroundLight', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Background White</label>
                        <input type="color" value="${theme.colors.backgroundWhite}" onchange="AdminEditor.updateConfig('theme.colors.backgroundWhite', this.value)">
                    </div>
                </div>
                
                <h3>Text Colors</h3>
                <div class="color-grid">
                    <div class="form-group">
                        <label>Text Dark</label>
                        <input type="color" value="${theme.colors.textDark}" onchange="AdminEditor.updateConfig('theme.colors.textDark', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Text Gray</label>
                        <input type="color" value="${theme.colors.textGray}" onchange="AdminEditor.updateConfig('theme.colors.textGray', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Text Light</label>
                        <input type="color" value="${theme.colors.textLight}" onchange="AdminEditor.updateConfig('theme.colors.textLight', this.value)">
                    </div>
                </div>
                
                <h3>Button Colors</h3>
                <div class="color-grid">
                    <div class="form-group">
                        <label>Primary Button</label>
                        <input type="color" value="${theme.buttons.primary}" onchange="AdminEditor.updateConfig('theme.buttons.primary', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Secondary Button</label>
                        <input type="color" value="${theme.buttons.secondary}" onchange="AdminEditor.updateConfig('theme.buttons.secondary', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Hover</label>
                        <input type="color" value="${theme.buttons.hover}" onchange="AdminEditor.updateConfig('theme.buttons.hover', this.value)">
                    </div>
                </div>
                
                <h3>Typography</h3>
                <div class="form-group">
                    <label>Primary Font</label>
                    <select onchange="AdminEditor.updateConfig('theme.fonts.primary', this.value)">
                        <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" ${theme.fonts.primary.includes('Segoe UI') ? 'selected' : ''}>Segoe UI</option>
                        <option value="'Arial', sans-serif" ${theme.fonts.primary.includes('Arial') ? 'selected' : ''}>Arial</option>
                        <option value="'Roboto', sans-serif" ${theme.fonts.primary.includes('Roboto') ? 'selected' : ''}>Roboto</option>
                        <option value="'Open Sans', sans-serif" ${theme.fonts.primary.includes('Open Sans') ? 'selected' : ''}>Open Sans</option>
                        <option value="'Poppins', sans-serif" ${theme.fonts.primary.includes('Poppins') ? 'selected' : ''}>Poppins</option>
                    </select>
                </div>
                
                <button type="button" class="btn-primary" onclick="AdminEditor.previewTheme()">Preview Theme</button>
            </div>
        `;
    },
    
    /**
     * Render Image Settings
     */
    renderImageSettings: function() {
        return `
            <h2>Image Management</h2>
            <div class="form-section">
                <p>Upload new images or change image paths. Images are stored in the images folder.</p>
                
                <div class="image-uploader">
                    <h3>Hero Background</h3>
                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'hero')">
                    <input type="text" value="${this.config.hero.backgroundImage}" placeholder="Or enter image URL">
                </div>
                
                <div class="image-uploader">
                    <h3>Introduction Image</h3>
                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'intro')">
                    <input type="text" value="${this.config.introduction.image}" placeholder="Or enter image URL">
                </div>
                
                <div class="image-uploader">
                    <h3>Popup Image</h3>
                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'popup')">
                    <input type="text" value="${this.config.popup.image}" placeholder="Or enter image URL">
                </div>
                
                <h3>Team Photos</h3>
                <div class="image-grid">
                    ${this.config.team.members.map((member, index) => `
                        <div class="image-item">
                            <label>${member.name}</label>
                            <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'team', ${index})">
                        </div>
                    `).join('')}
                </div>
                
                <h3>Gallery Images</h3>
                <div class="image-grid">
                    ${this.config.gallery.images.map((img, index) => `
                        <div class="image-item">
                            <label>Image ${index + 1}</label>
                            <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'gallery', ${index})">
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    },
    
    /**
     * Render Popup Settings
     */
    renderPopupSettings: function() {
        const popup = this.config.popup;
        return `
            <h2>Popup Editor</h2>
            <div class="form-section">
                <div class="form-group">
                    <label>
                        <input type="checkbox" ${popup.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('popup.enabled', this.checked)">
                        Enable Popup
                    </label>
                </div>
                
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" value="${popup.title}" onchange="AdminEditor.updateConfig('popup.title', this.value)">
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea rows="4" onchange="AdminEditor.updateConfig('popup.description', this.value)">${popup.description}</textarea>
                </div>
                
                <div class="form-group">
                    <label>Image</label>
                    <input type="text" value="${popup.image}" onchange="AdminEditor.updateConfig('popup.image', this.value)">
                </div>
                
                <div class="form-group">
                    <label>Button Text</label>
                    <input type="text" value="${popup.buttonText}" onchange="AdminEditor.updateConfig('popup.buttonText', this.value)">
                </div>
                
                <div class="form-group">
                    <label>Button Link</label>
                    <input type="text" value="${popup.buttonLink}" onchange="AdminEditor.updateConfig('popup.buttonLink', this.value)">
                </div>
                
                <h3>Colors</h3>
                <div class="color-grid">
                    <div class="form-group">
                        <label>Background Color</label>
                        <input type="color" value="${this.hexToRgba(popup.backgroundColor)}" onchange="AdminEditor.updateConfig('popup.backgroundColor', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Text Color</label>
                        <input type="color" value="${popup.textColor}" onchange="AdminEditor.updateConfig('popup.textColor', this.value)">
                    </div>
                    <div class="form-group">
                        <label>Button Color</label>
                        <input type="color" value="${popup.buttonColor}" onchange="AdminEditor.updateConfig('popup.buttonColor', this.value)">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Show Again Duration (days)</label>
                    <input type="number" value="${popup.showAgainDuration}" min="1" max="30" onchange="AdminEditor.updateConfig('popup.showAgainDuration', parseInt(this.value))">
                </div>
                
                <button type="button" class="btn-secondary" onclick="AdminEditor.testPopup()">Test Popup</button>
            </div>
        `;
    },
    
    /**
     * Render GitHub Settings
     */
    renderGitHubSettings: function() {
        const github = this.config.github;
        return `
            <h2>GitHub Publish Panel</h2>
            <div class="form-section">
                <div class="form-group">
                    <label>Repository URL</label>
                    <input type="text" id="github-repo" value="${github.repoUrl}" placeholder="https://github.com/username/repo" onchange="AdminEditor.updateConfig('github.repoUrl', this.value)">
                </div>
                
                <div class="form-group">
                    <label>GitHub Username</label>
                    <input type="text" id="github-username" value="${github.username}" placeholder="username" onchange="AdminEditor.updateConfig('github.username', this.value)">
                </div>
                
                <div class="form-group">
                    <label>Personal Access Token</label>
                    <input type="password" id="github-token" value="${github.token}" placeholder="ghp_xxxxxxxxxxxx" onchange="AdminEditor.updateConfig('github.token', this.value)">
                    <small>Create a token with 'repo' scope at GitHub Settings > Developer settings > Personal access tokens</small>
                </div>
                
                <div class="form-group">
                    <label>Branch</label>
                    <input type="text" id="github-branch" value="${github.branch}" placeholder="main" onchange="AdminEditor.updateConfig('github.branch', this.value)">
                </div>
                
                <div class="button-group">
                    <button type="button" class="btn-secondary" onclick="AdminEditor.testGitHubConnection()">Test Connection</button>
                    <button type="button" class="btn-primary" onclick="AdminEditor.publishToGitHub()">Publish Website</button>
                </div>
                
                <div id="github-status" class="status-message"></div>
            </div>
        `;
    },
    
    /**
     * Setup section-specific event listeners
     */
    setupSectionListeners: function() {
        // This is called after rendering each section
        // Additional event listeners can be added here
    },
    
    /**
     * Update configuration value
     */
    updateConfig: function(path, value) {
        const keys = path.split('.');
        let obj = this.config;
        
        for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            // Handle array indices
            const match = key.match(/^(\w+)\[(\d+)\]$/);
            if (match) {
                if (!obj[match[1]]) obj[match[1]] = [];
                obj = obj[match[1]];
                i++;
                key = keys[i];
            }
            obj = obj[key];
        }
        
        const lastKey = keys[keys.length - 1];
        const arrayMatch = lastKey.match(/^(\w+)\[(\d+)\]$/);
        
        if (arrayMatch) {
            obj[arrayMatch[1]][parseInt(arrayMatch[2])] = value;
        } else {
            obj[lastKey] = value;
        }
        
        this.hasChanges = true;
    },
    
    /**
     * Add menu item
     */
    addMenuItem: function() {
        const newItem = {
            text: 'New Item',
            link: '#section',
            order: this.config.navigation.menu.length + 1
        };
        this.config.navigation.menu.push(newItem);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Update menu item
     */
    updateMenuItem: function(index, field, value) {
        this.config.navigation.menu[index][field] = value;
        this.hasChanges = true;
    },
    
    /**
     * Remove menu item
     */
    removeMenuItem: function(index) {
        if (confirm('Remove this menu item?')) {
            this.config.navigation.menu.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Add service
     */
    addService: function() {
        const newService = {
            title: 'New Service',
            icon: '✨',
            content: 'Service description here.'
        };
        this.config.services.items.push(newService);
        this.hasChanges = true;
        this.renderCurrentSection();
    },
    
    /**
     * Remove service
     */
    removeService: function(index) {
        if (confirm('Remove this service?')) {
            this.config.services.items.splice(index, 1);
            this.hasChanges = true;
            this.renderCurrentSection();
        }
    },
    
    /**
     * Switch content tab
     */
    switchContentTab: function(tab) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });
        
        // Hide all panels
        document.querySelectorAll('.content-tab-panel').forEach(panel => {
            panel.style.display = 'none';
        });
        
        // Show selected panel
        const panel = document.getElementById('tab-' + tab);
        if (panel) {
            panel.style.display = 'block';
        } else {
            // Render the panel if not exists
            const contentArea = document.getElementById('content-editor-area');
            switch(tab) {
                case 'introduction':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'overview':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'services':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'team':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'gallery':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'contact':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'footer':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'clients':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                default:
                    contentArea.innerHTML = '<p>Editor coming soon for this section.</p>';
            }
        }
    },
    
    /**
     * Crop and upload image
     */
    cropImage: function(input, type, index) {
        const file = input.files[0];
        if (!file) return;
        
        // Create cropper modal
        this.createCropperModal(file, type, index);
    },
    
    /**
     * Create cropper modal
     */
    createCropperModal: function(file, type, index) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const imgData = e.target.result;
            
            // Create modal
            const modal = document.createElement('div');
            modal.id = 'cropper-modal';
            modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:10000;display:flex;justify-content:center;align-items:center;flex-direction:column;';
            
            const modalContent = document.createElement('div');
            modalContent.style.cssText = 'background:white;padding:20px;border-radius:8px;max-width:90%;max-height:90%;overflow:auto;';
            
            const title = document.createElement('h3');
            title.textContent = 'Crop Image';
            title.style.marginTop = '0';
            
            const imgContainer = document.createElement('div');
            imgContainer.style.cssText = 'max-width:100%;max-height:400px;overflow:hidden;margin:15px 0;';
            
            const img = document.createElement('img');
            img.src = imgData;
            img.id = 'cropper-image';
            img.style.cssText = 'max-width:100%;max-height:400px;';
            
            imgContainer.appendChild(img);
            
            // Crop controls
            const controls = document.createElement('div');
            controls.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap;margin-bottom:15px;';
            
            const aspectLabel = document.createElement('label');
            aspectLabel.textContent = 'Aspect Ratio: ';
            controls.appendChild(aspectLabel);
            
            const aspectSelect = document.createElement('select');
            aspectSelect.id = 'aspect-ratio';
            aspectSelect.style.cssText = 'padding:5px;margin-bottom:5px;';
            aspectSelect.innerHTML = `
                <option value="0">Free</option>
                <option value="1">1:1</option>
                <option value="4/3">4:3</option>
                <option value="16/9">16:9</option>
                <option value="3/4">3:4</option>
            `;
            controls.appendChild(aspectSelect);
            
            const buttonGroup = document.createElement('div');
            buttonGroup.style.cssText = 'display:flex;gap:10px;margin-top:10px;';
            
            const cropBtn = document.createElement('button');
            cropBtn.textContent = 'Apply Crop';
            cropBtn.className = 'btn btn-primary';
            cropBtn.onclick = function() { AdminEditor.applyCrop(img, type, index, modal); };
            
            const cancelBtn = document.createElement('button');
            cancelBtn.textContent = 'Cancel';
            cancelBtn.className = 'btn btn-secondary';
            cancelBtn.onclick = function() { modal.remove(); };
            
            const resetBtn = document.createElement('button');
            resetBtn.textContent = 'Reset';
            resetBtn.className = 'btn btn-secondary';
            resetBtn.onclick = function() { 
                if (img.cropper) {
                    img.cropper.reset();
                }
            };
            
            buttonGroup.appendChild(cropBtn);
            buttonGroup.appendChild(resetBtn);
            buttonGroup.appendChild(cancelBtn);
            
            modalContent.appendChild(title);
            modalContent.appendChild(controls);
            modalContent.appendChild(imgContainer);
            modalContent.appendChild(buttonGroup);
            modal.appendChild(modalContent);
            document.body.appendChild(modal);
            
            // Initialize Cropper.js if available, otherwise use simple crop
            if (typeof Cropper !== 'undefined') {
                const cropper = new Cropper(img, {
                    aspectRatio: NaN,
                    viewMode: 1,
                    ready: function() {
                        aspectSelect.addEventListener('change', function() {
                            const value = this.value;
                            if (value === '0') {
                                cropper.setAspectRatio(NaN);
                            } else {
                                cropper.setAspectRatio(eval(value));
                            }
                        });
                    }
                });
                img.cropper = cropper;
            } else {
                // Simple crop without library - use canvas
                AdminEditor.setupSimpleCrop(img, modal, type, index);
            }
        };
        reader.readAsDataURL(file);
    },
    
    /**
     * Setup simple crop without external library
     */
    setupSimpleCrop: function(img, modal, type, index) {
        const modalContent = modal.querySelector('div');
        const imgContainer = modalContent.querySelector('div');
        
        // Add crop coordinates inputs
        const cropControls = document.createElement('div');
        cropControls.id = 'simple-crop-controls';
        cropControls.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:15px 0;';
        cropControls.innerHTML = `
            <div>
                <label>X Position: <input type="number" id="crop-x" value="0" min="0" style="width:60px;"></label>
            </div>
            <div>
                <label>Y Position: <input type="number" id="crop-y" value="0" min="0" style="width:60px;"></label>
            </div>
            <div>
                <label>Width: <input type="number" id="crop-width" value="200" min="50" style="width:60px;"></label>
            </div>
            <div>
                <label>Height: <input type="number" id="crop-height" value="200" min="50" style="width:60px;"></label>
            </div>
        `;
        
        // Insert before button group
        const buttonGroup = modalContent.querySelector('div:last-child');
        modalContent.insertBefore(cropControls, buttonGroup);
        
        // Update crop button
        const cropBtn = buttonGroup.querySelector('button:first-child');
        cropBtn.onclick = function() {
            const x = parseInt(document.getElementById('crop-x').value) || 0;
            const y = parseInt(document.getElementById('crop-y').value) || 0;
            const width = parseInt(document.getElementById('crop-width').value) || 200;
            const height = parseInt(document.getElementById('crop-height').value) || 200;
            
            AdminEditor.applySimpleCrop(img.src, x, y, width, height, type, index, modal);
        };
    },
    
    /**
     * Apply simple crop using canvas
     */
    applySimpleCrop: function(imgData, x, y, width, height, type, index, modal) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        const img = new Image();
        img.onload = function() {
            canvas.width = width;
            canvas.height = height;
            
            // Draw cropped portion
            ctx.drawImage(img, x, y, width, height, 0, 0, width, height);
            
            // Get cropped data as base64
            const croppedData = canvas.toDataURL('image/jpeg', 0.9);
            
            // Update config
            AdminEditor.saveCroppedImage(croppedData, type, index);
            
            // Close modal
            modal.remove();
        };
        img.src = imgData;
    },
    
    /**
     * Apply crop (with Cropper.js)
     */
    applyCrop: function(img, type, index, modal) {
        if (img.cropper) {
            const canvas = img.cropper.getCroppedCanvas({
                maxWidth: 1200,
                maxHeight: 1200,
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });
            
            const croppedData = canvas.toDataURL('image/jpeg', 0.9);
            this.saveCroppedImage(croppedData, type, index);
            modal.remove();
        } else {
            // Use simple crop
            this.applySimpleCrop(img.src, 
                parseInt(document.getElementById('crop-x').value) || 0,
                parseInt(document.getElementById('crop-y').value) || 0,
                parseInt(document.getElementById('crop-width').value) || 200,
                parseInt(document.getElementById('crop-height').value) || 200,
                type, index, modal);
        }
    },
    
    /**
     * Save cropped image to config
     */
    saveCroppedImage: function(base64Data, type, index) {
        // In a real implementation, this would upload to server
        // For demo, we'll use the base64 data directly or save locally
        
        console.log('Image cropped:', type, index);
        
        // Update the config based on type
        switch(type) {
            case 'hero':
                this.updateConfig('hero.backgroundImage', base64Data);
                break;
            case 'intro':
                this.updateConfig('introduction.image', base64Data);
                break;
            case 'popup':
                this.updateConfig('popup.image', base64Data);
                break;
            case 'team':
                this.updateConfig('team.members[' + index + '].image', base64Data);
                break;
            case 'gallery':
                this.updateConfig('gallery.images[' + index + '].src', base64Data);
                break;
            case 'client':
                this.updateConfig('clients.items[' + index + '].logo', base64Data);
                break;
        }
        
        this.hasChanges = true;
        this.showNotification('Image cropped and applied!', 'success');
        
        // Re-render to show changes
        this.renderCurrentSection();
    },
    
    /**
     * Upload image
     */
    uploadImage: function(input, type, index) {
        const file = input.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const base64 = e.target.result;
            // In a real implementation, this would upload to server
            // For now, we'll use localStorage for preview
            console.log('Image uploaded:', type, index);
            AdminEditor.showNotification('Image uploaded! In production, this would be saved to the server.', 'info');
        };
        reader.readAsDataURL(file);
    },
    
    /**
     * Preview theme
     */
    previewTheme: function() {
        // Save current config and open preview
        const previewWindow = window.open('index.html', '_blank');
        this.showNotification('Preview will open in a new tab with current settings', 'info');
    },
    
    /**
     * Test popup
     */
    testPopup: function() {
        // Reset popup to show
        localStorage.removeItem('edc_popup_dismissed');
        
        // Open index.html to test
        const previewWindow = window.open('index.html', '_blank');
        this.showNotification('Popup will appear when the page loads', 'info');
    },
    
    /**
     * Test GitHub connection
     */
    async testGitHubConnection() {
        const statusDiv = document.getElementById('github-status');
        statusDiv.innerHTML = '<p>Testing connection...</p>';
        statusDiv.className = 'status-message info';
        
        // Update config from inputs
        this.config.github.repoUrl = document.getElementById('github-repo').value;
        this.config.github.token = document.getElementById('github-token').value;
        
        GitHubPublisher.setConfig(this.config.github);
        const result = await GitHubPublisher.testConnection();
        
        if (result.success) {
            statusDiv.innerHTML = `<p class="success">✓ ${result.message}</p>`;
            statusDiv.className = 'status-message success';
        } else {
            statusDiv.innerHTML = `<p class="error">✗ ${result.message}</p>`;
            statusDiv.className = 'status-message error';
        }
    },
    
    /**
     * Publish to GitHub
     */
    async publishToGitHub() {
        // First save config
        await this.saveConfig(false);
        
        const statusDiv = document.getElementById('github-status');
        statusDiv.innerHTML = '<p>Publishing to GitHub...</p>';
        statusDiv.className = 'status-message info';
        
        // Update config from inputs
        this.config.github.repoUrl = document.getElementById('github-repo').value;
        this.config.github.token = document.getElementById('github-token').value;
        this.config.github.branch = document.getElementById('github-branch').value;
        
        GitHubPublisher.setConfig(this.config.github);
        
        const files = [
            { path: 'index.html', message: 'Update index.html' },
            { path: 'data/site-config.json', message: 'Update site configuration' },
            { path: 'css/style.css', message: 'Update styles' }
        ];
        
        GitHubPublisher.publish(
            files,
            (progress) => {
                statusDiv.innerHTML = `<p>${progress}</p>`;
            },
            (results) => {
                const allSuccess = results.every(r => r.success);
                if (allSuccess) {
                    statusDiv.innerHTML = '<p class="success">✓ All files published successfully!</p>';
                    statusDiv.className = 'status-message success';
                } else {
                    const errors = results.filter(r => !r.success).map(r => r.error).join(', ');
                    statusDiv.innerHTML = `<p class="error">✗ Some files failed: ${errors}</p>`;
                    statusDiv.className = 'status-message error';
                }
            },
            (error) => {
                statusDiv.innerHTML = `<p class="error">✗ ${error}</p>`;
                statusDiv.className = 'status-message error';
            }
        );
    },
    
    /**
     * Preview site
     */
    previewSite: function() {
        // Save current config
        this.saveConfig(false).then(() => {
            window.open('index.html', '_blank');
        });
    },
    
    /**
     * Setup auto-save
     */
    setupAutoSave: function() {
        // Auto-save every 5 minutes
        setInterval(() => {
            if (this.hasChanges) {
                this.saveConfig(false);
                console.log('Auto-saved configuration');
            }
        }, 300000);
    },
    
    /**
     * Show notification
     */
    showNotification: function(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    },
    
    /**
     * Convert hex to rgba
     */
    hexToRgba: function(hex) {
        if (hex.startsWith('rgba')) return hex;
        
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        
        return `rgba(${r}, ${g}, ${b}, 0.85)`;
    }
};

// Make globally available
window.AdminEditor = AdminEditor;



Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #50

_2026-03-12 06:37:03Z_

I can see the issue now. The `switchContentTab` function is defined correctly in the AdminEditor object, but there might be a scope issue. Let me also check the server.js for the 404 error:

<minimax:tool_call>
<read_file>
<path>c:/Users/ACER/Desktop/EDC,LTD/server.js</path>
</read_file>

## 💬 User #51

_2026-03-12 06:37:03Z_

[read_file for 'c:/Users/ACER/Desktop/EDC,LTD/server.js'] Result:

/**
 * ============================================
 * EDC WEBSITE BACKEND SERVER
 * Local server for handling admin operations
 * ============================================
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(__dirname));

// Ensure data and images directories exist
const dataDir = path.join(__dirname, 'data');
const imagesDir = path.join(__dirname, 'images');

if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

if (!fs.existsSync(imagesDir)) {
    fs.mkdirSync(imagesDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let dest = imagesDir;
        
        // Create subdirectories if needed
        if (file.fieldname === 'gallery') {
            dest = path.join(imagesDir, 'gallery');
            if (!fs.existsSync(dest)) {
                fs.mkdirSync(dest, { recursive: true });
            }
        } else if (file.fieldname === 'team') {
            dest = imagesDir;
        }
        
        cb(null, dest);
    },
    filename: function (req, file, cb) {
        // Generate unique filename
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        let filename = file.fieldname + '-' + uniqueSuffix + ext;
        
        // If team member, use team1, team2, etc.
        if (file.fieldname === 'team' && req.body.teamIndex !== undefined) {
            filename = 'team' + (parseInt(req.body.teamIndex) + 1) + ext;
        }
        
        cb(null, filename);
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: function (req, file, cb) {
        // Allow all common image types
        const allowedTypes = /jpeg|jpg|png|gif|webp|svg|bmp|tiff|ico|avif|heic|heif/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed!'));
        }
    }
});

// ============================================
// API ROUTES
// ============================================

// Get site configuration
app.get('/api/config', (req, res) => {
    const configPath = path.join(dataDir, 'site-config.json');
    
    fs.readFile(configPath, 'utf8', (err, data) => {
        if (err) {
            // If config doesn't exist, create default
            const defaultConfig = getDefaultConfig();
            fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
                if (err) {
                    return res.status(500).json({ error: 'Failed to create config' });
                }
                return res.json(defaultConfig);
            });
        } else {
            try {
                const config = JSON.parse(data);
                res.json(config);
            } catch (parseError) {
                res.status(500).json({ error: 'Invalid JSON in config file' });
            }
        }
    });
});

// Save site configuration
app.post('/api/save-config', (req, res) => {
    const configPath = path.join(dataDir, 'site-config.json');
    const config = req.body;
    
    // Add timestamp
    config.lastUpdated = new Date().toISOString();
    
    fs.writeFile(configPath, JSON.stringify(config, null, 2), (err) => {
        if (err) {
            console.error('Error saving config:', err);
            return res.status(500).json({ error: 'Failed to save configuration' });
        }
        
        console.log('Configuration saved successfully');
        res.json({ success: true, message: 'Configuration saved' });
    });
});

// Upload single image
app.post('/api/upload-image', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    res.json({ 
        success: true, 
        filename: req.file.filename,
        path: 'images/' + req.file.filename
    });
});

// Upload multiple images (gallery)
app.post('/api/upload-gallery', upload.array('images', 20), (req, res) => {
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
    }
    
    const filenames = req.files.map(file => ({
        filename: file.filename,
        path: 'images/gallery/' + file.filename
    }));
    
    res.json({ success: true, files: filenames });
});

// Upload team member photo
app.post('/api/upload-team', upload.single('photo'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const teamIndex = req.body.teamIndex || 0;
    const ext = path.extname(req.file.originalname);
    const newFilename = 'team' + (parseInt(teamIndex) + 1) + ext;
    
    // Rename file to team1.jpg, team2.jpg, etc.
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, newFilename);
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: newFilename,
            path: 'images/' + newFilename
        });
    });
});

// Upload hero image
app.post('/api/upload-hero', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Rename to hero.jpg
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, 'hero.jpg');
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: 'hero.jpg',
            path: 'images/hero.jpg'
        });
    });
});

// Upload intro image
app.post('/api/upload-intro', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Rename to intro.jpg
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, 'intro.jpg');
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: 'intro.jpg',
            path: 'images/intro.jpg'
        });
    });
});

// Upload popup image
app.post('/api/upload-popup', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Rename to popup.jpg
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, 'popup.jpg');
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: 'popup.jpg',
            path: 'images/popup.jpg'
        });
    });
});

// List all images
app.get('/api/images', (req, res) => {
    const images = [];
    
    function walkDir(dir) {
        if (!fs.existsSync(dir)) return;
        
        const files = fs.readdirSync(dir);
        files.forEach(file => {
            const filePath = path.join(dir, file);
            const stat = fs.statSync(filePath);
            
            if (stat.isDirectory()) {
                walkDir(filePath);
            } else {
                const ext = path.extname(file).toLowerCase();
                if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.tiff', '.ico', '.avif', '.heic', '.heif'].includes(ext)) {
                    images.push({
                        name: file,
                        path: path.relative(__dirname, filePath).replace(/\\/g, '/'),
                        size: stat.size,
                        modified: stat.mtime
                    });
                }
            }
        });
    }
    
    walkDir(imagesDir);
    res.json(images);
});

// Delete image
app.delete('/api/images/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(imagesDir, filename);
    
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found' });
    }
    
    fs.unlink(filePath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to delete file' });
        }
        res.json({ success: true, message: 'File deleted' });
    });
});

// Get file content (for GitHub publishing)
app.get('/api/file/:filename', (req, res) => {
    const filename = req.params.filename;
    let filePath;
    
    if (filename === 'index.html') {
        filePath = path.join(__dirname, 'index.html');
    } else if (filename === 'style.css') {
        filePath = path.join(__dirname, 'css', 'style.css');
    } else if (filename === 'site-config.json') {
        filePath = path.join(dataDir, 'site-config.json');
    } else {
        filePath = path.join(__dirname, filename);
    }
    
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found' });
    }
    
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to read file' });
        }
        res.send(data);
    });
});

// Save file content
app.post('/api/save-file', (req, res) => {
    const { filename, content } = req.body;
    
    if (!filename || content === undefined) {
        return res.status(400).json({ error: 'Missing filename or content' });
    }
    
    let filePath;
    
    if (filename === 'index.html') {
        filePath = path.join(__dirname, 'index.html');
    } else if (filename === 'style.css') {
        filePath = path.join(__dirname, 'css', 'style.css');
    } else if (filename === 'site-config.json') {
        filePath = path.join(dataDir, 'site-config.json');
    } else {
        filePath = path.join(__dirname, filename);
    }
    
    // Ensure directory exists
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFile(filePath, content, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to save file' });
        }
        res.json({ success: true, message: 'File saved' });
    });
});

// Reset configuration to default
app.post('/api/reset-config', (req, res) => {
    const configPath = path.join(dataDir, 'site-config.json');
    const defaultConfig = getDefaultConfig();
    
    fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to reset configuration' });
        }
        res.json({ success: true, message: 'Configuration reset to default' });
    });
});

// Serve admin.html
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Serve index.html (default)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// ============================================
// DEFAULT CONFIGURATION
// ============================================

function getDefaultConfig() {
    return {
        site: {
            name: "English Development Consultants Co. Ltd.",
            description: "Education consulting and teacher recruitment in Thailand",
            logo: "images/logo.png",
            favicon: "images/favicon.png"
        },
        navigation: {
            enabled: true,
            logo: {
                text: "EDC",
                link: "index.html"
            },
            menu: [
                { text: "Home", link: "#home", order: 1 },
                { text: "Introduction", link: "#introduction", order: 2 },
                { text: "Company Overview", link: "#overview", order: 3 },
                { text: "Services", link: "#services", order: 4 },
                { text: "Clients", link: "#clients", order: 5 },
                { text: "Team", link: "#team", order: 6 },
                { text: "Gallery", link: "#gallery", order: 7 },
                { text: "Contact", link: "#contact", order: 8 }
            ],
            applyButton: {
                text: "Apply Now",
                link: "http://54.252.186.9",
                enabled: true
            },
            style: {
                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                fontSize: "16px",
                textColor: "#1a202c",
                backgroundColor: "#ffffff",
                hoverColor: "#38a169",
                mobileStyle: "hamburger"
            }
        },
        hero: {
            enabled: true,
            title: "English Development Consultants Co. Ltd.",
            tagline: "Be Part of Our Team",
            buttonText: "Apply Now",
            buttonLink: "http://54.252.186.9",
            backgroundImage: "images/hero.jpg",
            overlayColor: "rgba(26, 54, 93, 0.85)",
            textColor: "#ffffff"
        },
        introduction: {
            enabled: true,
            title: "Welcome to EDC",
            content: [
                "English Development Consultants Co. Ltd. (EDC) is a leading education consulting and teacher recruitment company operating in Thailand.",
                "With years of experience in the education sector, we understand the importance of quality English language education.",
                "Partner with us to transform English language education in Thailand."
            ],
            image: "images/intro.jpg",
            imageAlt: "EDC Office"
        },
        overview: {
            enabled: true,
            title: "Company Overview",
            subtitle: "Our core values drive everything we do",
            mission: {
                title: "Our Mission",
                icon: "🎯",
                content: "To provide exceptional education consulting services and recruit highly qualified English language teachers."
            },
            vision: {
                title: "Our Vision",
                icon: "👁️",
                content: "To become the most trusted education consulting company in Thailand and Southeast Asia."
            }
        },
        services: {
            enabled: true,
            title: "Our Services",
            subtitle: "Comprehensive solutions for all your education needs",
            items: [
                { title: "Teacher Recruitment", icon: "👨‍🏫", content: "We specialize in recruiting qualified English teachers from around the world." },
                { title: "Training Programs", icon: "📚", content: "We offer comprehensive training programs for teachers." },
                { title: "Educational Consulting", icon: "💼", content: "Our expert consultants provide guidance on curriculum development." },
                { title: "Curriculum Support", icon: "📋", content: "We assist educational institutions in developing English language curricula." }
            ]
        },
        clients: {
            enabled: true,
            title: "Our Clients",
            subtitle: "Trusted by leading educational institutions",
            items: [
                { name: "School 1", logo: "" },
                { name: "School 2", logo: "" },
                { name: "School 3", logo: "" },
                { name: "School 4", logo: "" }
            ]
        },
        team: {
            enabled: true,
            title: "Our Team",
            subtitle: "Meet the dedicated professionals behind EDC",
            members: [
                { name: "John Smith", position: "Managing Director", image: "images/team1.jpg" },
                { name: "Sarah Johnson", position: "Head of Recruitment", image: "images/team2.jpg" },
                { name: "Michael Chen", position: "Training Coordinator", image: "images/team3.jpg" },
                { name: "Emily Davis", position: "Consultant", image: "images/team4.jpg" }
            ]
        },
        gallery: {
            enabled: true,
            title: "Gallery",
            subtitle: "Highlights from our programs and activities",
            images: [
                { src: "images/gallery/1.jpg", alt: "Gallery Image 1" },
                { src: "images/gallery/2.jpg", alt: "Gallery Image 2" },
                { src: "images/gallery/3.jpg", alt: "Gallery Image 3" },
                { src: "images/gallery/4.jpg", alt: "Gallery Image 4" },
                { src: "images/gallery/5.jpg", alt: "Gallery Image 5" },
                { src: "images/gallery/6.jpg", alt: "Gallery Image 6" },
                { src: "images/gallery/7.jpg", alt: "Gallery Image 7" },
                { src: "images/gallery/8.jpg", alt: "Gallery Image 8" }
            ]
        },
        contact: {
            enabled: true,
            title: "Contact Us",
            subtitle: "Get in touch with us for inquiries",
            company: "English Development Consultants Co. Ltd.",
            phone: "+66 2 123 4567",
            email: "info@edc-thailand.com",
            address: "Bangkok, Thailand",
            form: { enabled: true, emailTo: "info@edc-thailand.com" }
        },
        footer: {
            enabled: true,
            about: {
                title: "About EDC",
                content: "English Development Consultants Co. Ltd. is a leading education consulting and teacher recruitment company in Thailand."
            },
            quickLinks: [
                { text: "Home", link: "#home" },
                { text: "Services", link: "#services" },
                { text: "Contact", link: "#contact" }
            ],
            services: [
                { text: "Teacher Recruitment", link: "#services" },
                { text: "Training Programs", link: "#services" }
            ],
            social: { facebook: "#", twitter: "#", linkedin: "#", instagram: "#" },
            copyright: "© 2024 English Development Consultants Co. Ltd. All rights reserved."
        },
        popup: {
            enabled: false,
            title: "Welcome to EDC!",
            description: "Join our team of dedicated educators and make a difference in English language education in Thailand.",
            image: "images/popup.jpg",
            buttonText: "Learn More",
            buttonLink: "#introduction",
            backgroundColor: "rgba(26, 54, 93, 0.95)",
            textColor: "#ffffff",
            buttonColor: "#38a169",
            showAgainDuration: 1
        },
        theme: {
            colors: {
                primary: "#1a365d",
                primaryLight: "#2c5282",
                primaryDark: "#0d1b2a",
                secondary: "#38a169",
                secondaryLight: "#48bb78",
                secondaryDark: "#276749",
                backgroundLight: "#f7fafc",
                backgroundWhite: "#ffffff",
                textDark: "#1a202c",
                textGray: "#4a5568",
                textLight: "#718096",
                borderColor: "#e2e8f0"
            },
            fonts: {
                primary: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                headings: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
            },
            buttons: {
                primary: "#1a365d",
                secondary: "#38a169",
                hover: "#2c5282"
            }
        },
        github: {
            repoUrl: "",
            username: "",
            token: "",
            branch: "main"
        },
        lastUpdated: new Date().toISOString()
    };
}

// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   EDC Website Server                                       ║
║   Running at: http://localhost:${PORT}                       ║
║                                                            ║
║   Public Website: http://localhost:${PORT}/index.html       ║
║   Admin Panel:    http://localhost:${PORT}/admin.html       ║
║                                                            ║
║   Press Ctrl+C to stop the server                          ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
    `);
});



Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #52

_2026-03-12 06:37:03Z_

Now I understand the issues. Let me fix them:

1. **404 Error**: The server needs a catch-all route
2. **JavaScript Error**: The `switchContentTab` function needs to properly reference `this`

Let me fix the server.js first to handle all routes:

<minimax:tool_call>
<edit_file>
<path>c:/Users/ACER/Desktop/EDC,LTD/server.js</path>
<content>
<<<<<<< SEARCH
// Serve index.html (default)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});
=======
// Serve index.html (default)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Catch-all route for any other path - serve index.html
app.get('*', (req, res) => {
    const filePath = path.join(__dirname, req.path);
    
    // Check if file exists
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        return res.sendFile(filePath);
    }
    
    // Otherwise serve index.html for SPA-like behavior
    res.sendFile(path.join(__dirname, 'index.html'));
});
>>>>>>> REPLACE
</content>
</edit_file>

## 💬 User #53

_2026-03-12 06:37:03Z_

[edit_file for 'c:/Users/ACER/Desktop/EDC,LTD/server.js'] Result:

The content was successfully saved to c:/Users/ACER/Desktop/EDC,LTD/server.js.[Please review the changes carefully and make sure they are correct  You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build. Edit the file again if necessary.][Diff of the changes applied]
@@ -1,609 +1,621 @@
-/**
- * ============================================
- * EDC WEBSITE BACKEND SERVER
- * Local server for handling admin operations
- * ============================================
- */
-
-const express = require('express');
-const cors = require('cors');
-const fs = require('fs');
-const path = require('path');
-const multer = require('multer');
-const bodyParser = require('body-parser');
-
-const app = express();
-const PORT = process.env.PORT || 3000;
-
-// Middleware
-app.use(cors());
-app.use(bodyParser.json({ limit: '50mb' }));
-app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
-app.use(express.static(__dirname));
-
-// Ensure data and images directories exist
-const dataDir = path.join(__dirname, 'data');
-const imagesDir = path.join(__dirname, 'images');
-
-if (!fs.existsSync(dataDir)) {
-    fs.mkdirSync(dataDir, { recursive: true });
-}
-
-if (!fs.existsSync(imagesDir)) {
-    fs.mkdirSync(imagesDir, { recursive: true });
-}
-
-// Configure multer for file uploads
-const storage = multer.diskStorage({
-    destination: function (req, file, cb) {
-        let dest = imagesDir;
-        
-        // Create subdirectories if needed
-        if (file.fieldname === 'gallery') {
-            dest = path.join(imagesDir, 'gallery');
-            if (!fs.existsSync(dest)) {
-                fs.mkdirSync(dest, { recursive: true });
-            }
-        } else if (file.fieldname === 'team') {
-            dest = imagesDir;
-        }
-        
-        cb(null, dest);
-    },
-    filename: function (req, file, cb) {
-        // Generate unique filename
-        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
-        const ext = path.extname(file.originalname);
-        let filename = file.fieldname + '-' + uniqueSuffix + ext;
-        
-        // If team member, use team1, team2, etc.
-        if (file.fieldname === 'team' && req.body.teamIndex !== undefined) {
-            filename = 'team' + (parseInt(req.body.teamIndex) + 1) + ext;
-        }
-        
-        cb(null, filename);
-    }
-});
-
-const upload = multer({ 
-    storage: storage,
-    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
-    fileFilter: function (req, file, cb) {
-        // Allow all common image types
-        const allowedTypes = /jpeg|jpg|png|gif|webp|svg|bmp|tiff|ico|avif|heic|heif/;
-        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
-        const mimetype = allowedTypes.test(file.mimetype);
-        
-        if (extname && mimetype) {
-            return cb(null, true);
-        } else {
-            cb(new Error('Only image files are allowed!'));
-        }
-    }
-});
-
-// ============================================
-// API ROUTES
-// ============================================
-
-// Get site configuration
-app.get('/api/config', (req, res) => {
-    const configPath = path.join(dataDir, 'site-config.json');
-    
-    fs.readFile(configPath, 'utf8', (err, data) => {
-        if (err) {
-            // If config doesn't exist, create default
-            const defaultConfig = getDefaultConfig();
-            fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
-                if (err) {
-                    return res.status(500).json({ error: 'Failed to create config' });
-                }
-                return res.json(defaultConfig);
-            });
-        } else {
-            try {
-                const config = JSON.parse(data);
-                res.json(config);
-            } catch (parseError) {
-                res.status(500).json({ error: 'Invalid JSON in config file' });
-            }
-        }
-    });
-});
-
-// Save site configuration
-app.post('/api/save-config', (req, res) => {
-    const configPath = path.join(dataDir, 'site-config.json');
-    const config = req.body;
-    
-    // Add timestamp
-    config.lastUpdated = new Date().toISOString();
-    
-    fs.writeFile(configPath, JSON.stringify(config, null, 2), (err) => {
-        if (err) {
-            console.error('Error saving config:', err);
-            return res.status(500).json({ error: 'Failed to save configuration' });
-        }
-        
-        console.log('Configuration saved successfully');
-        res.json({ success: true, message: 'Configuration saved' });
-    });
-});
-
-// Upload single image
-app.post('/api/upload-image', upload.single('image'), (req, res) => {
-    if (!req.file) {
-        return res.status(400).json({ error: 'No file uploaded' });
-    }
-    
-    res.json({ 
-        success: true, 
-        filename: req.file.filename,
-        path: 'images/' + req.file.filename
-    });
-});
-
-// Upload multiple images (gallery)
-app.post('/api/upload-gallery', upload.array('images', 20), (req, res) => {
-    if (!req.files || req.files.length === 0) {
-        return res.status(400).json({ error: 'No files uploaded' });
-    }
-    
-    const filenames = req.files.map(file => ({
-        filename: file.filename,
-        path: 'images/gallery/' + file.filename
-    }));
-    
-    res.json({ success: true, files: filenames });
-});
-
-// Upload team member photo
-app.post('/api/upload-team', upload.single('photo'), (req, res) => {
-    if (!req.file) {
-        return res.status(400).json({ error: 'No file uploaded' });
-    }
-    
-    const teamIndex = req.body.teamIndex || 0;
-    const ext = path.extname(req.file.originalname);
-    const newFilename = 'team' + (parseInt(teamIndex) + 1) + ext;
-    
-    // Rename file to team1.jpg, team2.jpg, etc.
-    const oldPath = req.file.path;
-    const newPath = path.join(imagesDir, newFilename);
-    
-    fs.rename(oldPath, newPath, (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to rename file' });
-        }
-        
-        res.json({ 
-            success: true, 
-            filename: newFilename,
-            path: 'images/' + newFilename
-        });
-    });
-});
-
-// Upload hero image
-app.post('/api/upload-hero', upload.single('image'), (req, res) => {
-    if (!req.file) {
-        return res.status(400).json({ error: 'No file uploaded' });
-    }
-    
-    // Rename to hero.jpg
-    const oldPath = req.file.path;
-    const newPath = path.join(imagesDir, 'hero.jpg');
-    
-    fs.rename(oldPath, newPath, (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to rename file' });
-        }
-        
-        res.json({ 
-            success: true, 
-            filename: 'hero.jpg',
-            path: 'images/hero.jpg'
-        });
-    });
-});
-
-// Upload intro image
-app.post('/api/upload-intro', upload.single('image'), (req, res) => {
-    if (!req.file) {
-        return res.status(400).json({ error: 'No file uploaded' });
-    }
-    
-    // Rename to intro.jpg
-    const oldPath = req.file.path;
-    const newPath = path.join(imagesDir, 'intro.jpg');
-    
-    fs.rename(oldPath, newPath, (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to rename file' });
-        }
-        
-        res.json({ 
-            success: true, 
-            filename: 'intro.jpg',
-            path: 'images/intro.jpg'
-        });
-    });
-});
-
-// Upload popup image
-app.post('/api/upload-popup', upload.single('image'), (req, res) => {
-    if (!req.file) {
-        return res.status(400).json({ error: 'No file uploaded' });
-    }
-    
-    // Rename to popup.jpg
-    const oldPath = req.file.path;
-    const newPath = path.join(imagesDir, 'popup.jpg');
-    
-    fs.rename(oldPath, newPath, (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to rename file' });
-        }
-        
-        res.json({ 
-            success: true, 
-            filename: 'popup.jpg',
-            path: 'images/popup.jpg'
-        });
-    });
-});
-
-// List all images
-app.get('/api/images', (req, res) => {
-    const images = [];
-    
-    function walkDir(dir) {
-        if (!fs.existsSync(dir)) return;
-        
-        const files = fs.readdirSync(dir);
-        files.forEach(file => {
-            const filePath = path.join(dir, file);
-            const stat = fs.statSync(filePath);
-            
-            if (stat.isDirectory()) {
-                walkDir(filePath);
-            } else {
-                const ext = path.extname(file).toLowerCase();
-                if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.tiff', '.ico', '.avif', '.heic', '.heif'].includes(ext)) {
-                    images.push({
-                        name: file,
-                        path: path.relative(__dirname, filePath).replace(/\\/g, '/'),
-                        size: stat.size,
-                        modified: stat.mtime
-                    });
-                }
-            }
-        });
-    }
-    
-    walkDir(imagesDir);
-    res.json(images);
-});
-
-// Delete image
-app.delete('/api/images/:filename', (req, res) => {
-    const filename = req.params.filename;
-    const filePath = path.join(imagesDir, filename);
-    
-    if (!fs.existsSync(filePath)) {
-        return res.status(404).json({ error: 'File not found' });
-    }
-    
-    fs.unlink(filePath, (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to delete file' });
-        }
-        res.json({ success: true, message: 'File deleted' });
-    });
-});
-
-// Get file content (for GitHub publishing)
-app.get('/api/file/:filename', (req, res) => {
-    const filename = req.params.filename;
-    let filePath;
-    
-    if (filename === 'index.html') {
-        filePath = path.join(__dirname, 'index.html');
-    } else if (filename === 'style.css') {
-        filePath = path.join(__dirname, 'css', 'style.css');
-    } else if (filename === 'site-config.json') {
-        filePath = path.join(dataDir, 'site-config.json');
-    } else {
-        filePath = path.join(__dirname, filename);
-    }
-    
-    if (!fs.existsSync(filePath)) {
-        return res.status(404).json({ error: 'File not found' });
-    }
-    
-    fs.readFile(filePath, 'utf8', (err, data) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to read file' });
-        }
-        res.send(data);
-    });
-});
-
-// Save file content
-app.post('/api/save-file', (req, res) => {
-    const { filename, content } = req.body;
-    
-    if (!filename || content === undefined) {
-        return res.status(400).json({ error: 'Missing filename or content' });
-    }
-    
-    let filePath;
-    
-    if (filename === 'index.html') {
-        filePath = path.join(__dirname, 'index.html');
-    } else if (filename === 'style.css') {
-        filePath = path.join(__dirname, 'css', 'style.css');
-    } else if (filename === 'site-config.json') {
-        filePath = path.join(dataDir, 'site-config.json');
-    } else {
-        filePath = path.join(__dirname, filename);
-    }
-    
-    // Ensure directory exists
-    const dir = path.dirname(filePath);
-    if (!fs.existsSync(dir)) {
-        fs.mkdirSync(dir, { recursive: true });
-    }
-    
-    fs.writeFile(filePath, content, (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to save file' });
-        }
-        res.json({ success: true, message: 'File saved' });
-    });
-});
-
-// Reset configuration to default
-app.post('/api/reset-config', (req, res) => {
-    const configPath = path.join(dataDir, 'site-config.json');
-    const defaultConfig = getDefaultConfig();
-    
-    fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
-        if (err) {
-            return res.status(500).json({ error: 'Failed to reset configuration' });
-        }
-        res.json({ success: true, message: 'Configuration reset to default' });
-    });
-});
-
-// Serve admin.html
-app.get('/admin', (req, res) => {
-    res.sendFile(path.join(__dirname, 'admin.html'));
-});
-
-// Serve index.html (default)
-app.get('/', (req, res) => {
-    res.sendFile(path.join(__dirname, 'index.html'));
-});
-
-// ============================================
-// DEFAULT CONFIGURATION
-// ============================================
-
-function getDefaultConfig() {
-    return {
-        site: {
-            name: "English Development Consultants Co. Ltd.",
-            description: "Education consulting and teacher recruitment in Thailand",
-            logo: "images/logo.png",
-            favicon: "images/favicon.png"
-        },
-        navigation: {
-            enabled: true,
-            logo: {
-                text: "EDC",
-                link: "index.html"
-            },
-            menu: [
-                { text: "Home", link: "#home", order: 1 },
-                { text: "Introduction", link: "#introduction", order: 2 },
-                { text: "Company Overview", link: "#overview", order: 3 },
-                { text: "Services", link: "#services", order: 4 },
-                { text: "Clients", link: "#clients", order: 5 },
-                { text: "Team", link: "#team", order: 6 },
-                { text: "Gallery", link: "#gallery", order: 7 },
-                { text: "Contact", link: "#contact", order: 8 }
-            ],
-            applyButton: {
-                text: "Apply Now",
-                link: "http://54.252.186.9",
-                enabled: true
-            },
-            style: {
-                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
-                fontSize: "16px",
-                textColor: "#1a202c",
-                backgroundColor: "#ffffff",
-                hoverColor: "#38a169",
-                mobileStyle: "hamburger"
-            }
-        },
-        hero: {
-            enabled: true,
-            title: "English Development Consultants Co. Ltd.",
-            tagline: "Be Part of Our Team",
-            buttonText: "Apply Now",
-            buttonLink: "http://54.252.186.9",
-            backgroundImage: "images/hero.jpg",
-            overlayColor: "rgba(26, 54, 93, 0.85)",
-            textColor: "#ffffff"
-        },
-        introduction: {
-            enabled: true,
-            title: "Welcome to EDC",
-            content: [
-                "English Development Consultants Co. Ltd. (EDC) is a leading education consulting and teacher recruitment company operating in Thailand.",
-                "With years of experience in the education sector, we understand the importance of quality English language education.",
-                "Partner with us to transform English language education in Thailand."
-            ],
-            image: "images/intro.jpg",
-            imageAlt: "EDC Office"
-        },
-        overview: {
-            enabled: true,
-            title: "Company Overview",
-            subtitle: "Our core values drive everything we do",
-            mission: {
-                title: "Our Mission",
-                icon: "🎯",
-                content: "To provide exceptional education consulting services and recruit highly qualified English language teachers."
-            },
-            vision: {
-                title: "Our Vision",
-                icon: "👁️",
-                content: "To become the most trusted education consulting company in Thailand and Southeast Asia."
-            }
-        },
-        services: {
-            enabled: true,
-            title: "Our Services",
-            subtitle: "Comprehensive solutions for all your education needs",
-            items: [
-                { title: "Teacher Recruitment", icon: "👨‍🏫", content: "We specialize in recruiting qualified English teachers from around the world." },
-                { title: "Training Programs", icon: "📚", content: "We offer comprehensive training programs for teachers." },
-                { title: "Educational Consulting", icon: "💼", content: "Our expert consultants provide guidance on curriculum development." },
-                { title: "Curriculum Support", icon: "📋", content: "We assist educational institutions in developing English language curricula." }
-            ]
-        },
-        clients: {
-            enabled: true,
-            title: "Our Clients",
-            subtitle: "Trusted by leading educational institutions",
-            items: [
-                { name: "School 1", logo: "" },
-                { name: "School 2", logo: "" },
-                { name: "School 3", logo: "" },
-                { name: "School 4", logo: "" }
-            ]
-        },
-        team: {
-            enabled: true,
-            title: "Our Team",
-            subtitle: "Meet the dedicated professionals behind EDC",
-            members: [
-                { name: "John Smith", position: "Managing Director", image: "images/team1.jpg" },
-                { name: "Sarah Johnson", position: "Head of Recruitment", image: "images/team2.jpg" },
-                { name: "Michael Chen", position: "Training Coordinator", image: "images/team3.jpg" },
-                { name: "Emily Davis", position: "Consultant", image: "images/team4.jpg" }
-            ]
-        },
-        gallery: {
-            enabled: true,
-            title: "Gallery",
-            subtitle: "Highlights from our programs and activities",
-            images: [
-                { src: "images/gallery/1.jpg", alt: "Gallery Image 1" },
-                { src: "images/gallery/2.jpg", alt: "Gallery Image 2" },
-                { src: "images/gallery/3.jpg", alt: "Gallery Image 3" },
-                { src: "images/gallery/4.jpg", alt: "Gallery Image 4" },
-                { src: "images/gallery/5.jpg", alt: "Gallery Image 5" },
-                { src: "images/gallery/6.jpg", alt: "Gallery Image 6" },
-                { src: "images/gallery/7.jpg", alt: "Gallery Image 7" },
-                { src: "images/gallery/8.jpg", alt: "Gallery Image 8" }
-            ]
-        },
-        contact: {
-            enabled: true,
-            title: "Contact Us",
-            subtitle: "Get in touch with us for inquiries",
-            company: "English Development Consultants Co. Ltd.",
-            phone: "+66 2 123 4567",
-            email: "info@edc-thailand.com",
-            address: "Bangkok, Thailand",
-            form: { enabled: true, emailTo: "info@edc-thailand.com" }
-        },
-        footer: {
-            enabled: true,
-            about: {
-                title: "About EDC",
-                content: "English Development Consultants Co. Ltd. is a leading education consulting and teacher recruitment company in Thailand."
-            },
-            quickLinks: [
-                { text: "Home", link: "#home" },
-                { text: "Services", link: "#services" },
-                { text: "Contact", link: "#contact" }
-            ],
-            services: [
-                { text: "Teacher Recruitment", link: "#services" },
-                { text: "Training Programs", link: "#services" }
-            ],
-            social: { facebook: "#", twitter: "#", linkedin: "#", instagram: "#" },
-            copyright: "© 2024 English Development Consultants Co. Ltd. All rights reserved."
-        },
-        popup: {
-            enabled: false,
-            title: "Welcome to EDC!",
-            description: "Join our team of dedicated educators and make a difference in English language education in Thailand.",
-            image: "images/popup.jpg",
-            buttonText: "Learn More",
-            buttonLink: "#introduction",
-            backgroundColor: "rgba(26, 54, 93, 0.95)",
-            textColor: "#ffffff",
-            buttonColor: "#38a169",
-            showAgainDuration: 1
-        },
-        theme: {
-            colors: {
-                primary: "#1a365d",
-                primaryLight: "#2c5282",
-                primaryDark: "#0d1b2a",
-                secondary: "#38a169",
-                secondaryLight: "#48bb78",
-                secondaryDark: "#276749",
-                backgroundLight: "#f7fafc",
-                backgroundWhite: "#ffffff",
-                textDark: "#1a202c",
-                textGray: "#4a5568",
-                textLight: "#718096",
-                borderColor: "#e2e8f0"
-            },
-            fonts: {
-                primary: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
-                headings: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
-            },
-            buttons: {
-                primary: "#1a365d",
-                secondary: "#38a169",
-                hover: "#2c5282"
-            }
-        },
-        github: {
-            repoUrl: "",
-            username: "",
-            token: "",
-            branch: "main"
-        },
-        lastUpdated: new Date().toISOString()
-    };
-}
-
-// ============================================
-// START SERVER
-// ============================================
-
-app.listen(PORT, () => {
-    console.log(`
-╔════════════════════════════════════════════════════════════╗
-║                                                            ║
-║   EDC Website Server                                       ║
-║   Running at: http://localhost:${PORT}                       ║
-║                                                            ║
-║   Public Website: http://localhost:${PORT}/index.html       ║
-║   Admin Panel:    http://localhost:${PORT}/admin.html       ║
-║                                                            ║
-║   Press Ctrl+C to stop the server                          ║
-║                                                            ║
-╚════════════════════════════════════════════════════════════╝
-    `);
-});
-
+/**
+ * ============================================
+ * EDC WEBSITE BACKEND SERVER
+ * Local server for handling admin operations
+ * ============================================
+ */
+
+const express = require('express');
+const cors = require('cors');
+const fs = require('fs');
+const path = require('path');
+const multer = require('multer');
+const bodyParser = require('body-parser');
+
+const app = express();
+const PORT = process.env.PORT || 3000;
+
+// Middleware
+app.use(cors());
+app.use(bodyParser.json({ limit: '50mb' }));
+app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
+app.use(express.static(__dirname));
+
+// Ensure data and images directories exist
+const dataDir = path.join(__dirname, 'data');
+const imagesDir = path.join(__dirname, 'images');
+
+if (!fs.existsSync(dataDir)) {
+    fs.mkdirSync(dataDir, { recursive: true });
+}
+
+if (!fs.existsSync(imagesDir)) {
+    fs.mkdirSync(imagesDir, { recursive: true });
+}
+
+// Configure multer for file uploads
+const storage = multer.diskStorage({
+    destination: function (req, file, cb) {
+        let dest = imagesDir;
+        
+        // Create subdirectories if needed
+        if (file.fieldname === 'gallery') {
+            dest = path.join(imagesDir, 'gallery');
+            if (!fs.existsSync(dest)) {
+                fs.mkdirSync(dest, { recursive: true });
+            }
+        } else if (file.fieldname === 'team') {
+            dest = imagesDir;
+        }
+        
+        cb(null, dest);
+    },
+    filename: function (req, file, cb) {
+        // Generate unique filename
+        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
+        const ext = path.extname(file.originalname);
+        let filename = file.fieldname + '-' + uniqueSuffix + ext;
+        
+        // If team member, use team1, team2, etc.
+        if (file.fieldname === 'team' && req.body.teamIndex !== undefined) {
+            filename = 'team' + (parseInt(req.body.teamIndex) + 1) + ext;
+        }
+        
+        cb(null, filename);
+    }
+});
+
+const upload = multer({ 
+    storage: storage,
+    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
+    fileFilter: function (req, file, cb) {
+        // Allow all common image types
+        const allowedTypes = /jpeg|jpg|png|gif|webp|svg|bmp|tiff|ico|avif|heic|heif/;
+        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
+        const mimetype = allowedTypes.test(file.mimetype);
+        
+        if (extname && mimetype) {
+            return cb(null, true);
+        } else {
+            cb(new Error('Only image files are allowed!'));
+        }
+    }
+});
+
+// ============================================
+// API ROUTES
+// ============================================
+
+// Get site configuration
+app.get('/api/config', (req, res) => {
+    const configPath = path.join(dataDir, 'site-config.json');
+    
+    fs.readFile(configPath, 'utf8', (err, data) => {
+        if (err) {
+            // If config doesn't exist, create default
+            const defaultConfig = getDefaultConfig();
+            fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
+                if (err) {
+                    return res.status(500).json({ error: 'Failed to create config' });
+                }
+                return res.json(defaultConfig);
+            });
+        } else {
+            try {
+                const config = JSON.parse(data);
+                res.json(config);
+            } catch (parseError) {
+                res.status(500).json({ error: 'Invalid JSON in config file' });
+            }
+        }
+    });
+});
+
+// Save site configuration
+app.post('/api/save-config', (req, res) => {
+    const configPath = path.join(dataDir, 'site-config.json');
+    const config = req.body;
+    
+    // Add timestamp
+    config.lastUpdated = new Date().toISOString();
+    
+    fs.writeFile(configPath, JSON.stringify(config, null, 2), (err) => {
+        if (err) {
+            console.error('Error saving config:', err);
+            return res.status(500).json({ error: 'Failed to save configuration' });
+        }
+        
+        console.log('Configuration saved successfully');
+        res.json({ success: true, message: 'Configuration saved' });
+    });
+});
+
+// Upload single image
+app.post('/api/upload-image', upload.single('image'), (req, res) => {
+    if (!req.file) {
+        return res.status(400).json({ error: 'No file uploaded' });
+    }
+    
+    res.json({ 
+        success: true, 
+        filename: req.file.filename,
+        path: 'images/' + req.file.filename
+    });
+});
+
+// Upload multiple images (gallery)
+app.post('/api/upload-gallery', upload.array('images', 20), (req, res) => {
+    if (!req.files || req.files.length === 0) {
+        return res.status(400).json({ error: 'No files uploaded' });
+    }
+    
+    const filenames = req.files.map(file => ({
+        filename: file.filename,
+        path: 'images/gallery/' + file.filename
+    }));
+    
+    res.json({ success: true, files: filenames });
+});
+
+// Upload team member photo
+app.post('/api/upload-team', upload.single('photo'), (req, res) => {
+    if (!req.file) {
+        return res.status(400).json({ error: 'No file uploaded' });
+    }
+    
+    const teamIndex = req.body.teamIndex || 0;
+    const ext = path.extname(req.file.originalname);
+    const newFilename = 'team' + (parseInt(teamIndex) + 1) + ext;
+    
+    // Rename file to team1.jpg, team2.jpg, etc.
+    const oldPath = req.file.path;
+    const newPath = path.join(imagesDir, newFilename);
+    
+    fs.rename(oldPath, newPath, (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to rename file' });
+        }
+        
+        res.json({ 
+            success: true, 
+            filename: newFilename,
+            path: 'images/' + newFilename
+        });
+    });
+});
+
+// Upload hero image
+app.post('/api/upload-hero', upload.single('image'), (req, res) => {
+    if (!req.file) {
+        return res.status(400).json({ error: 'No file uploaded' });
+    }
+    
+    // Rename to hero.jpg
+    const oldPath = req.file.path;
+    const newPath = path.join(imagesDir, 'hero.jpg');
+    
+    fs.rename(oldPath, newPath, (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to rename file' });
+        }
+        
+        res.json({ 
+            success: true, 
+            filename: 'hero.jpg',
+            path: 'images/hero.jpg'
+        });
+    });
+});
+
+// Upload intro image
+app.post('/api/upload-intro', upload.single('image'), (req, res) => {
+    if (!req.file) {
+        return res.status(400).json({ error: 'No file uploaded' });
+    }
+    
+    // Rename to intro.jpg
+    const oldPath = req.file.path;
+    const newPath = path.join(imagesDir, 'intro.jpg');
+    
+    fs.rename(oldPath, newPath, (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to rename file' });
+        }
+        
+        res.json({ 
+            success: true, 
+            filename: 'intro.jpg',
+            path: 'images/intro.jpg'
+        });
+    });
+});
+
+// Upload popup image
+app.post('/api/upload-popup', upload.single('image'), (req, res) => {
+    if (!req.file) {
+        return res.status(400).json({ error: 'No file uploaded' });
+    }
+    
+    // Rename to popup.jpg
+    const oldPath = req.file.path;
+    const newPath = path.join(imagesDir, 'popup.jpg');
+    
+    fs.rename(oldPath, newPath, (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to rename file' });
+        }
+        
+        res.json({ 
+            success: true, 
+            filename: 'popup.jpg',
+            path: 'images/popup.jpg'
+        });
+    });
+});
+
+// List all images
+app.get('/api/images', (req, res) => {
+    const images = [];
+    
+    function walkDir(dir) {
+        if (!fs.existsSync(dir)) return;
+        
+        const files = fs.readdirSync(dir);
+        files.forEach(file => {
+            const filePath = path.join(dir, file);
+            const stat = fs.statSync(filePath);
+            
+            if (stat.isDirectory()) {
+                walkDir(filePath);
+            } else {
+                const ext = path.extname(file).toLowerCase();
+                if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.tiff', '.ico', '.avif', '.heic', '.heif'].includes(ext)) {
+                    images.push({
+                        name: file,
+                        path: path.relative(__dirname, filePath).replace(/\\/g, '/'),
+                        size: stat.size,
+                        modified: stat.mtime
+                    });
+                }
+            }
+        });
+    }
+    
+    walkDir(imagesDir);
+    res.json(images);
+});
+
+// Delete image
+app.delete('/api/images/:filename', (req, res) => {
+    const filename = req.params.filename;
+    const filePath = path.join(imagesDir, filename);
+    
+    if (!fs.existsSync(filePath)) {
+        return res.status(404).json({ error: 'File not found' });
+    }
+    
+    fs.unlink(filePath, (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to delete file' });
+        }
+        res.json({ success: true, message: 'File deleted' });
+    });
+});
+
+// Get file content (for GitHub publishing)
+app.get('/api/file/:filename', (req, res) => {
+    const filename = req.params.filename;
+    let filePath;
+    
+    if (filename === 'index.html') {
+        filePath = path.join(__dirname, 'index.html');
+    } else if (filename === 'style.css') {
+        filePath = path.join(__dirname, 'css', 'style.css');
+    } else if (filename === 'site-config.json') {
+        filePath = path.join(dataDir, 'site-config.json');
+    } else {
+        filePath = path.join(__dirname, filename);
+    }
+    
+    if (!fs.existsSync(filePath)) {
+        return res.status(404).json({ error: 'File not found' });
+    }
+    
+    fs.readFile(filePath, 'utf8', (err, data) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to read file' });
+        }
+        res.send(data);
+    });
+});
+
+// Save file content
+app.post('/api/save-file', (req, res) => {
+    const { filename, content } = req.body;
+    
+    if (!filename || content === undefined) {
+        return res.status(400).json({ error: 'Missing filename or content' });
+    }
+    
+    let filePath;
+    
+    if (filename === 'index.html') {
+        filePath = path.join(__dirname, 'index.html');
+    } else if (filename === 'style.css') {
+        filePath = path.join(__dirname, 'css', 'style.css');
+    } else if (filename === 'site-config.json') {
+        filePath = path.join(dataDir, 'site-config.json');
+    } else {
+        filePath = path.join(__dirname, filename);
+    }
+    
+    // Ensure directory exists
+    const dir = path.dirname(filePath);
+    if (!fs.existsSync(dir)) {
+        fs.mkdirSync(dir, { recursive: true });
+    }
+    
+    fs.writeFile(filePath, content, (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to save file' });
+        }
+        res.json({ success: true, message: 'File saved' });
+    });
+});
+
+// Reset configuration to default
+app.post('/api/reset-config', (req, res) => {
+    const configPath = path.join(dataDir, 'site-config.json');
+    const defaultConfig = getDefaultConfig();
+    
+    fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
+        if (err) {
+            return res.status(500).json({ error: 'Failed to reset configuration' });
+        }
+        res.json({ success: true, message: 'Configuration reset to default' });
+    });
+});
+
+// Serve admin.html
+app.get('/admin', (req, res) => {
+    res.sendFile(path.join(__dirname, 'admin.html'));
+});
+
+// Serve index.html (default)
+app.get('/', (req, res) => {
+    res.sendFile(path.join(__dirname, 'index.html'));
+});
+
+// Catch-all route for any other path - serve index.html
+app.get('*', (req, res) => {
+    const filePath = path.join(__dirname, req.path);
+    
+    // Check if file exists
+    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
+        return res.sendFile(filePath);
+    }
+    
+    // Otherwise serve index.html for SPA-like behavior
+    res.sendFile(path.join(__dirname, 'index.html'));
+});
+
+// ============================================
+// DEFAULT CONFIGURATION
+// ============================================
+
+function getDefaultConfig() {
+    return {
+        site: {
+            name: "English Development Consultants Co. Ltd.",
+            description: "Education consulting and teacher recruitment in Thailand",
+            logo: "images/logo.png",
+            favicon: "images/favicon.png"
+        },
+        navigation: {
+            enabled: true,
+            logo: {
+                text: "EDC",
+                link: "index.html"
+            },
+            menu: [
+                { text: "Home", link: "#home", order: 1 },
+                { text: "Introduction", link: "#introduction", order: 2 },
+                { text: "Company Overview", link: "#overview", order: 3 },
+                { text: "Services", link: "#services", order: 4 },
+                { text: "Clients", link: "#clients", order: 5 },
+                { text: "Team", link: "#team", order: 6 },
+                { text: "Gallery", link: "#gallery", order: 7 },
+                { text: "Contact", link: "#contact", order: 8 }
+            ],
+            applyButton: {
+                text: "Apply Now",
+                link: "http://54.252.186.9",
+                enabled: true
+            },
+            style: {
+                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
+                fontSize: "16px",
+                textColor: "#1a202c",
+                backgroundColor: "#ffffff",
+                hoverColor: "#38a169",
+                mobileStyle: "hamburger"
+            }
+        },
+        hero: {
+            enabled: true,
+            title: "English Development Consultants Co. Ltd.",
+            tagline: "Be Part of Our Team",
+            buttonText: "Apply Now",
+            buttonLink: "http://54.252.186.9",
+            backgroundImage: "images/hero.jpg",
+            overlayColor: "rgba(26, 54, 93, 0.85)",
+            textColor: "#ffffff"
+        },
+        introduction: {
+            enabled: true,
+            title: "Welcome to EDC",
+            content: [
+                "English Development Consultants Co. Ltd. (EDC) is a leading education consulting and teacher recruitment company operating in Thailand.",
+                "With years of experience in the education sector, we understand the importance of quality English language education.",
+                "Partner with us to transform English language education in Thailand."
+            ],
+            image: "images/intro.jpg",
+            imageAlt: "EDC Office"
+        },
+        overview: {
+            enabled: true,
+            title: "Company Overview",
+            subtitle: "Our core values drive everything we do",
+            mission: {
+                title: "Our Mission",
+                icon: "🎯",
+                content: "To provide exceptional education consulting services and recruit highly qualified English language teachers."
+            },
+            vision: {
+                title: "Our Vision",
+                icon: "👁️",
+                content: "To become the most trusted education consulting company in Thailand and Southeast Asia."
+            }
+        },
+        services: {
+            enabled: true,
+            title: "Our Services",
+            subtitle: "Comprehensive solutions for all your education needs",
+            items: [
+                { title: "Teacher Recruitment", icon: "👨‍🏫", content: "We specialize in recruiting qualified English teachers from around the world." },
+                { title: "Training Programs", icon: "📚", content: "We offer comprehensive training programs for teachers." },
+                { title: "Educational Consulting", icon: "💼", content: "Our expert consultants provide guidance on curriculum development." },
+                { title: "Curriculum Support", icon: "📋", content: "We assist educational institutions in developing English language curricula." }
+            ]
+        },
+        clients: {
+            enabled: true,
+            title: "Our Clients",
+            subtitle: "Trusted by leading educational institutions",
+            items: [
+                { name: "School 1", logo: "" },
+                { name: "School 2", logo: "" },
+                { name: "School 3", logo: "" },
+                { name: "School 4", logo: "" }
+            ]
+        },
+        team: {
+            enabled: true,
+            title: "Our Team",
+            subtitle: "Meet the dedicated professionals behind EDC",
+            members: [
+                { name: "John Smith", position: "Managing Director", image: "images/team1.jpg" },
+                { name: "Sarah Johnson", position: "Head of Recruitment", image: "images/team2.jpg" },
+                { name: "Michael Chen", position: "Training Coordinator", image: "images/team3.jpg" },
+                { name: "Emily Davis", position: "Consultant", image: "images/team4.jpg" }
+            ]
+        },
+        gallery: {
+            enabled: true,
+            title: "Gallery",
+            subtitle: "Highlights from our programs and activities",
+            images: [
+                { src: "images/gallery/1.jpg", alt: "Gallery Image 1" },
+                { src: "images/gallery/2.jpg", alt: "Gallery Image 2" },
+                { src: "images/gallery/3.jpg", alt: "Gallery Image 3" },
+                { src: "images/gallery/4.jpg", alt: "Gallery Image 4" },
+                { src: "images/gallery/5.jpg", alt: "Gallery Image 5" },
+                { src: "images/gallery/6.jpg", alt: "Gallery Image 6" },
+                { src: "images/gallery/7.jpg", alt: "Gallery Image 7" },
+                { src: "images/gallery/8.jpg", alt: "Gallery Image 8" }
+            ]
+        },
+        contact: {
+            enabled: true,
+            title: "Contact Us",
+            subtitle: "Get in touch with us for inquiries",
+            company: "English Development Consultants Co. Ltd.",
+            phone: "+66 2 123 4567",
+            email: "info@edc-thailand.com",
+            address: "Bangkok, Thailand",
+            form: { enabled: true, emailTo: "info@edc-thailand.com" }
+        },
+        footer: {
+            enabled: true,
+            about: {
+                title: "About EDC",
+                content: "English Development Consultants Co. Ltd. is a leading education consulting and teacher recruitment company in Thailand."
+            },
+            quickLinks: [
+                { text: "Home", link: "#home" },
+                { text: "Services", link: "#services" },
+                { text: "Contact", link: "#contact" }
+            ],
+            services: [
+                { text: "Teacher Recruitment", link: "#services" },
+                { text: "Training Programs", link: "#services" }
+            ],
+            social: { facebook: "#", twitter: "#", linkedin: "#", instagram: "#" },
+            copyright: "© 2024 English Development Consultants Co. Ltd. All rights reserved."
+        },
+        popup: {
+            enabled: false,
+            title: "Welcome to EDC!",
+            description: "Join our team of dedicated educators and make a difference in English language education in Thailand.",
+            image: "images/popup.jpg",
+            buttonText: "Learn More",
+            buttonLink: "#introduction",
+            backgroundColor: "rgba(26, 54, 93, 0.95)",
+            textColor: "#ffffff",
+            buttonColor: "#38a169",
+            showAgainDuration: 1
+        },
+        theme: {
+            colors: {
+                primary: "#1a365d",
+                primaryLight: "#2c5282",
+                primaryDark: "#0d1b2a",
+                secondary: "#38a169",
+                secondaryLight: "#48bb78",
+                secondaryDark: "#276749",
+                backgroundLight: "#f7fafc",
+                backgroundWhite: "#ffffff",
+                textDark: "#1a202c",
+                textGray: "#4a5568",
+                textLight: "#718096",
+                borderColor: "#e2e8f0"
+            },
+            fonts: {
+                primary: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
+                headings: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
+            },
+            buttons: {
+                primary: "#1a365d",
+                secondary: "#38a169",
+                hover: "#2c5282"
+            }
+        },
+        github: {
+            repoUrl: "",
+            username: "",
+            token: "",
+            branch: "main"
+        },
+        lastUpdated: new Date().toISOString()
+    };
+}
+
+// ============================================
+// START SERVER
+// ============================================
+
+app.listen(PORT, () => {
+    console.log(`
+╔════════════════════════════════════════════════════════════╗
+║                                                            ║
+║   EDC Website Server                                       ║
+║   Running at: http://localhost:${PORT}                       ║
+║                                                            ║
+║   Public Website: http://localhost:${PORT}/index.html       ║
+║   Admin Panel:    http://localhost:${PORT}/admin.html       ║
+║                                                            ║
+║   Press Ctrl+C to stop the server                          ║
+║                                                            ║
+╚════════════════════════════════════════════════════════════╝
+    `);
+});

[Please review the diff. You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build.]
Important: You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build

Environment details:

# VSCode Visible Files
server.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #54

_2026-03-12 06:37:03Z_

Now let me check the admin.html to see how it loads the JavaScript and ensure there are no issues:

<minimax:tool_call>
<read_file>
<path>c:/Users/ACER/Desktop/EDC,LTD/admin.html</path>
</invoke>

## 💬 User #55

_2026-03-12 06:37:03Z_

[read_file for 'c:/Users/ACER/Desktop/EDC,LTD/admin.html'] Result:

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - EDC Website</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body class="admin-body">
    <!-- Admin Header -->
    <header class="admin-header">
        <div class="admin-header-content">
            <div class="admin-logo">
                <h1>EDC Admin</h1>
                <span class="admin-badge">Dashboard</span>
            </div>
            <div class="admin-actions">
                <button id="preview-btn" class="btn btn-secondary">
                    <span>👁️</span> Preview Site
                </button>
                <button id="save-btn" class="btn btn-primary">
                    <span>💾</span> Save Changes
                </button>
                <button id="reset-btn" class="btn btn-danger">
                    <span>↩️</span> Reset
                </button>
                <a href="index.html" class="btn btn-outline" target="_blank">
                    <span>🌐</span> View Live Site
                </a>
            </div>
        </div>
    </header>

    <!-- Admin Main Layout -->
    <div class="admin-layout">
        <!-- Sidebar Navigation -->
        <aside class="admin-sidebar">
            <nav class="admin-nav">
                <ul class="admin-nav-list">
                    <li>
                        <a href="#" class="admin-nav-item active" data-section="general">
                            <span class="nav-icon">⚙️</span>
                            <span class="nav-text">General Settings</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="navigation">
                            <span class="nav-icon">🔗</span>
                            <span class="nav-text">Navigation</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="hero">
                            <span class="nav-icon">🏠</span>
                            <span class="nav-text">Hero Section</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="content">
                            <span class="nav-icon">📝</span>
                            <span class="nav-text">Content Editor</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="theme">
                            <span class="nav-icon">🎨</span>
                            <span class="nav-text">Theme & Colors</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="images">
                            <span class="nav-icon">🖼️</span>
                            <span class="nav-text">Image Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="popup">
                            <span class="nav-icon">📢</span>
                            <span class="nav-text">Popup Editor</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="admin-nav-item" data-section="github">
                            <span class="nav-icon">📦</span>
                            <span class="nav-text">GitHub Publish</span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div class="admin-sidebar-footer">
                <p>Last saved: <span id="last-saved">Never</span></p>
            </div>
        </aside>

        <!-- Main Content Area -->
        <main class="admin-main">
            <div class="admin-content">
                <div id="editor-content" class="editor-content">
                    <!-- Dynamic content will be loaded here -->
                    <div class="loading-spinner">
                        <div class="spinner"></div>
                        <p>Loading configuration...</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Notification Container -->
    <div id="notifications" class="notifications-container"></div>

    <!-- Scripts -->
    <script src="js/admin-editor.js"></script>
    <script src="js/github-publisher.js"></script>
    <script>
        // Initialize Admin Editor
        document.addEventListener('DOMContentLoaded', function() {
            AdminEditor.init();
        });
    </script>
</body>
</html>



Environment details:

# VSCode Visible Files
server.js

# VSCode Open Tabs
index.html
js/admin-editor.js
server.js

## 🤖 Assistant #56

_2026-03-12 06:37:03Z_

I see the issue now. The `switchContentTab` function is called from inline onclick handlers, but `this` doesn't refer to the AdminEditor object in that context. Let me fix this by making the function use `AdminEditor` directly:

<minimax:tool_call>
<edit_file>
<path>c:/Users/ACER/Desktop/EDC,LTD/js/admin-editor.js</path>
<content>
<<<<<<< SEARCH
    /**
     * Switch content tab
     */
    switchContentTab: function(tab) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });
        
        // Hide all panels
        document.querySelectorAll('.content-tab-panel').forEach(panel => {
            panel.style.display = 'none';
        });
        
        // Show selected panel
        const panel = document.getElementById('tab-' + tab);
        if (panel) {
            panel.style.display = 'block';
        } else {
            // Render the panel if not exists
            const contentArea = document.getElementById('content-editor-area');
            switch(tab) {
                case 'introduction':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'overview':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'services':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'team':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'gallery':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'contact':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'footer':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                case 'clients':
                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
                    break;
                default:
                    contentArea.innerHTML = '<p>Editor coming soon for this section.</p>';
            }
        }
    },
=======
    /**
     * Switch content tab
     */
    switchContentTab: function(tab) {
        const self = AdminEditor;
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });
        
        // Hide all panels
        document.querySelectorAll('.content-tab-panel').forEach(panel => {
            panel.style.display = 'none';
        });
        
        // Show selected panel
        const panel = document.getElementById('tab-' + tab);
        if (panel) {
            panel.style.display = 'block';
        } else {
            // Render the panel if not exists
            const contentArea = document.getElementById('content-editor-area');
            switch(tab) {
                case 'introduction':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'overview':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'services':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'team':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'gallery':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'contact':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'footer':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                case 'clients':
                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
                    break;
                default:
                    contentArea.innerHTML = '<p>Editor coming soon for this section.</p>';
            }
        }
    },
>>>>>>> REPLACE
</content>
</edit_file>

## 💬 User #57

_2026-03-12 06:37:03Z_

[edit_file for 'c:/Users/ACER/Desktop/EDC,LTD/js/admin-editor.js'] Result:

The content was successfully saved to c:/Users/ACER/Desktop/EDC,LTD/js/admin-editor.js.[Please review the changes carefully and make sure they are correct  You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build. Edit the file again if necessary.][Diff of the changes applied]
@@ -1,1802 +1,1802 @@
-/**
- * ============================================
- * ADMIN EDITOR - Visual Content Editor
- * Allows editing all site configuration from admin panel
- * ============================================
- */
-
-const AdminEditor = {
-    config: null,
-    currentSection: 'general',
-    hasChanges: false,
-    
-    /**
-     * Initialize the admin editor
-     */
-    init: async function() {
-        const config = await this.loadConfig();
-        if (!config) {
-            this.showNotification('Error loading configuration. Please ensure the server is running!', 'error');
-            return;
-        }
-        this.setupEventListeners();
-        this.renderCurrentSection();
-        this.setupAutoSave();
-    },
-    
-    /**
-     * Load configuration from server
-     */
-    loadConfig: async function() {
-        try {
-            // Use server API endpoint - works with both server and direct file access
-            // when the server is running
-            const response = await fetch('/api/config');
-            if (!response.ok) {
-                throw new Error('Failed to fetch config');
-            }
-            this.config = await response.json();
-            return this.config;
-        } catch (error) {
-            console.error('Error loading config:', error);
-            this.showNotification('Error loading configuration. Make sure the server is running!', 'error');
-            return null;
-        }
-    },
-    
-    /**
-     * Save configuration to server
-     */
-    saveConfig: async function(showMessage = true) {
-        try {
-            const response = await fetch('/api/save-config', {
-                method: 'POST',
-                headers: {
-                    'Content-Type': 'application/json'
-                },
-                body: JSON.stringify(this.config)
-            });
-            
-            if (!response.ok) {
-                throw new Error('Failed to save configuration');
-            }
-            
-            this.hasChanges = false;
-            if (showMessage) {
-                this.showNotification('Configuration saved successfully!', 'success');
-            }
-            
-            // Update last updated timestamp
-            this.config.lastUpdated = new Date().toISOString();
-            
-            return true;
-        } catch (error) {
-            console.error('Error saving config:', error);
-            this.showNotification('Error saving configuration: ' + error.message, 'error');
-            return false;
-        }
-    },
-    
-    /**
-     * Setup event listeners
-     */
-    setupEventListeners: function() {
-        // Section navigation
-        document.querySelectorAll('.admin-nav-item').forEach(item => {
-            item.addEventListener('click', (e) => {
-                e.preventDefault();
-                const section = item.dataset.section;
-                this.switchSection(section);
-            });
-        });
-        
-        // Save button
-        document.getElementById('save-btn')?.addEventListener('click', () => {
-            this.saveConfig();
-        });
-        
-        // Preview button
-        document.getElementById('preview-btn')?.addEventListener('click', () => {
-            this.previewSite();
-        });
-        
-        // Reset button
-        document.getElementById('reset-btn')?.addEventListener('click', () => {
-            if (confirm('Are you sure you want to reset all changes?')) {
-                this.loadConfig().then(() => {
-                    this.renderCurrentSection();
-                    this.showNotification('Changes reset', 'info');
-                });
-            }
-        });
-        
-        // Handle before unload if there are unsaved changes
-        window.addEventListener('beforeunload', (e) => {
-            if (this.hasChanges) {
-                e.preventDefault();
-                e.returnValue = '';
-            }
-        });
-    },
-    
-    /**
-     * Switch admin section
-     */
-    switchSection: function(section) {
-        // Update active nav item
-        document.querySelectorAll('.admin-nav-item').forEach(item => {
-            item.classList.toggle('active', item.dataset.section === section);
-        });
-        
-        this.currentSection = section;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Render current section
-     */
-    renderCurrentSection: function() {
-        const container = document.getElementById('editor-content');
-        if (!container) return;
-        
-        switch (this.currentSection) {
-            case 'general':
-                container.innerHTML = this.renderGeneralSettings();
-                break;
-            case 'navigation':
-                container.innerHTML = this.renderNavigationSettings();
-                break;
-            case 'hero':
-                container.innerHTML = this.renderHeroSettings();
-                break;
-            case 'content':
-                container.innerHTML = this.renderContentSettings();
-                break;
-            case 'theme':
-                container.innerHTML = this.renderThemeSettings();
-                break;
-            case 'images':
-                container.innerHTML = this.renderImageSettings();
-                break;
-            case 'popup':
-                container.innerHTML = this.renderPopupSettings();
-                break;
-            case 'github':
-                container.innerHTML = this.renderGitHubSettings();
-                break;
-            default:
-                container.innerHTML = '<p>Section not found</p>';
-        }
-        
-        // Setup section-specific event listeners
-        this.setupSectionListeners();
-    },
-    
-    /**
-     * Render General Settings
-     */
-    renderGeneralSettings: function() {
-        return `
-            <h2>General Settings</h2>
-            <div class="form-section">
-                <div class="form-group">
-                    <label>Site Name</label>
-                    <input type="text" id="site-name" value="${this.config.site.name}" onchange="AdminEditor.updateConfig('site.name', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Site Description</label>
-                    <textarea id="site-description" onchange="AdminEditor.updateConfig('site.description', this.value)">${this.config.site.description}</textarea>
-                </div>
-                <div class="form-group">
-                    <label>Logo URL</label>
-                    <input type="text" id="site-logo" value="${this.config.site.logo}" onchange="AdminEditor.updateConfig('site.logo', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Favicon URL</label>
-                    <input type="text" id="site-favicon" value="${this.config.site.favicon}" onchange="AdminEditor.updateConfig('site.favicon', this.value)">
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Navigation Settings
-     */
-    renderNavigationSettings: function() {
-        const nav = this.config.navigation;
-        return `
-            <h2>Navigation Settings</h2>
-            <div class="form-section">
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${nav.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('navigation.enabled', this.checked)">
-                        Enable Navigation
-                    </label>
-                </div>
-                <h3>Logo</h3>
-                <div class="form-group">
-                    <label>Logo Text</label>
-                    <input type="text" value="${nav.logo.text}" onchange="AdminEditor.updateConfig('navigation.logo.text', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Logo Link</label>
-                    <input type="text" value="${nav.logo.link}" onchange="AdminEditor.updateConfig('navigation.logo.link', this.value)">
-                </div>
-                Menu Items</h3>
-                <div id="menu-items-editor">
-                    ${nav.menu.sort((a, b) => a.order - b.order).map((item, index) => `
-                        <div class="menu-item-editor">
-                            <div class="form-row">
-                                <input type="text" placeholder="Text" value="${item.text}" onchange="AdminEditor.updateMenuItem(${index}, 'text', this.value)">
-                                <input type="text" placeholder="Link" value="${item.link}" onchange="AdminEditor.updateMenuItem(${index}, 'link', this.value)">
-                                <input type="number" placeholder="Order" value="${item.order}" min="1" onchange="AdminEditor.updateMenuItem(${index}, 'order', parseInt(this.value))">
-                                <button type="button" class="btn-danger" onclick="AdminEditor.removeMenuItem(${index})">Remove</button>
-                            </div>
-                        </div>
-                    `).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addMenuItem()">+ Add Menu Item</button>
-                
-                <h3>Apply Button</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${nav.applyButton.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('navigation.applyButton.enabled', this.checked)">
-                        Enable Apply Button
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Button Text</label>
-                    <input type="text" value="${nav.applyButton.text}" onchange="AdminEditor.updateConfig('navigation.applyButton.text', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Button Link</label>
-                    <input type="text" value="${nav.applyButton.link}" onchange="AdminEditor.updateConfig('navigation.applyButton.link', this.value)">
-                </div>
-                
-                <h3>Navigation Style</h3>
-                <div class="form-group">
-                    <label>Font Family</label>
-                    <select onchange="AdminEditor.updateConfig('navigation.style.fontFamily', this.value)">
-                        <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" ${nav.style.fontFamily.includes('Segoe UI') ? 'selected' : ''}>Segoe UI</option>
-                        <option value="'Arial', sans-serif" ${nav.style.fontFamily.includes('Arial') ? 'selected' : ''}>Arial</option>
-                        <option value="'Roboto', sans-serif" ${nav.style.fontFamily.includes('Roboto') ? 'selected' : ''}>Roboto</option>
-                        <option value="'Open Sans', sans-serif" ${nav.style.fontFamily.includes('Open Sans') ? 'selected' : ''}>Open Sans</option>
-                    </select>
-                </div>
-                <div class="form-group">
-                    <label>Text Color</label>
-                    <input type="color" value="${nav.style.textColor}" onchange="AdminEditor.updateConfig('navigation.style.textColor', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Background Color</label>
-                    <input type="color" value="${nav.style.backgroundColor}" onchange="AdminEditor.updateConfig('navigation.style.backgroundColor', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Hover Color</label>
-                    <input type="color" value="${nav.style.hoverColor}" onchange="AdminEditor.updateConfig('navigation.style.hoverColor', this.value)">
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Hero Settings
-     */
-    renderHeroSettings: function() {
-        const hero = this.config.hero;
-        return `
-            <h2>Hero Section</h2>
-            <div class="form-section">
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${hero.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('hero.enabled', this.checked)">
-                        Enable Hero Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${hero.title}" onchange="AdminEditor.updateConfig('hero.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Tagline</label>
-                    <input type="text" value="${hero.tagline}" onchange="AdminEditor.updateConfig('hero.tagline', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Button Text</label>
-                    <input type="text" value="${hero.buttonText}" onchange="AdminEditor.updateConfig('hero.buttonText', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Button Link</label>
-                    <input type="text" value="${hero.buttonLink}" onchange="AdminEditor.updateConfig('hero.buttonLink', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Background Image</label>
-                    <input type="text" value="${hero.backgroundImage}" onchange="AdminEditor.updateConfig('hero.backgroundImage', this.value)">
-                    <small>Image path relative to project root</small>
-                </div>
-                <div class="form-group">
-                    <label>Overlay Color</label>
-                    <input type="color" value="${this.hexToRgba(hero.overlayColor)}" onchange="AdminEditor.updateConfig('hero.overlayColor', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Text Color</label>
-                    <input type="color" value="${hero.textColor}" onchange="AdminEditor.updateConfig('hero.textColor', this.value)">
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Content Settings (Introduction, Overview, Services, etc.)
-     */
-    renderContentSettings: function() {
-        return `
-            <h2>Content Editor</h2>
-            
-            <div class="content-tabs">
-                <button class="tab-btn active" data-tab="introduction" onclick="AdminEditor.switchContentTab('introduction')">Introduction</button>
-                <button class="tab-btn" data-tab="overview" onclick="AdminEditor.switchContentTab('overview')">Overview</button>
-                <button class="tab-btn" data-tab="services" onclick="AdminEditor.switchContentTab('services')">Services</button>
-                <button class="tab-btn" data-tab="team" onclick="AdminEditor.switchContentTab('team')">Team</button>
-                <button class="tab-btn" data-tab="clients" onclick="AdminEditor.switchContentTab('clients')">Clients</button>
-                <button class="tab-btn" data-tab="gallery" onclick="AdminEditor.switchContentTab('gallery')">Gallery</button>
-                <button class="tab-btn" data-tab="contact" onclick="AdminEditor.switchContentTab('contact')">Contact</button>
-                <button class="tab-btn" data-tab="footer" onclick="AdminEditor.switchContentTab('footer')">Footer</button>
-            </div>
-            
-            <div id="content-editor-area">
-                ${this.renderIntroductionEditor()}
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Introduction Editor
-     */
-    renderIntroductionEditor: function() {
-        const intro = this.config.introduction;
-        return `
-            <div class="form-section content-tab-panel" id="tab-introduction">
-                <h3>Introduction Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${intro.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('introduction.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${intro.title}" onchange="AdminEditor.updateConfig('introduction.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Content Paragraphs</label>
-                    ${intro.content.map((p, i) => `
-                        <textarea rows="3" onchange="AdminEditor.updateConfig('introduction.content[${i}]', this.value)">${p}</textarea>
-                    `).join('')}
-                </div>
-                <div class="form-group">
-                    <label>Image</label>
-                    <input type="text" value="${intro.image}" onchange="AdminEditor.updateConfig('introduction.image', this.value)">
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Services Editor
-     */
-    renderServicesEditor: function() {
-        const services = this.config.services;
-        const layout = services.layout || { columns: 4, alignment: 'left', itemAlignment: 'left' };
-        return `
-            <div class="form-section content-tab-panel" id="tab-services" style="display:none;">
-                <h3>Services Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${services.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('services.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${services.title}" onchange="AdminEditor.updateConfig('services.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Subtitle</label>
-                    <input type="text" value="${services.subtitle}" onchange="AdminEditor.updateConfig('services.subtitle', this.value)">
-                </div>
-                
-                <!-- Layout Settings -->
-                <div class="layout-settings">
-                    <h4>📐 Layout Settings</h4>
-                    <div class="layout-controls">
-                        <div class="form-group">
-                            <label>Number of Columns</label>
-                            <select onchange="AdminEditor.updateConfig('services.layout.columns', parseInt(this.value))">
-                                <option value="1" ${layout.columns === 1 ? 'selected' : ''}>1 Column</option>
-                                <option value="2" ${layout.columns === 2 ? 'selected' : ''}>2 Columns</option>
-                                <option value="3" ${layout.columns === 3 ? 'selected' : ''}>3 Columns</option>
-                                <option value="4" ${layout.columns === 4 ? 'selected' : ''}>4 Columns</option>
-                            </select>
-                        </div>
-                        <div class="form-group">
-                            <label>Section Alignment</label>
-                            <select onchange="AdminEditor.updateConfig('services.layout.alignment', this.value)">
-                                <option value="left" ${layout.alignment === 'left' ? 'selected' : ''}>Align Left</option>
-                                <option value="center" ${layout.alignment === 'center' ? 'selected' : ''}>Align Center</option>
-                                <option value="right" ${layout.alignment === 'right' ? 'selected' : ''}>Align Right</option>
-                            </select>
-                        </div>
-                        <div class="form-group">
-                            <label>Item Alignment</label>
-                            <select onchange="AdminEditor.updateConfig('services.layout.itemAlignment', this.value)">
-                                <option value="left" ${layout.itemAlignment === 'left' ? 'selected' : ''}>Items Align Left</option>
-                                <option value="center" ${layout.itemAlignment === 'center' ? 'selected' : ''}>Items Align Center</option>
-                                <option value="right" ${layout.itemAlignment === 'right' ? 'selected' : ''}>Items Align Right</option>
-                            </select>
-                        </div>
-                    </div>
-                </div>
-                
-                <h4>Service Items</h4>
-                <div id="services-editor">
-                    ${services.items.map((service, index) => {
-                        const serviceLayout = service.layout || { column: (index % layout.columns) + 1, order: index + 1 };
-                        return `
-                        <div class="item-editor">
-                            <h5>Service ${index + 1}</h5>
-                            <div class="form-group">
-                                <label>Title</label>
-                                <input type="text" value="${service.title}" onchange="AdminEditor.updateConfig('services.items[${index}].title', this.value)">
-                            </div>
-                            <div class="form-group">
-                                <label>Icon (emoji)</label>
-                                <input type="text" value="${service.icon}" onchange="AdminEditor.updateConfig('services.items[${index}].icon', this.value)">
-                            </div>
-                            <div class="form-group">
-                                <label>Content</label>
-                                <textarea rows="4" onchange="AdminEditor.updateConfig('services.items[${index}].content', this.value)">${service.content}</textarea>
-                            </div>
-                            <div class="item-layout-controls">
-                                <div class="form-group">
-                                    <label>Column</label>
-                                    <select onchange="AdminEditor.updateConfig('services.items[${index}].layout.column', parseInt(this.value))">
-                                        ${[1,2,3,4].map(col => `<option value="${col}" ${serviceLayout.column === col ? 'selected' : ''}>Column ${col}</option>`).join('')}
-                                    </select>
-                                </div>
-                                <div class="form-group">
-                                    <label>Order/Row</label>
-                                    <input type="number" value="${serviceLayout.order}" min="1" onchange="AdminEditor.updateConfig('services.items[${index}].layout.order', parseInt(this.value))">
-                                </div>
-                            </div>
-                            <button type="button" class="btn-danger" onclick="AdminEditor.removeService(${index})">Remove Service</button>
-                        </div>
-                    `}).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addService()">+ Add Service</button>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Overview Editor
-     */
-    renderOverviewEditor: function() {
-        const overview = this.config.overview;
-        return `
-            <div class="form-section content-tab-panel" id="tab-overview" style="display:none;">
-                <h3>Company Overview</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${overview.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('overview.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${overview.title}" onchange="AdminEditor.updateConfig('overview.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Subtitle</label>
-                    <input type="text" value="${overview.subtitle}" onchange="AdminEditor.updateConfig('overview.subtitle', this.value)">
-                </div>
-                <h4>Mission</h4>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${overview.mission.title}" onchange="AdminEditor.updateConfig('overview.mission.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Icon</label>
-                    <input type="text" value="${overview.mission.icon}" onchange="AdminEditor.updateConfig('overview.mission.icon', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Content</label>
-                    <textarea rows="4" onchange="AdminEditor.updateConfig('overview.mission.content', this.value)">${overview.mission.content}</textarea>
-                </div>
-                <h4>Vision</h4>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${overview.vision.title}" onchange="AdminEditor.updateConfig('overview.vision.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Icon</label>
-                    <input type="text" value="${overview.vision.icon}" onchange="AdminEditor.updateConfig('overview.vision.icon', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Content</label>
-                    <textarea rows="4" onchange="AdminEditor.updateConfig('overview.vision.content', this.value)">${overview.vision.content}</textarea>
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Team Editor
-     */
-    renderTeamEditor: function() {
-        const team = this.config.team;
-        const layout = team.layout || { columns: 4, alignment: 'center', itemAlignment: 'center' };
-        return `
-            <div class="form-section content-tab-panel" id="tab-team" style="display:none;">
-                <h3>Team Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${team.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('team.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${team.title}" onchange="AdminEditor.updateConfig('team.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Subtitle</label>
-                    <input type="text" value="${team.subtitle}" onchange="AdminEditor.updateConfig('team.subtitle', this.value)">
-                </div>
-                
-                <!-- Layout Settings -->
-                <div class="layout-settings">
-                    <h4>📐 Layout Settings</h4>
-                    <div class="layout-controls">
-                        <div class="form-group">
-                            <label>Number of Columns</label>
-                            <select onchange="AdminEditor.updateConfig('team.layout.columns', parseInt(this.value))">
-                                <option value="1" ${layout.columns === 1 ? 'selected' : ''}>1 Column</option>
-                                <option value="2" ${layout.columns === 2 ? 'selected' : ''}>2 Columns</option>
-                                <option value="3" ${layout.columns === 3 ? 'selected' : ''}>3 Columns</option>
-                                <option value="4" ${layout.columns === 4 ? 'selected' : ''}>4 Columns</option>
-                            </select>
-                        </div>
-                        <div class="form-group">
-                            <label>Section Alignment</label>
-                            <select onchange="AdminEditor.updateConfig('team.layout.alignment', this.value)">
-                                <option value="left" ${layout.alignment === 'left' ? 'selected' : ''}>Align Left</option>
-                                <option value="center" ${layout.alignment === 'center' ? 'selected' : ''}>Align Center</option>
-                                <option value="right" ${layout.alignment === 'right' ? 'selected' : ''}>Align Right</option>
-                            </select>
-                        </div>
-                        <div class="form-group">
-                            <label>Item Alignment</label>
-                            <select onchange="AdminEditor.updateConfig('team.layout.itemAlignment', this.value)">
-                                <option value="left" ${layout.itemAlignment === 'left' ? 'selected' : ''}>Items Align Left</option>
-                                <option value="center" ${layout.itemAlignment === 'center' ? 'selected' : ''}>Items Align Center</option>
-                                <option value="right" ${layout.itemAlignment === 'right' ? 'selected' : ''}>Items Align Right</option>
-                            </select>
-                        </div>
-                    </div>
-                </div>
-                
-                <h4>Team Members</h4>
-                <div id="team-editor">
-                    ${team.members.map((member, index) => {
-                        const memberLayout = member.layout || { column: (index % layout.columns) + 1, order: index + 1 };
-                        return `
-                        <div class="item-editor">
-                            <h5>Team Member ${index + 1}</h5>
-                            <div class="form-group">
-                                <label>Name</label>
-                                <input type="text" value="${member.name}" onchange="AdminEditor.updateConfig('team.members[${index}].name', this.value)">
-                            </div>
-                            <div class="form-group">
-                                <label>Position</label>
-                                <input type="text" value="${member.position}" onchange="AdminEditor.updateConfig('team.members[${index}].position', this.value)">
-                            </div>
-                            <div class="form-group">
-                                <label>Photo</label>
-                                <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
-<input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'team', ${index})">
-                                ${member.image ? `<img src="${member.image}" alt="${member.name}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
-                            </div>
-                            <div class="item-layout-controls">
-                                <div class="form-group">
-                                    <label>Column</label>
-                                    <select onchange="AdminEditor.updateConfig('team.members[${index}].layout.column', parseInt(this.value))">
-                                        ${[1,2,3,4].map(col => `<option value="${col}" ${memberLayout.column === col ? 'selected' : ''}>Column ${col}</option>`).join('')}
-                                    </select>
-                                </div>
-                                <div class="form-group">
-                                    <label>Order/Row</label>
-                                    <input type="number" value="${memberLayout.order}" min="1" onchange="AdminEditor.updateConfig('team.members[${index}].layout.order', parseInt(this.value))">
-                                </div>
-                            </div>
-                            <button type="button" class="btn-danger" onclick="AdminEditor.removeTeamMember(${index})">Remove Member</button>
-                        </div>
-                    `}).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addTeamMember()">+ Add Team Member</button>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Gallery Editor
-     */
-    renderGalleryEditor: function() {
-        const gallery = this.config.gallery;
-        return `
-            <div class="form-section content-tab-panel" id="tab-gallery" style="display:none;">
-                <h3>Gallery Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${gallery.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('gallery.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${gallery.title}" onchange="AdminEditor.updateConfig('gallery.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Subtitle</label>
-                    <input type="text" value="${gallery.subtitle}" onchange="AdminEditor.updateConfig('gallery.subtitle', this.value)">
-                </div>
-                <h4>Gallery Images</h4>
-                <div id="gallery-editor">
-                    ${gallery.images.map((img, index) => `
-                        <div class="item-editor">
-                            <h5>Image ${index + 1}</h5>
-                            <div class="form-group">
-                                <label>Image Source</label>
-                                <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
-                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'gallery', ${index})">
-                            </div>
-                            <div class="form-group">
-                                <label>Alt Text</label>
-                                <input type="text" value="${img.alt}" onchange="AdminEditor.updateConfig('gallery.images[${index}].alt', this.value)">
-                            </div>
-                            ${img.src ? `<img src="${img.src}" alt="${img.alt}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
-                            <button type="button" class="btn-danger" onclick="AdminEditor.removeGalleryImage(${index})">Remove Image</button>
-                        </div>
-                    `).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addGalleryImage()">+ Add Gallery Image</button>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Contact Editor
-     */
-    renderContactEditor: function() {
-        const contact = this.config.contact;
-        return `
-            <div class="form-section content-tab-panel" id="tab-contact" style="display:none;">
-                <h3>Contact Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${contact.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('contact.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${contact.title}" onchange="AdminEditor.updateConfig('contact.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Subtitle</label>
-                    <input type="text" value="${contact.subtitle}" onchange="AdminEditor.updateConfig('contact.subtitle', this.value)">
-                </div>
-                <h4>Contact Information</h4>
-                <div class="form-group">
-                    <label>Company Name</label>
-                    <input type="text" value="${contact.company}" onchange="AdminEditor.updateConfig('contact.company', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Phone</label>
-                    <input type="text" value="${contact.phone}" onchange="AdminEditor.updateConfig('contact.phone', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Email</label>
-                    <input type="text" value="${contact.email}" onchange="AdminEditor.updateConfig('contact.email', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Address</label>
-                    <input type="text" value="${contact.address}" onchange="AdminEditor.updateConfig('contact.address', this.value)">
-                </div>
-                <h4>Contact Form</h4>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${contact.form.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('contact.form.enabled', this.checked)">
-                        Enable Contact Form
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Email To</label>
-                    <input type="text" value="${contact.form.emailTo}" onchange="AdminEditor.updateConfig('contact.form.emailTo', this.value)">
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Footer Editor
-     */
-    renderFooterEditor: function() {
-        const footer = this.config.footer;
-        return `
-            <div class="form-section content-tab-panel" id="tab-footer" style="display:none;">
-                <h3>Footer Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${footer.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('footer.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <h4>About Section</h4>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${footer.about.title}" onchange="AdminEditor.updateConfig('footer.about.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Content</label>
-                    <textarea rows="3" onchange="AdminEditor.updateConfig('footer.about.content', this.value)">${footer.about.content}</textarea>
-                </div>
-                <h4>Quick Links</h4>
-                <div id="footer-quicklinks-editor">
-                    ${footer.quickLinks.map((link, index) => `
-                        <div class="form-row">
-                            <input type="text" placeholder="Text" value="${link.text}" onchange="AdminEditor.updateConfig('footer.quickLinks[${index}].text', this.value)">
-                            <input type="text" placeholder="Link" value="${link.link}" onchange="AdminEditor.updateConfig('footer.quickLinks[${index}].link', this.value)">
-                            <button type="button" class="btn-danger" onclick="AdminEditor.removeFooterQuickLink(${index})">Remove</button>
-                        </div>
-                    `).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addFooterQuickLink()">+ Add Quick Link</button>
-                <h4>Services Links</h4>
-                <div id="footer-services-editor">
-                    ${footer.services.map((link, index) => `
-                        <div class="form-row">
-                            <input type="text" placeholder="Text" value="${link.text}" onchange="AdminEditor.updateConfig('footer.services[${index}].text', this.value)">
-                            <input type="text" placeholder="Link" value="${link.link}" onchange="AdminEditor.updateConfig('footer.services[${index}].link', this.value)">
-                            <button type="button" class="btn-danger" onclick="AdminEditor.removeFooterServiceLink(${index})">Remove</button>
-                        </div>
-                    `).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addFooterServiceLink()">+ Add Service Link</button>
-                <h4>Social Media</h4>
-                <div class="form-group">
-                    <label>Facebook</label>
-                    <input type="text" value="${footer.social.facebook}" onchange="AdminEditor.updateConfig('footer.social.facebook', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Twitter</label>
-                    <input type="text" value="${footer.social.twitter}" onchange="AdminEditor.updateConfig('footer.social.twitter', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>LinkedIn</label>
-                    <input type="text" value="${footer.social.linkedin}" onchange="AdminEditor.updateConfig('footer.social.linkedin', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Instagram</label>
-                    <input type="text" value="${footer.social.instagram}" onchange="AdminEditor.updateConfig('footer.social.instagram', this.value)">
-                </div>
-                <h4>Copyright</h4>
-                <div class="form-group">
-                    <label>Copyright Text</label>
-                    <input type="text" value="${footer.copyright}" onchange="AdminEditor.updateConfig('footer.copyright', this.value)">
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Clients Editor
-     */
-    renderClientsEditor: function() {
-        const clients = this.config.clients;
-        return `
-            <div class="form-section content-tab-panel" id="tab-clients" style="display:none;">
-                <h3>Clients Section</h3>
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${clients.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('clients.enabled', this.checked)">
-                        Enable Section
-                    </label>
-                </div>
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${clients.title}" onchange="AdminEditor.updateConfig('clients.title', this.value)">
-                </div>
-                <div class="form-group">
-                    <label>Subtitle</label>
-                    <input type="text" value="${clients.subtitle}" onchange="AdminEditor.updateConfig('clients.subtitle', this.value)">
-                </div>
-                <h4>Clients</h4>
-                <div id="clients-editor">
-                    ${clients.items.map((client, index) => `
-                        <div class="item-editor">
-                            <h5>Client ${index + 1}</h5>
-                            <div class="form-group">
-                                <label>Name</label>
-                                <input type="text" value="${client.name}" onchange="AdminEditor.updateConfig('clients.items[${index}].name', this.value)">
-                            </div>
-                            <div class="form-group">
-                                <label>Logo</label>
-                                <input type="text" value="${client.logo}" onchange="AdminEditor.updateConfig('clients.items[${index}].logo', this.value)">
-                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'client', ${index})">
-                            </div>
-                            <button type="button" class="btn-danger" onclick="AdminEditor.removeClient(${index})">Remove Client</button>
-                        </div>
-                    `).join('')}
-                </div>
-                <button type="button" class="btn-secondary" onclick="AdminEditor.addClient()">+ Add Client</button>
-            </div>
-        `;
-    },
-    
-    /**
-     * Add team member
-     */
-    addTeamMember: function() {
-        const layout = this.config.team.layout || { columns: 4 };
-        const newMember = {
-            name: 'New Team Member',
-            position: 'Position',
-            image: 'images/intro.jpg',
-            layout: {
-                column: (this.config.team.members.length % layout.columns) + 1,
-                order: this.config.team.members.length + 1
-            }
-        };
-        this.config.team.members.push(newMember);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Remove team member
-     */
-    removeTeamMember: function(index) {
-        if (confirm('Remove this team member?')) {
-            this.config.team.members.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Add gallery image
-     */
-    addGalleryImage: function() {
-        const newImage = {
-            src: 'images/intro.jpg',
-            alt: 'New Gallery Image'
-        };
-        this.config.gallery.images.push(newImage);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Remove gallery image
-     */
-    removeGalleryImage: function(index) {
-        if (confirm('Remove this image?')) {
-            this.config.gallery.images.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Add client
-     */
-    addClient: function() {
-        const newClient = {
-            name: 'New Client',
-            logo: ''
-        };
-        this.config.clients.items.push(newClient);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Remove client
-     */
-    removeClient: function(index) {
-        if (confirm('Remove this client?')) {
-            this.config.clients.items.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Add footer quick link
-     */
-    addFooterQuickLink: function() {
-        const newLink = {
-            text: 'New Link',
-            link: '#'
-        };
-        this.config.footer.quickLinks.push(newLink);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Remove footer quick link
-     */
-    removeFooterQuickLink: function(index) {
-        if (confirm('Remove this link?')) {
-            this.config.footer.quickLinks.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Add footer service link
-     */
-    addFooterServiceLink: function() {
-        const newLink = {
-            text: 'New Service',
-            link: '#'
-        };
-        this.config.footer.services.push(newLink);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Remove footer service link
-     */
-    removeFooterServiceLink: function(index) {
-        if (confirm('Remove this service link?')) {
-            this.config.footer.services.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Render Theme Settings
-     */
-    renderThemeSettings: function() {
-        const theme = this.config.theme;
-        return `
-            <h2>Theme & Colors</h2>
-            <div class="form-section">
-                <h3>Primary Colors</h3>
-                <div class="color-grid">
-                    <div class="form-group">
-                        <label>Primary</label>
-                        <input type="color" value="${theme.colors.primary}" onchange="AdminEditor.updateConfig('theme.colors.primary', this.value)">
-                        <input type="text" value="${theme.colors.primary}" onchange="AdminEditor.updateConfig('theme.colors.primary', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Primary Light</label>
-                        <input type="color" value="${theme.colors.primaryLight}" onchange="AdminEditor.updateConfig('theme.colors.primaryLight', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Primary Dark</label>
-                        <input type="color" value="${theme.colors.primaryDark}" onchange="AdminEditor.updateConfig('theme.colors.primaryDark', this.value)">
-                    </div>
-                </div>
-                
-                <h3>Secondary Colors</h3>
-                <div class="color-grid">
-                    <div class="form-group">
-                        <label>Secondary</label>
-                        <input type="color" value="${theme.colors.secondary}" onchange="AdminEditor.updateConfig('theme.colors.secondary', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Secondary Light</label>
-                        <input type="color" value="${theme.colors.secondaryLight}" onchange="AdminEditor.updateConfig('theme.colors.secondaryLight', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Secondary Dark</label>
-                        <input type="color" value="${theme.colors.secondaryDark}" onchange="AdminEditor.updateConfig('theme.colors.secondaryDark', this.value)">
-                    </div>
-                </div>
-                
-                <h3>Background Colors</h3>
-                <div class="color-grid">
-                    <div class="form-group">
-                        <label>Background Light</label>
-                        <input type="color" value="${theme.colors.backgroundLight}" onchange="AdminEditor.updateConfig('theme.colors.backgroundLight', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Background White</label>
-                        <input type="color" value="${theme.colors.backgroundWhite}" onchange="AdminEditor.updateConfig('theme.colors.backgroundWhite', this.value)">
-                    </div>
-                </div>
-                
-                <h3>Text Colors</h3>
-                <div class="color-grid">
-                    <div class="form-group">
-                        <label>Text Dark</label>
-                        <input type="color" value="${theme.colors.textDark}" onchange="AdminEditor.updateConfig('theme.colors.textDark', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Text Gray</label>
-                        <input type="color" value="${theme.colors.textGray}" onchange="AdminEditor.updateConfig('theme.colors.textGray', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Text Light</label>
-                        <input type="color" value="${theme.colors.textLight}" onchange="AdminEditor.updateConfig('theme.colors.textLight', this.value)">
-                    </div>
-                </div>
-                
-                <h3>Button Colors</h3>
-                <div class="color-grid">
-                    <div class="form-group">
-                        <label>Primary Button</label>
-                        <input type="color" value="${theme.buttons.primary}" onchange="AdminEditor.updateConfig('theme.buttons.primary', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Secondary Button</label>
-                        <input type="color" value="${theme.buttons.secondary}" onchange="AdminEditor.updateConfig('theme.buttons.secondary', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Hover</label>
-                        <input type="color" value="${theme.buttons.hover}" onchange="AdminEditor.updateConfig('theme.buttons.hover', this.value)">
-                    </div>
-                </div>
-                
-                <h3>Typography</h3>
-                <div class="form-group">
-                    <label>Primary Font</label>
-                    <select onchange="AdminEditor.updateConfig('theme.fonts.primary', this.value)">
-                        <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" ${theme.fonts.primary.includes('Segoe UI') ? 'selected' : ''}>Segoe UI</option>
-                        <option value="'Arial', sans-serif" ${theme.fonts.primary.includes('Arial') ? 'selected' : ''}>Arial</option>
-                        <option value="'Roboto', sans-serif" ${theme.fonts.primary.includes('Roboto') ? 'selected' : ''}>Roboto</option>
-                        <option value="'Open Sans', sans-serif" ${theme.fonts.primary.includes('Open Sans') ? 'selected' : ''}>Open Sans</option>
-                        <option value="'Poppins', sans-serif" ${theme.fonts.primary.includes('Poppins') ? 'selected' : ''}>Poppins</option>
-                    </select>
-                </div>
-                
-                <button type="button" class="btn-primary" onclick="AdminEditor.previewTheme()">Preview Theme</button>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Image Settings
-     */
-    renderImageSettings: function() {
-        return `
-            <h2>Image Management</h2>
-            <div class="form-section">
-                <p>Upload new images or change image paths. Images are stored in the images folder.</p>
-                
-                <div class="image-uploader">
-                    <h3>Hero Background</h3>
-                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'hero')">
-                    <input type="text" value="${this.config.hero.backgroundImage}" placeholder="Or enter image URL">
-                </div>
-                
-                <div class="image-uploader">
-                    <h3>Introduction Image</h3>
-                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'intro')">
-                    <input type="text" value="${this.config.introduction.image}" placeholder="Or enter image URL">
-                </div>
-                
-                <div class="image-uploader">
-                    <h3>Popup Image</h3>
-                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'popup')">
-                    <input type="text" value="${this.config.popup.image}" placeholder="Or enter image URL">
-                </div>
-                
-                <h3>Team Photos</h3>
-                <div class="image-grid">
-                    ${this.config.team.members.map((member, index) => `
-                        <div class="image-item">
-                            <label>${member.name}</label>
-                            <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
-                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'team', ${index})">
-                        </div>
-                    `).join('')}
-                </div>
-                
-                <h3>Gallery Images</h3>
-                <div class="image-grid">
-                    ${this.config.gallery.images.map((img, index) => `
-                        <div class="image-item">
-                            <label>Image ${index + 1}</label>
-                            <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
-                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'gallery', ${index})">
-                        </div>
-                    `).join('')}
-                </div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render Popup Settings
-     */
-    renderPopupSettings: function() {
-        const popup = this.config.popup;
-        return `
-            <h2>Popup Editor</h2>
-            <div class="form-section">
-                <div class="form-group">
-                    <label>
-                        <input type="checkbox" ${popup.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('popup.enabled', this.checked)">
-                        Enable Popup
-                    </label>
-                </div>
-                
-                <div class="form-group">
-                    <label>Title</label>
-                    <input type="text" value="${popup.title}" onchange="AdminEditor.updateConfig('popup.title', this.value)">
-                </div>
-                
-                <div class="form-group">
-                    <label>Description</label>
-                    <textarea rows="4" onchange="AdminEditor.updateConfig('popup.description', this.value)">${popup.description}</textarea>
-                </div>
-                
-                <div class="form-group">
-                    <label>Image</label>
-                    <input type="text" value="${popup.image}" onchange="AdminEditor.updateConfig('popup.image', this.value)">
-                </div>
-                
-                <div class="form-group">
-                    <label>Button Text</label>
-                    <input type="text" value="${popup.buttonText}" onchange="AdminEditor.updateConfig('popup.buttonText', this.value)">
-                </div>
-                
-                <div class="form-group">
-                    <label>Button Link</label>
-                    <input type="text" value="${popup.buttonLink}" onchange="AdminEditor.updateConfig('popup.buttonLink', this.value)">
-                </div>
-                
-                <h3>Colors</h3>
-                <div class="color-grid">
-                    <div class="form-group">
-                        <label>Background Color</label>
-                        <input type="color" value="${this.hexToRgba(popup.backgroundColor)}" onchange="AdminEditor.updateConfig('popup.backgroundColor', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Text Color</label>
-                        <input type="color" value="${popup.textColor}" onchange="AdminEditor.updateConfig('popup.textColor', this.value)">
-                    </div>
-                    <div class="form-group">
-                        <label>Button Color</label>
-                        <input type="color" value="${popup.buttonColor}" onchange="AdminEditor.updateConfig('popup.buttonColor', this.value)">
-                    </div>
-                </div>
-                
-                <div class="form-group">
-                    <label>Show Again Duration (days)</label>
-                    <input type="number" value="${popup.showAgainDuration}" min="1" max="30" onchange="AdminEditor.updateConfig('popup.showAgainDuration', parseInt(this.value))">
-                </div>
-                
-                <button type="button" class="btn-secondary" onclick="AdminEditor.testPopup()">Test Popup</button>
-            </div>
-        `;
-    },
-    
-    /**
-     * Render GitHub Settings
-     */
-    renderGitHubSettings: function() {
-        const github = this.config.github;
-        return `
-            <h2>GitHub Publish Panel</h2>
-            <div class="form-section">
-                <div class="form-group">
-                    <label>Repository URL</label>
-                    <input type="text" id="github-repo" value="${github.repoUrl}" placeholder="https://github.com/username/repo" onchange="AdminEditor.updateConfig('github.repoUrl', this.value)">
-                </div>
-                
-                <div class="form-group">
-                    <label>GitHub Username</label>
-                    <input type="text" id="github-username" value="${github.username}" placeholder="username" onchange="AdminEditor.updateConfig('github.username', this.value)">
-                </div>
-                
-                <div class="form-group">
-                    <label>Personal Access Token</label>
-                    <input type="password" id="github-token" value="${github.token}" placeholder="ghp_xxxxxxxxxxxx" onchange="AdminEditor.updateConfig('github.token', this.value)">
-                    <small>Create a token with 'repo' scope at GitHub Settings > Developer settings > Personal access tokens</small>
-                </div>
-                
-                <div class="form-group">
-                    <label>Branch</label>
-                    <input type="text" id="github-branch" value="${github.branch}" placeholder="main" onchange="AdminEditor.updateConfig('github.branch', this.value)">
-                </div>
-                
-                <div class="button-group">
-                    <button type="button" class="btn-secondary" onclick="AdminEditor.testGitHubConnection()">Test Connection</button>
-                    <button type="button" class="btn-primary" onclick="AdminEditor.publishToGitHub()">Publish Website</button>
-                </div>
-                
-                <div id="github-status" class="status-message"></div>
-            </div>
-        `;
-    },
-    
-    /**
-     * Setup section-specific event listeners
-     */
-    setupSectionListeners: function() {
-        // This is called after rendering each section
-        // Additional event listeners can be added here
-    },
-    
-    /**
-     * Update configuration value
-     */
-    updateConfig: function(path, value) {
-        const keys = path.split('.');
-        let obj = this.config;
-        
-        for (let i = 0; i < keys.length - 1; i++) {
-            const key = keys[i];
-            // Handle array indices
-            const match = key.match(/^(\w+)\[(\d+)\]$/);
-            if (match) {
-                if (!obj[match[1]]) obj[match[1]] = [];
-                obj = obj[match[1]];
-                i++;
-                key = keys[i];
-            }
-            obj = obj[key];
-        }
-        
-        const lastKey = keys[keys.length - 1];
-        const arrayMatch = lastKey.match(/^(\w+)\[(\d+)\]$/);
-        
-        if (arrayMatch) {
-            obj[arrayMatch[1]][parseInt(arrayMatch[2])] = value;
-        } else {
-            obj[lastKey] = value;
-        }
-        
-        this.hasChanges = true;
-    },
-    
-    /**
-     * Add menu item
-     */
-    addMenuItem: function() {
-        const newItem = {
-            text: 'New Item',
-            link: '#section',
-            order: this.config.navigation.menu.length + 1
-        };
-        this.config.navigation.menu.push(newItem);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Update menu item
-     */
-    updateMenuItem: function(index, field, value) {
-        this.config.navigation.menu[index][field] = value;
-        this.hasChanges = true;
-    },
-    
-    /**
-     * Remove menu item
-     */
-    removeMenuItem: function(index) {
-        if (confirm('Remove this menu item?')) {
-            this.config.navigation.menu.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Add service
-     */
-    addService: function() {
-        const newService = {
-            title: 'New Service',
-            icon: '✨',
-            content: 'Service description here.'
-        };
-        this.config.services.items.push(newService);
-        this.hasChanges = true;
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Remove service
-     */
-    removeService: function(index) {
-        if (confirm('Remove this service?')) {
-            this.config.services.items.splice(index, 1);
-            this.hasChanges = true;
-            this.renderCurrentSection();
-        }
-    },
-    
-    /**
-     * Switch content tab
-     */
-    switchContentTab: function(tab) {
-        document.querySelectorAll('.tab-btn').forEach(btn => {
-            btn.classList.toggle('active', btn.dataset.tab === tab);
-        });
-        
-        // Hide all panels
-        document.querySelectorAll('.content-tab-panel').forEach(panel => {
-            panel.style.display = 'none';
-        });
-        
-        // Show selected panel
-        const panel = document.getElementById('tab-' + tab);
-        if (panel) {
-            panel.style.display = 'block';
-        } else {
-            // Render the panel if not exists
-            const contentArea = document.getElementById('content-editor-area');
-            switch(tab) {
-                case 'introduction':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'overview':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'services':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'team':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'gallery':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'contact':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'footer':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                case 'clients':
-                    contentArea.innerHTML = this.renderIntroductionEditor() + this.renderOverviewEditor() + this.renderServicesEditor() + this.renderTeamEditor() + this.renderGalleryEditor() + this.renderContactEditor() + this.renderFooterEditor() + this.renderClientsEditor();
-                    break;
-                default:
-                    contentArea.innerHTML = '<p>Editor coming soon for this section.</p>';
-            }
-        }
-    },
-    
-    /**
-     * Crop and upload image
-     */
-    cropImage: function(input, type, index) {
-        const file = input.files[0];
-        if (!file) return;
-        
-        // Create cropper modal
-        this.createCropperModal(file, type, index);
-    },
-    
-    /**
-     * Create cropper modal
-     */
-    createCropperModal: function(file, type, index) {
-        const reader = new FileReader();
-        reader.onload = function(e) {
-            const imgData = e.target.result;
-            
-            // Create modal
-            const modal = document.createElement('div');
-            modal.id = 'cropper-modal';
-            modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:10000;display:flex;justify-content:center;align-items:center;flex-direction:column;';
-            
-            const modalContent = document.createElement('div');
-            modalContent.style.cssText = 'background:white;padding:20px;border-radius:8px;max-width:90%;max-height:90%;overflow:auto;';
-            
-            const title = document.createElement('h3');
-            title.textContent = 'Crop Image';
-            title.style.marginTop = '0';
-            
-            const imgContainer = document.createElement('div');
-            imgContainer.style.cssText = 'max-width:100%;max-height:400px;overflow:hidden;margin:15px 0;';
-            
-            const img = document.createElement('img');
-            img.src = imgData;
-            img.id = 'cropper-image';
-            img.style.cssText = 'max-width:100%;max-height:400px;';
-            
-            imgContainer.appendChild(img);
-            
-            // Crop controls
-            const controls = document.createElement('div');
-            controls.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap;margin-bottom:15px;';
-            
-            const aspectLabel = document.createElement('label');
-            aspectLabel.textContent = 'Aspect Ratio: ';
-            controls.appendChild(aspectLabel);
-            
-            const aspectSelect = document.createElement('select');
-            aspectSelect.id = 'aspect-ratio';
-            aspectSelect.style.cssText = 'padding:5px;margin-bottom:5px;';
-            aspectSelect.innerHTML = `
-                <option value="0">Free</option>
-                <option value="1">1:1</option>
-                <option value="4/3">4:3</option>
-                <option value="16/9">16:9</option>
-                <option value="3/4">3:4</option>
-            `;
-            controls.appendChild(aspectSelect);
-            
-            const buttonGroup = document.createElement('div');
-            buttonGroup.style.cssText = 'display:flex;gap:10px;margin-top:10px;';
-            
-            const cropBtn = document.createElement('button');
-            cropBtn.textContent = 'Apply Crop';
-            cropBtn.className = 'btn btn-primary';
-            cropBtn.onclick = function() { AdminEditor.applyCrop(img, type, index, modal); };
-            
-            const cancelBtn = document.createElement('button');
-            cancelBtn.textContent = 'Cancel';
-            cancelBtn.className = 'btn btn-secondary';
-            cancelBtn.onclick = function() { modal.remove(); };
-            
-            const resetBtn = document.createElement('button');
-            resetBtn.textContent = 'Reset';
-            resetBtn.className = 'btn btn-secondary';
-            resetBtn.onclick = function() { 
-                if (img.cropper) {
-                    img.cropper.reset();
-                }
-            };
-            
-            buttonGroup.appendChild(cropBtn);
-            buttonGroup.appendChild(resetBtn);
-            buttonGroup.appendChild(cancelBtn);
-            
-            modalContent.appendChild(title);
-            modalContent.appendChild(controls);
-            modalContent.appendChild(imgContainer);
-            modalContent.appendChild(buttonGroup);
-            modal.appendChild(modalContent);
-            document.body.appendChild(modal);
-            
-            // Initialize Cropper.js if available, otherwise use simple crop
-            if (typeof Cropper !== 'undefined') {
-                const cropper = new Cropper(img, {
-                    aspectRatio: NaN,
-                    viewMode: 1,
-                    ready: function() {
-                        aspectSelect.addEventListener('change', function() {
-                            const value = this.value;
-                            if (value === '0') {
-                                cropper.setAspectRatio(NaN);
-                            } else {
-                                cropper.setAspectRatio(eval(value));
-                            }
-                        });
-                    }
-                });
-                img.cropper = cropper;
-            } else {
-                // Simple crop without library - use canvas
-                AdminEditor.setupSimpleCrop(img, modal, type, index);
-            }
-        };
-        reader.readAsDataURL(file);
-    },
-    
-    /**
-     * Setup simple crop without external library
-     */
-    setupSimpleCrop: function(img, modal, type, index) {
-        const modalContent = modal.querySelector('div');
-        const imgContainer = modalContent.querySelector('div');
-        
-        // Add crop coordinates inputs
-        const cropControls = document.createElement('div');
-        cropControls.id = 'simple-crop-controls';
-        cropControls.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:15px 0;';
-        cropControls.innerHTML = `
-            <div>
-                <label>X Position: <input type="number" id="crop-x" value="0" min="0" style="width:60px;"></label>
-            </div>
-            <div>
-                <label>Y Position: <input type="number" id="crop-y" value="0" min="0" style="width:60px;"></label>
-            </div>
-            <div>
-                <label>Width: <input type="number" id="crop-width" value="200" min="50" style="width:60px;"></label>
-            </div>
-            <div>
-                <label>Height: <input type="number" id="crop-height" value="200" min="50" style="width:60px;"></label>
-            </div>
-        `;
-        
-        // Insert before button group
-        const buttonGroup = modalContent.querySelector('div:last-child');
-        modalContent.insertBefore(cropControls, buttonGroup);
-        
-        // Update crop button
-        const cropBtn = buttonGroup.querySelector('button:first-child');
-        cropBtn.onclick = function() {
-            const x = parseInt(document.getElementById('crop-x').value) || 0;
-            const y = parseInt(document.getElementById('crop-y').value) || 0;
-            const width = parseInt(document.getElementById('crop-width').value) || 200;
-            const height = parseInt(document.getElementById('crop-height').value) || 200;
-            
-            AdminEditor.applySimpleCrop(img.src, x, y, width, height, type, index, modal);
-        };
-    },
-    
-    /**
-     * Apply simple crop using canvas
-     */
-    applySimpleCrop: function(imgData, x, y, width, height, type, index, modal) {
-        const canvas = document.createElement('canvas');
-        const ctx = canvas.getContext('2d');
-        
-        const img = new Image();
-        img.onload = function() {
-            canvas.width = width;
-            canvas.height = height;
-            
-            // Draw cropped portion
-            ctx.drawImage(img, x, y, width, height, 0, 0, width, height);
-            
-            // Get cropped data as base64
-            const croppedData = canvas.toDataURL('image/jpeg', 0.9);
-            
-            // Update config
-            AdminEditor.saveCroppedImage(croppedData, type, index);
-            
-            // Close modal
-            modal.remove();
-        };
-        img.src = imgData;
-    },
-    
-    /**
-     * Apply crop (with Cropper.js)
-     */
-    applyCrop: function(img, type, index, modal) {
-        if (img.cropper) {
-            const canvas = img.cropper.getCroppedCanvas({
-                maxWidth: 1200,
-                maxHeight: 1200,
-                imageSmoothingEnabled: true,
-                imageSmoothingQuality: 'high'
-            });
-            
-            const croppedData = canvas.toDataURL('image/jpeg', 0.9);
-            this.saveCroppedImage(croppedData, type, index);
-            modal.remove();
-        } else {
-            // Use simple crop
-            this.applySimpleCrop(img.src, 
-                parseInt(document.getElementById('crop-x').value) || 0,
-                parseInt(document.getElementById('crop-y').value) || 0,
-                parseInt(document.getElementById('crop-width').value) || 200,
-                parseInt(document.getElementById('crop-height').value) || 200,
-                type, index, modal);
-        }
-    },
-    
-    /**
-     * Save cropped image to config
-     */
-    saveCroppedImage: function(base64Data, type, index) {
-        // In a real implementation, this would upload to server
-        // For demo, we'll use the base64 data directly or save locally
-        
-        console.log('Image cropped:', type, index);
-        
-        // Update the config based on type
-        switch(type) {
-            case 'hero':
-                this.updateConfig('hero.backgroundImage', base64Data);
-                break;
-            case 'intro':
-                this.updateConfig('introduction.image', base64Data);
-                break;
-            case 'popup':
-                this.updateConfig('popup.image', base64Data);
-                break;
-            case 'team':
-                this.updateConfig('team.members[' + index + '].image', base64Data);
-                break;
-            case 'gallery':
-                this.updateConfig('gallery.images[' + index + '].src', base64Data);
-                break;
-            case 'client':
-                this.updateConfig('clients.items[' + index + '].logo', base64Data);
-                break;
-        }
-        
-        this.hasChanges = true;
-        this.showNotification('Image cropped and applied!', 'success');
-        
-        // Re-render to show changes
-        this.renderCurrentSection();
-    },
-    
-    /**
-     * Upload image
-     */
-    uploadImage: function(input, type, index) {
-        const file = input.files[0];
-        if (!file) return;
-        
-        const reader = new FileReader();
-        reader.onload = function(e) {
-            const base64 = e.target.result;
-            // In a real implementation, this would upload to server
-            // For now, we'll use localStorage for preview
-            console.log('Image uploaded:', type, index);
-            AdminEditor.showNotification('Image uploaded! In production, this would be saved to the server.', 'info');
-        };
-        reader.readAsDataURL(file);
-    },
-    
-    /**
-     * Preview theme
-     */
-    previewTheme: function() {
-        // Save current config and open preview
-        const previewWindow = window.open('index.html', '_blank');
-        this.showNotification('Preview will open in a new tab with current settings', 'info');
-    },
-    
-    /**
-     * Test popup
-     */
-    testPopup: function() {
-        // Reset popup to show
-        localStorage.removeItem('edc_popup_dismissed');
-        
-        // Open index.html to test
-        const previewWindow = window.open('index.html', '_blank');
-        this.showNotification('Popup will appear when the page loads', 'info');
-    },
-    
-    /**
-     * Test GitHub connection
-     */
-    async testGitHubConnection() {
-        const statusDiv = document.getElementById('github-status');
-        statusDiv.innerHTML = '<p>Testing connection...</p>';
-        statusDiv.className = 'status-message info';
-        
-        // Update config from inputs
-        this.config.github.repoUrl = document.getElementById('github-repo').value;
-        this.config.github.token = document.getElementById('github-token').value;
-        
-        GitHubPublisher.setConfig(this.config.github);
-        const result = await GitHubPublisher.testConnection();
-        
-        if (result.success) {
-            statusDiv.innerHTML = `<p class="success">✓ ${result.message}</p>`;
-            statusDiv.className = 'status-message success';
-        } else {
-            statusDiv.innerHTML = `<p class="error">✗ ${result.message}</p>`;
-            statusDiv.className = 'status-message error';
-        }
-    },
-    
-    /**
-     * Publish to GitHub
-     */
-    async publishToGitHub() {
-        // First save config
-        await this.saveConfig(false);
-        
-        const statusDiv = document.getElementById('github-status');
-        statusDiv.innerHTML = '<p>Publishing to GitHub...</p>';
-        statusDiv.className = 'status-message info';
-        
-        // Update config from inputs
-        this.config.github.repoUrl = document.getElementById('github-repo').value;
-        this.config.github.token = document.getElementById('github-token').value;
-        this.config.github.branch = document.getElementById('github-branch').value;
-        
-        GitHubPublisher.setConfig(this.config.github);
-        
-        const files = [
-            { path: 'index.html', message: 'Update index.html' },
-            { path: 'data/site-config.json', message: 'Update site configuration' },
-            { path: 'css/style.css', message: 'Update styles' }
-        ];
-        
-        GitHubPublisher.publish(
-            files,
-            (progress) => {
-                statusDiv.innerHTML = `<p>${progress}</p>`;
-            },
-            (results) => {
-                const allSuccess = results.every(r => r.success);
-                if (allSuccess) {
-                    statusDiv.innerHTML = '<p class="success">✓ All files published successfully!</p>';
-                    statusDiv.className = 'status-message success';
-                } else {
-                    const errors = results.filter(r => !r.success).map(r => r.error).join(', ');
-                    statusDiv.innerHTML = `<p class="error">✗ Some files failed: ${errors}</p>`;
-                    statusDiv.className = 'status-message error';
-                }
-            },
-            (error) => {
-                statusDiv.innerHTML = `<p class="error">✗ ${error}</p>`;
-                statusDiv.className = 'status-message error';
-            }
-        );
-    },
-    
-    /**
-     * Preview site
-     */
-    previewSite: function() {
-        // Save current config
-        this.saveConfig(false).then(() => {
-            window.open('index.html', '_blank');
-        });
-    },
-    
-    /**
-     * Setup auto-save
-     */
-    setupAutoSave: function() {
-        // Auto-save every 5 minutes
-        setInterval(() => {
-            if (this.hasChanges) {
-                this.saveConfig(false);
-                console.log('Auto-saved configuration');
-            }
-        }, 300000);
-    },
-    
-    /**
-     * Show notification
-     */
-    showNotification: function(message, type = 'info') {
-        const notification = document.createElement('div');
-        notification.className = `notification notification-${type}`;
-        notification.textContent = message;
-        
-        document.body.appendChild(notification);
-        
-        setTimeout(() => {
-            notification.classList.add('show');
-        }, 10);
-        
-        setTimeout(() => {
-            notification.classList.remove('show');
-            setTimeout(() => notification.remove(), 300);
-        }, 3000);
-    },
-    
-    /**
-     * Convert hex to rgba
-     */
-    hexToRgba: function(hex) {
-        if (hex.startsWith('rgba')) return hex;
-        
-        const r = parseInt(hex.slice(1, 3), 16);
-        const g = parseInt(hex.slice(3, 5), 16);
-        const b = parseInt(hex.slice(5, 7), 16);
-        
-        return `rgba(${r}, ${g}, ${b}, 0.85)`;
-    }
-};
-
-// Make globally available
-window.AdminEditor = AdminEditor;
-
+/**
+ * ============================================
+ * ADMIN EDITOR - Visual Content Editor
+ * Allows editing all site configuration from admin panel
+ * ============================================
+ */
+
+const AdminEditor = {
+    config: null,
+    currentSection: 'general',
+    hasChanges: false,
+    
+    /**
+     * Initialize the admin editor
+     */
+    init: async function() {
+        const config = await this.loadConfig();
+        if (!config) {
+            this.showNotification('Error loading configuration. Please ensure the server is running!', 'error');
+            return;
+        }
+        this.setupEventListeners();
+        this.renderCurrentSection();
+        this.setupAutoSave();
+    },
+    
+    /**
+     * Load configuration from server
+     */
+    loadConfig: async function() {
+        try {
+            // Use server API endpoint - works with both server and direct file access
+            // when the server is running
+            const response = await fetch('/api/config');
+            if (!response.ok) {
+                throw new Error('Failed to fetch config');
+            }
+            this.config = await response.json();
+            return this.config;
+        } catch (error) {
+            console.error('Error loading config:', error);
+            this.showNotification('Error loading configuration. Make sure the server is running!', 'error');
+            return null;
+        }
+    },
+    
+    /**
+     * Save configuration to server
+     */
+    saveConfig: async function(showMessage = true) {
+        try {
+            const response = await fetch('/api/save-config', {
+                method: 'POST',
+                headers: {
+                    'Content-Type': 'application/json'
+                },
+                body: JSON.stringify(this.config)
+            });
+            
+            if (!response.ok) {
+                throw new Error('Failed to save configuration');
+            }
+            
+            this.hasChanges = false;
+            if (showMessage) {
+                this.showNotification('Configuration saved successfully!', 'success');
+            }
+            
+            // Update last updated timestamp
+            this.config.lastUpdated = new Date().toISOString();
+            
+            return true;
+        } catch (error) {
+            console.error('Error saving config:', error);
+            this.showNotification('Error saving configuration: ' + error.message, 'error');
+            return false;
+        }
+    },
+    
+    /**
+     * Setup event listeners
+     */
+    setupEventListeners: function() {
+        // Section navigation
+        document.querySelectorAll('.admin-nav-item').forEach(item => {
+            item.addEventListener('click', (e) => {
+                e.preventDefault();
+                const section = item.dataset.section;
+                this.switchSection(section);
+            });
+        });
+        
+        // Save button
+        document.getElementById('save-btn')?.addEventListener('click', () => {
+            this.saveConfig();
+        });
+        
+        // Preview button
+        document.getElementById('preview-btn')?.addEventListener('click', () => {
+            this.previewSite();
+        });
+        
+        // Reset button
+        document.getElementById('reset-btn')?.addEventListener('click', () => {
+            if (confirm('Are you sure you want to reset all changes?')) {
+                this.loadConfig().then(() => {
+                    this.renderCurrentSection();
+                    this.showNotification('Changes reset', 'info');
+                });
+            }
+        });
+        
+        // Handle before unload if there are unsaved changes
+        window.addEventListener('beforeunload', (e) => {
+            if (this.hasChanges) {
+                e.preventDefault();
+                e.returnValue = '';
+            }
+        });
+    },
+    
+    /**
+     * Switch admin section
+     */
+    switchSection: function(section) {
+        // Update active nav item
+        document.querySelectorAll('.admin-nav-item').forEach(item => {
+            item.classList.toggle('active', item.dataset.section === section);
+        });
+        
+        this.currentSection = section;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Render current section
+     */
+    renderCurrentSection: function() {
+        const container = document.getElementById('editor-content');
+        if (!container) return;
+        
+        switch (this.currentSection) {
+            case 'general':
+                container.innerHTML = this.renderGeneralSettings();
+                break;
+            case 'navigation':
+                container.innerHTML = this.renderNavigationSettings();
+                break;
+            case 'hero':
+                container.innerHTML = this.renderHeroSettings();
+                break;
+            case 'content':
+                container.innerHTML = this.renderContentSettings();
+                break;
+            case 'theme':
+                container.innerHTML = this.renderThemeSettings();
+                break;
+            case 'images':
+                container.innerHTML = this.renderImageSettings();
+                break;
+            case 'popup':
+                container.innerHTML = this.renderPopupSettings();
+                break;
+            case 'github':
+                container.innerHTML = this.renderGitHubSettings();
+                break;
+            default:
+                container.innerHTML = '<p>Section not found</p>';
+        }
+        
+        // Setup section-specific event listeners
+        this.setupSectionListeners();
+    },
+    
+    /**
+     * Render General Settings
+     */
+    renderGeneralSettings: function() {
+        return `
+            <h2>General Settings</h2>
+            <div class="form-section">
+                <div class="form-group">
+                    <label>Site Name</label>
+                    <input type="text" id="site-name" value="${this.config.site.name}" onchange="AdminEditor.updateConfig('site.name', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Site Description</label>
+                    <textarea id="site-description" onchange="AdminEditor.updateConfig('site.description', this.value)">${this.config.site.description}</textarea>
+                </div>
+                <div class="form-group">
+                    <label>Logo URL</label>
+                    <input type="text" id="site-logo" value="${this.config.site.logo}" onchange="AdminEditor.updateConfig('site.logo', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Favicon URL</label>
+                    <input type="text" id="site-favicon" value="${this.config.site.favicon}" onchange="AdminEditor.updateConfig('site.favicon', this.value)">
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Navigation Settings
+     */
+    renderNavigationSettings: function() {
+        const nav = this.config.navigation;
+        return `
+            <h2>Navigation Settings</h2>
+            <div class="form-section">
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${nav.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('navigation.enabled', this.checked)">
+                        Enable Navigation
+                    </label>
+                </div>
+                <h3>Logo</h3>
+                <div class="form-group">
+                    <label>Logo Text</label>
+                    <input type="text" value="${nav.logo.text}" onchange="AdminEditor.updateConfig('navigation.logo.text', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Logo Link</label>
+                    <input type="text" value="${nav.logo.link}" onchange="AdminEditor.updateConfig('navigation.logo.link', this.value)">
+                </div>
+                Menu Items</h3>
+                <div id="menu-items-editor">
+                    ${nav.menu.sort((a, b) => a.order - b.order).map((item, index) => `
+                        <div class="menu-item-editor">
+                            <div class="form-row">
+                                <input type="text" placeholder="Text" value="${item.text}" onchange="AdminEditor.updateMenuItem(${index}, 'text', this.value)">
+                                <input type="text" placeholder="Link" value="${item.link}" onchange="AdminEditor.updateMenuItem(${index}, 'link', this.value)">
+                                <input type="number" placeholder="Order" value="${item.order}" min="1" onchange="AdminEditor.updateMenuItem(${index}, 'order', parseInt(this.value))">
+                                <button type="button" class="btn-danger" onclick="AdminEditor.removeMenuItem(${index})">Remove</button>
+                            </div>
+                        </div>
+                    `).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addMenuItem()">+ Add Menu Item</button>
+                
+                <h3>Apply Button</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${nav.applyButton.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('navigation.applyButton.enabled', this.checked)">
+                        Enable Apply Button
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Button Text</label>
+                    <input type="text" value="${nav.applyButton.text}" onchange="AdminEditor.updateConfig('navigation.applyButton.text', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Button Link</label>
+                    <input type="text" value="${nav.applyButton.link}" onchange="AdminEditor.updateConfig('navigation.applyButton.link', this.value)">
+                </div>
+                
+                <h3>Navigation Style</h3>
+                <div class="form-group">
+                    <label>Font Family</label>
+                    <select onchange="AdminEditor.updateConfig('navigation.style.fontFamily', this.value)">
+                        <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" ${nav.style.fontFamily.includes('Segoe UI') ? 'selected' : ''}>Segoe UI</option>
+                        <option value="'Arial', sans-serif" ${nav.style.fontFamily.includes('Arial') ? 'selected' : ''}>Arial</option>
+                        <option value="'Roboto', sans-serif" ${nav.style.fontFamily.includes('Roboto') ? 'selected' : ''}>Roboto</option>
+                        <option value="'Open Sans', sans-serif" ${nav.style.fontFamily.includes('Open Sans') ? 'selected' : ''}>Open Sans</option>
+                    </select>
+                </div>
+                <div class="form-group">
+                    <label>Text Color</label>
+                    <input type="color" value="${nav.style.textColor}" onchange="AdminEditor.updateConfig('navigation.style.textColor', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Background Color</label>
+                    <input type="color" value="${nav.style.backgroundColor}" onchange="AdminEditor.updateConfig('navigation.style.backgroundColor', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Hover Color</label>
+                    <input type="color" value="${nav.style.hoverColor}" onchange="AdminEditor.updateConfig('navigation.style.hoverColor', this.value)">
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Hero Settings
+     */
+    renderHeroSettings: function() {
+        const hero = this.config.hero;
+        return `
+            <h2>Hero Section</h2>
+            <div class="form-section">
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${hero.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('hero.enabled', this.checked)">
+                        Enable Hero Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${hero.title}" onchange="AdminEditor.updateConfig('hero.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Tagline</label>
+                    <input type="text" value="${hero.tagline}" onchange="AdminEditor.updateConfig('hero.tagline', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Button Text</label>
+                    <input type="text" value="${hero.buttonText}" onchange="AdminEditor.updateConfig('hero.buttonText', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Button Link</label>
+                    <input type="text" value="${hero.buttonLink}" onchange="AdminEditor.updateConfig('hero.buttonLink', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Background Image</label>
+                    <input type="text" value="${hero.backgroundImage}" onchange="AdminEditor.updateConfig('hero.backgroundImage', this.value)">
+                    <small>Image path relative to project root</small>
+                </div>
+                <div class="form-group">
+                    <label>Overlay Color</label>
+                    <input type="color" value="${this.hexToRgba(hero.overlayColor)}" onchange="AdminEditor.updateConfig('hero.overlayColor', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Text Color</label>
+                    <input type="color" value="${hero.textColor}" onchange="AdminEditor.updateConfig('hero.textColor', this.value)">
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Content Settings (Introduction, Overview, Services, etc.)
+     */
+    renderContentSettings: function() {
+        return `
+            <h2>Content Editor</h2>
+            
+            <div class="content-tabs">
+                <button class="tab-btn active" data-tab="introduction" onclick="AdminEditor.switchContentTab('introduction')">Introduction</button>
+                <button class="tab-btn" data-tab="overview" onclick="AdminEditor.switchContentTab('overview')">Overview</button>
+                <button class="tab-btn" data-tab="services" onclick="AdminEditor.switchContentTab('services')">Services</button>
+                <button class="tab-btn" data-tab="team" onclick="AdminEditor.switchContentTab('team')">Team</button>
+                <button class="tab-btn" data-tab="clients" onclick="AdminEditor.switchContentTab('clients')">Clients</button>
+                <button class="tab-btn" data-tab="gallery" onclick="AdminEditor.switchContentTab('gallery')">Gallery</button>
+                <button class="tab-btn" data-tab="contact" onclick="AdminEditor.switchContentTab('contact')">Contact</button>
+                <button class="tab-btn" data-tab="footer" onclick="AdminEditor.switchContentTab('footer')">Footer</button>
+            </div>
+            
+            <div id="content-editor-area">
+                ${this.renderIntroductionEditor()}
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Introduction Editor
+     */
+    renderIntroductionEditor: function() {
+        const intro = this.config.introduction;
+        return `
+            <div class="form-section content-tab-panel" id="tab-introduction">
+                <h3>Introduction Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${intro.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('introduction.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${intro.title}" onchange="AdminEditor.updateConfig('introduction.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Content Paragraphs</label>
+                    ${intro.content.map((p, i) => `
+                        <textarea rows="3" onchange="AdminEditor.updateConfig('introduction.content[${i}]', this.value)">${p}</textarea>
+                    `).join('')}
+                </div>
+                <div class="form-group">
+                    <label>Image</label>
+                    <input type="text" value="${intro.image}" onchange="AdminEditor.updateConfig('introduction.image', this.value)">
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Services Editor
+     */
+    renderServicesEditor: function() {
+        const services = this.config.services;
+        const layout = services.layout || { columns: 4, alignment: 'left', itemAlignment: 'left' };
+        return `
+            <div class="form-section content-tab-panel" id="tab-services" style="display:none;">
+                <h3>Services Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${services.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('services.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${services.title}" onchange="AdminEditor.updateConfig('services.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Subtitle</label>
+                    <input type="text" value="${services.subtitle}" onchange="AdminEditor.updateConfig('services.subtitle', this.value)">
+                </div>
+                
+                <!-- Layout Settings -->
+                <div class="layout-settings">
+                    <h4>📐 Layout Settings</h4>
+                    <div class="layout-controls">
+                        <div class="form-group">
+                            <label>Number of Columns</label>
+                            <select onchange="AdminEditor.updateConfig('services.layout.columns', parseInt(this.value))">
+                                <option value="1" ${layout.columns === 1 ? 'selected' : ''}>1 Column</option>
+                                <option value="2" ${layout.columns === 2 ? 'selected' : ''}>2 Columns</option>
+                                <option value="3" ${layout.columns === 3 ? 'selected' : ''}>3 Columns</option>
+                                <option value="4" ${layout.columns === 4 ? 'selected' : ''}>4 Columns</option>
+                            </select>
+                        </div>
+                        <div class="form-group">
+                            <label>Section Alignment</label>
+                            <select onchange="AdminEditor.updateConfig('services.layout.alignment', this.value)">
+                                <option value="left" ${layout.alignment === 'left' ? 'selected' : ''}>Align Left</option>
+                                <option value="center" ${layout.alignment === 'center' ? 'selected' : ''}>Align Center</option>
+                                <option value="right" ${layout.alignment === 'right' ? 'selected' : ''}>Align Right</option>
+                            </select>
+                        </div>
+                        <div class="form-group">
+                            <label>Item Alignment</label>
+                            <select onchange="AdminEditor.updateConfig('services.layout.itemAlignment', this.value)">
+                                <option value="left" ${layout.itemAlignment === 'left' ? 'selected' : ''}>Items Align Left</option>
+                                <option value="center" ${layout.itemAlignment === 'center' ? 'selected' : ''}>Items Align Center</option>
+                                <option value="right" ${layout.itemAlignment === 'right' ? 'selected' : ''}>Items Align Right</option>
+                            </select>
+                        </div>
+                    </div>
+                </div>
+                
+                <h4>Service Items</h4>
+                <div id="services-editor">
+                    ${services.items.map((service, index) => {
+                        const serviceLayout = service.layout || { column: (index % layout.columns) + 1, order: index + 1 };
+                        return `
+                        <div class="item-editor">
+                            <h5>Service ${index + 1}</h5>
+                            <div class="form-group">
+                                <label>Title</label>
+                                <input type="text" value="${service.title}" onchange="AdminEditor.updateConfig('services.items[${index}].title', this.value)">
+                            </div>
+                            <div class="form-group">
+                                <label>Icon (emoji)</label>
+                                <input type="text" value="${service.icon}" onchange="AdminEditor.updateConfig('services.items[${index}].icon', this.value)">
+                            </div>
+                            <div class="form-group">
+                                <label>Content</label>
+                                <textarea rows="4" onchange="AdminEditor.updateConfig('services.items[${index}].content', this.value)">${service.content}</textarea>
+                            </div>
+                            <div class="item-layout-controls">
+                                <div class="form-group">
+                                    <label>Column</label>
+                                    <select onchange="AdminEditor.updateConfig('services.items[${index}].layout.column', parseInt(this.value))">
+                                        ${[1,2,3,4].map(col => `<option value="${col}" ${serviceLayout.column === col ? 'selected' : ''}>Column ${col}</option>`).join('')}
+                                    </select>
+                                </div>
+                                <div class="form-group">
+                                    <label>Order/Row</label>
+                                    <input type="number" value="${serviceLayout.order}" min="1" onchange="AdminEditor.updateConfig('services.items[${index}].layout.order', parseInt(this.value))">
+                                </div>
+                            </div>
+                            <button type="button" class="btn-danger" onclick="AdminEditor.removeService(${index})">Remove Service</button>
+                        </div>
+                    `}).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addService()">+ Add Service</button>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Overview Editor
+     */
+    renderOverviewEditor: function() {
+        const overview = this.config.overview;
+        return `
+            <div class="form-section content-tab-panel" id="tab-overview" style="display:none;">
+                <h3>Company Overview</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${overview.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('overview.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${overview.title}" onchange="AdminEditor.updateConfig('overview.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Subtitle</label>
+                    <input type="text" value="${overview.subtitle}" onchange="AdminEditor.updateConfig('overview.subtitle', this.value)">
+                </div>
+                <h4>Mission</h4>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${overview.mission.title}" onchange="AdminEditor.updateConfig('overview.mission.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Icon</label>
+                    <input type="text" value="${overview.mission.icon}" onchange="AdminEditor.updateConfig('overview.mission.icon', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Content</label>
+                    <textarea rows="4" onchange="AdminEditor.updateConfig('overview.mission.content', this.value)">${overview.mission.content}</textarea>
+                </div>
+                <h4>Vision</h4>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${overview.vision.title}" onchange="AdminEditor.updateConfig('overview.vision.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Icon</label>
+                    <input type="text" value="${overview.vision.icon}" onchange="AdminEditor.updateConfig('overview.vision.icon', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Content</label>
+                    <textarea rows="4" onchange="AdminEditor.updateConfig('overview.vision.content', this.value)">${overview.vision.content}</textarea>
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Team Editor
+     */
+    renderTeamEditor: function() {
+        const team = this.config.team;
+        const layout = team.layout || { columns: 4, alignment: 'center', itemAlignment: 'center' };
+        return `
+            <div class="form-section content-tab-panel" id="tab-team" style="display:none;">
+                <h3>Team Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${team.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('team.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${team.title}" onchange="AdminEditor.updateConfig('team.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Subtitle</label>
+                    <input type="text" value="${team.subtitle}" onchange="AdminEditor.updateConfig('team.subtitle', this.value)">
+                </div>
+                
+                <!-- Layout Settings -->
+                <div class="layout-settings">
+                    <h4>📐 Layout Settings</h4>
+                    <div class="layout-controls">
+                        <div class="form-group">
+                            <label>Number of Columns</label>
+                            <select onchange="AdminEditor.updateConfig('team.layout.columns', parseInt(this.value))">
+                                <option value="1" ${layout.columns === 1 ? 'selected' : ''}>1 Column</option>
+                                <option value="2" ${layout.columns === 2 ? 'selected' : ''}>2 Columns</option>
+                                <option value="3" ${layout.columns === 3 ? 'selected' : ''}>3 Columns</option>
+                                <option value="4" ${layout.columns === 4 ? 'selected' : ''}>4 Columns</option>
+                            </select>
+                        </div>
+                        <div class="form-group">
+                            <label>Section Alignment</label>
+                            <select onchange="AdminEditor.updateConfig('team.layout.alignment', this.value)">
+                                <option value="left" ${layout.alignment === 'left' ? 'selected' : ''}>Align Left</option>
+                                <option value="center" ${layout.alignment === 'center' ? 'selected' : ''}>Align Center</option>
+                                <option value="right" ${layout.alignment === 'right' ? 'selected' : ''}>Align Right</option>
+                            </select>
+                        </div>
+                        <div class="form-group">
+                            <label>Item Alignment</label>
+                            <select onchange="AdminEditor.updateConfig('team.layout.itemAlignment', this.value)">
+                                <option value="left" ${layout.itemAlignment === 'left' ? 'selected' : ''}>Items Align Left</option>
+                                <option value="center" ${layout.itemAlignment === 'center' ? 'selected' : ''}>Items Align Center</option>
+                                <option value="right" ${layout.itemAlignment === 'right' ? 'selected' : ''}>Items Align Right</option>
+                            </select>
+                        </div>
+                    </div>
+                </div>
+                
+                <h4>Team Members</h4>
+                <div id="team-editor">
+                    ${team.members.map((member, index) => {
+                        const memberLayout = member.layout || { column: (index % layout.columns) + 1, order: index + 1 };
+                        return `
+                        <div class="item-editor">
+                            <h5>Team Member ${index + 1}</h5>
+                            <div class="form-group">
+                                <label>Name</label>
+                                <input type="text" value="${member.name}" onchange="AdminEditor.updateConfig('team.members[${index}].name', this.value)">
+                            </div>
+                            <div class="form-group">
+                                <label>Position</label>
+                                <input type="text" value="${member.position}" onchange="AdminEditor.updateConfig('team.members[${index}].position', this.value)">
+                            </div>
+                            <div class="form-group">
+                                <label>Photo</label>
+                                <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
+<input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'team', ${index})">
+                                ${member.image ? `<img src="${member.image}" alt="${member.name}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
+                            </div>
+                            <div class="item-layout-controls">
+                                <div class="form-group">
+                                    <label>Column</label>
+                                    <select onchange="AdminEditor.updateConfig('team.members[${index}].layout.column', parseInt(this.value))">
+                                        ${[1,2,3,4].map(col => `<option value="${col}" ${memberLayout.column === col ? 'selected' : ''}>Column ${col}</option>`).join('')}
+                                    </select>
+                                </div>
+                                <div class="form-group">
+                                    <label>Order/Row</label>
+                                    <input type="number" value="${memberLayout.order}" min="1" onchange="AdminEditor.updateConfig('team.members[${index}].layout.order', parseInt(this.value))">
+                                </div>
+                            </div>
+                            <button type="button" class="btn-danger" onclick="AdminEditor.removeTeamMember(${index})">Remove Member</button>
+                        </div>
+                    `}).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addTeamMember()">+ Add Team Member</button>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Gallery Editor
+     */
+    renderGalleryEditor: function() {
+        const gallery = this.config.gallery;
+        return `
+            <div class="form-section content-tab-panel" id="tab-gallery" style="display:none;">
+                <h3>Gallery Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${gallery.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('gallery.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${gallery.title}" onchange="AdminEditor.updateConfig('gallery.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Subtitle</label>
+                    <input type="text" value="${gallery.subtitle}" onchange="AdminEditor.updateConfig('gallery.subtitle', this.value)">
+                </div>
+                <h4>Gallery Images</h4>
+                <div id="gallery-editor">
+                    ${gallery.images.map((img, index) => `
+                        <div class="item-editor">
+                            <h5>Image ${index + 1}</h5>
+                            <div class="form-group">
+                                <label>Image Source</label>
+                                <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
+                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'gallery', ${index})">
+                            </div>
+                            <div class="form-group">
+                                <label>Alt Text</label>
+                                <input type="text" value="${img.alt}" onchange="AdminEditor.updateConfig('gallery.images[${index}].alt', this.value)">
+                            </div>
+                            ${img.src ? `<img src="${img.src}" alt="${img.alt}" style="max-width:100px;max-height:100px;margin-top:5px;">` : ''}
+                            <button type="button" class="btn-danger" onclick="AdminEditor.removeGalleryImage(${index})">Remove Image</button>
+                        </div>
+                    `).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addGalleryImage()">+ Add Gallery Image</button>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Contact Editor
+     */
+    renderContactEditor: function() {
+        const contact = this.config.contact;
+        return `
+            <div class="form-section content-tab-panel" id="tab-contact" style="display:none;">
+                <h3>Contact Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${contact.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('contact.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${contact.title}" onchange="AdminEditor.updateConfig('contact.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Subtitle</label>
+                    <input type="text" value="${contact.subtitle}" onchange="AdminEditor.updateConfig('contact.subtitle', this.value)">
+                </div>
+                <h4>Contact Information</h4>
+                <div class="form-group">
+                    <label>Company Name</label>
+                    <input type="text" value="${contact.company}" onchange="AdminEditor.updateConfig('contact.company', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Phone</label>
+                    <input type="text" value="${contact.phone}" onchange="AdminEditor.updateConfig('contact.phone', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Email</label>
+                    <input type="text" value="${contact.email}" onchange="AdminEditor.updateConfig('contact.email', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Address</label>
+                    <input type="text" value="${contact.address}" onchange="AdminEditor.updateConfig('contact.address', this.value)">
+                </div>
+                <h4>Contact Form</h4>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${contact.form.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('contact.form.enabled', this.checked)">
+                        Enable Contact Form
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Email To</label>
+                    <input type="text" value="${contact.form.emailTo}" onchange="AdminEditor.updateConfig('contact.form.emailTo', this.value)">
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Footer Editor
+     */
+    renderFooterEditor: function() {
+        const footer = this.config.footer;
+        return `
+            <div class="form-section content-tab-panel" id="tab-footer" style="display:none;">
+                <h3>Footer Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${footer.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('footer.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <h4>About Section</h4>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${footer.about.title}" onchange="AdminEditor.updateConfig('footer.about.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Content</label>
+                    <textarea rows="3" onchange="AdminEditor.updateConfig('footer.about.content', this.value)">${footer.about.content}</textarea>
+                </div>
+                <h4>Quick Links</h4>
+                <div id="footer-quicklinks-editor">
+                    ${footer.quickLinks.map((link, index) => `
+                        <div class="form-row">
+                            <input type="text" placeholder="Text" value="${link.text}" onchange="AdminEditor.updateConfig('footer.quickLinks[${index}].text', this.value)">
+                            <input type="text" placeholder="Link" value="${link.link}" onchange="AdminEditor.updateConfig('footer.quickLinks[${index}].link', this.value)">
+                            <button type="button" class="btn-danger" onclick="AdminEditor.removeFooterQuickLink(${index})">Remove</button>
+                        </div>
+                    `).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addFooterQuickLink()">+ Add Quick Link</button>
+                <h4>Services Links</h4>
+                <div id="footer-services-editor">
+                    ${footer.services.map((link, index) => `
+                        <div class="form-row">
+                            <input type="text" placeholder="Text" value="${link.text}" onchange="AdminEditor.updateConfig('footer.services[${index}].text', this.value)">
+                            <input type="text" placeholder="Link" value="${link.link}" onchange="AdminEditor.updateConfig('footer.services[${index}].link', this.value)">
+                            <button type="button" class="btn-danger" onclick="AdminEditor.removeFooterServiceLink(${index})">Remove</button>
+                        </div>
+                    `).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addFooterServiceLink()">+ Add Service Link</button>
+                <h4>Social Media</h4>
+                <div class="form-group">
+                    <label>Facebook</label>
+                    <input type="text" value="${footer.social.facebook}" onchange="AdminEditor.updateConfig('footer.social.facebook', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Twitter</label>
+                    <input type="text" value="${footer.social.twitter}" onchange="AdminEditor.updateConfig('footer.social.twitter', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>LinkedIn</label>
+                    <input type="text" value="${footer.social.linkedin}" onchange="AdminEditor.updateConfig('footer.social.linkedin', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Instagram</label>
+                    <input type="text" value="${footer.social.instagram}" onchange="AdminEditor.updateConfig('footer.social.instagram', this.value)">
+                </div>
+                <h4>Copyright</h4>
+                <div class="form-group">
+                    <label>Copyright Text</label>
+                    <input type="text" value="${footer.copyright}" onchange="AdminEditor.updateConfig('footer.copyright', this.value)">
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Clients Editor
+     */
+    renderClientsEditor: function() {
+        const clients = this.config.clients;
+        return `
+            <div class="form-section content-tab-panel" id="tab-clients" style="display:none;">
+                <h3>Clients Section</h3>
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${clients.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('clients.enabled', this.checked)">
+                        Enable Section
+                    </label>
+                </div>
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${clients.title}" onchange="AdminEditor.updateConfig('clients.title', this.value)">
+                </div>
+                <div class="form-group">
+                    <label>Subtitle</label>
+                    <input type="text" value="${clients.subtitle}" onchange="AdminEditor.updateConfig('clients.subtitle', this.value)">
+                </div>
+                <h4>Clients</h4>
+                <div id="clients-editor">
+                    ${clients.items.map((client, index) => `
+                        <div class="item-editor">
+                            <h5>Client ${index + 1}</h5>
+                            <div class="form-group">
+                                <label>Name</label>
+                                <input type="text" value="${client.name}" onchange="AdminEditor.updateConfig('clients.items[${index}].name', this.value)">
+                            </div>
+                            <div class="form-group">
+                                <label>Logo</label>
+                                <input type="text" value="${client.logo}" onchange="AdminEditor.updateConfig('clients.items[${index}].logo', this.value)">
+                                <input type="file" accept="image/*" onchange="AdminEditor.cropImage(this, 'client', ${index})">
+                            </div>
+                            <button type="button" class="btn-danger" onclick="AdminEditor.removeClient(${index})">Remove Client</button>
+                        </div>
+                    `).join('')}
+                </div>
+                <button type="button" class="btn-secondary" onclick="AdminEditor.addClient()">+ Add Client</button>
+            </div>
+        `;
+    },
+    
+    /**
+     * Add team member
+     */
+    addTeamMember: function() {
+        const layout = this.config.team.layout || { columns: 4 };
+        const newMember = {
+            name: 'New Team Member',
+            position: 'Position',
+            image: 'images/intro.jpg',
+            layout: {
+                column: (this.config.team.members.length % layout.columns) + 1,
+                order: this.config.team.members.length + 1
+            }
+        };
+        this.config.team.members.push(newMember);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Remove team member
+     */
+    removeTeamMember: function(index) {
+        if (confirm('Remove this team member?')) {
+            this.config.team.members.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Add gallery image
+     */
+    addGalleryImage: function() {
+        const newImage = {
+            src: 'images/intro.jpg',
+            alt: 'New Gallery Image'
+        };
+        this.config.gallery.images.push(newImage);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Remove gallery image
+     */
+    removeGalleryImage: function(index) {
+        if (confirm('Remove this image?')) {
+            this.config.gallery.images.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Add client
+     */
+    addClient: function() {
+        const newClient = {
+            name: 'New Client',
+            logo: ''
+        };
+        this.config.clients.items.push(newClient);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Remove client
+     */
+    removeClient: function(index) {
+        if (confirm('Remove this client?')) {
+            this.config.clients.items.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Add footer quick link
+     */
+    addFooterQuickLink: function() {
+        const newLink = {
+            text: 'New Link',
+            link: '#'
+        };
+        this.config.footer.quickLinks.push(newLink);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Remove footer quick link
+     */
+    removeFooterQuickLink: function(index) {
+        if (confirm('Remove this link?')) {
+            this.config.footer.quickLinks.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Add footer service link
+     */
+    addFooterServiceLink: function() {
+        const newLink = {
+            text: 'New Service',
+            link: '#'
+        };
+        this.config.footer.services.push(newLink);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Remove footer service link
+     */
+    removeFooterServiceLink: function(index) {
+        if (confirm('Remove this service link?')) {
+            this.config.footer.services.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Render Theme Settings
+     */
+    renderThemeSettings: function() {
+        const theme = this.config.theme;
+        return `
+            <h2>Theme & Colors</h2>
+            <div class="form-section">
+                <h3>Primary Colors</h3>
+                <div class="color-grid">
+                    <div class="form-group">
+                        <label>Primary</label>
+                        <input type="color" value="${theme.colors.primary}" onchange="AdminEditor.updateConfig('theme.colors.primary', this.value)">
+                        <input type="text" value="${theme.colors.primary}" onchange="AdminEditor.updateConfig('theme.colors.primary', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Primary Light</label>
+                        <input type="color" value="${theme.colors.primaryLight}" onchange="AdminEditor.updateConfig('theme.colors.primaryLight', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Primary Dark</label>
+                        <input type="color" value="${theme.colors.primaryDark}" onchange="AdminEditor.updateConfig('theme.colors.primaryDark', this.value)">
+                    </div>
+                </div>
+                
+                <h3>Secondary Colors</h3>
+                <div class="color-grid">
+                    <div class="form-group">
+                        <label>Secondary</label>
+                        <input type="color" value="${theme.colors.secondary}" onchange="AdminEditor.updateConfig('theme.colors.secondary', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Secondary Light</label>
+                        <input type="color" value="${theme.colors.secondaryLight}" onchange="AdminEditor.updateConfig('theme.colors.secondaryLight', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Secondary Dark</label>
+                        <input type="color" value="${theme.colors.secondaryDark}" onchange="AdminEditor.updateConfig('theme.colors.secondaryDark', this.value)">
+                    </div>
+                </div>
+                
+                <h3>Background Colors</h3>
+                <div class="color-grid">
+                    <div class="form-group">
+                        <label>Background Light</label>
+                        <input type="color" value="${theme.colors.backgroundLight}" onchange="AdminEditor.updateConfig('theme.colors.backgroundLight', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Background White</label>
+                        <input type="color" value="${theme.colors.backgroundWhite}" onchange="AdminEditor.updateConfig('theme.colors.backgroundWhite', this.value)">
+                    </div>
+                </div>
+                
+                <h3>Text Colors</h3>
+                <div class="color-grid">
+                    <div class="form-group">
+                        <label>Text Dark</label>
+                        <input type="color" value="${theme.colors.textDark}" onchange="AdminEditor.updateConfig('theme.colors.textDark', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Text Gray</label>
+                        <input type="color" value="${theme.colors.textGray}" onchange="AdminEditor.updateConfig('theme.colors.textGray', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Text Light</label>
+                        <input type="color" value="${theme.colors.textLight}" onchange="AdminEditor.updateConfig('theme.colors.textLight', this.value)">
+                    </div>
+                </div>
+                
+                <h3>Button Colors</h3>
+                <div class="color-grid">
+                    <div class="form-group">
+                        <label>Primary Button</label>
+                        <input type="color" value="${theme.buttons.primary}" onchange="AdminEditor.updateConfig('theme.buttons.primary', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Secondary Button</label>
+                        <input type="color" value="${theme.buttons.secondary}" onchange="AdminEditor.updateConfig('theme.buttons.secondary', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Hover</label>
+                        <input type="color" value="${theme.buttons.hover}" onchange="AdminEditor.updateConfig('theme.buttons.hover', this.value)">
+                    </div>
+                </div>
+                
+                <h3>Typography</h3>
+                <div class="form-group">
+                    <label>Primary Font</label>
+                    <select onchange="AdminEditor.updateConfig('theme.fonts.primary', this.value)">
+                        <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" ${theme.fonts.primary.includes('Segoe UI') ? 'selected' : ''}>Segoe UI</option>
+                        <option value="'Arial', sans-serif" ${theme.fonts.primary.includes('Arial') ? 'selected' : ''}>Arial</option>
+                        <option value="'Roboto', sans-serif" ${theme.fonts.primary.includes('Roboto') ? 'selected' : ''}>Roboto</option>
+                        <option value="'Open Sans', sans-serif" ${theme.fonts.primary.includes('Open Sans') ? 'selected' : ''}>Open Sans</option>
+                        <option value="'Poppins', sans-serif" ${theme.fonts.primary.includes('Poppins') ? 'selected' : ''}>Poppins</option>
+                    </select>
+                </div>
+                
+                <button type="button" class="btn-primary" onclick="AdminEditor.previewTheme()">Preview Theme</button>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Image Settings
+     */
+    renderImageSettings: function() {
+        return `
+            <h2>Image Management</h2>
+            <div class="form-section">
+                <p>Upload new images or change image paths. Images are stored in the images folder.</p>
+                
+                <div class="image-uploader">
+                    <h3>Hero Background</h3>
+                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'hero')">
+                    <input type="text" value="${this.config.hero.backgroundImage}" placeholder="Or enter image URL">
+                </div>
+                
+                <div class="image-uploader">
+                    <h3>Introduction Image</h3>
+                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'intro')">
+                    <input type="text" value="${this.config.introduction.image}" placeholder="Or enter image URL">
+                </div>
+                
+                <div class="image-uploader">
+                    <h3>Popup Image</h3>
+                    <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'popup')">
+                    <input type="text" value="${this.config.popup.image}" placeholder="Or enter image URL">
+                </div>
+                
+                <h3>Team Photos</h3>
+                <div class="image-grid">
+                    ${this.config.team.members.map((member, index) => `
+                        <div class="image-item">
+                            <label>${member.name}</label>
+                            <input type="text" value="${member.image}" onchange="AdminEditor.updateConfig('team.members[${index}].image', this.value)">
+                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'team', ${index})">
+                        </div>
+                    `).join('')}
+                </div>
+                
+                <h3>Gallery Images</h3>
+                <div class="image-grid">
+                    ${this.config.gallery.images.map((img, index) => `
+                        <div class="image-item">
+                            <label>Image ${index + 1}</label>
+                            <input type="text" value="${img.src}" onchange="AdminEditor.updateConfig('gallery.images[${index}].src', this.value)">
+                            <input type="file" accept="image/*" onchange="AdminEditor.uploadImage(this, 'gallery', ${index})">
+                        </div>
+                    `).join('')}
+                </div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render Popup Settings
+     */
+    renderPopupSettings: function() {
+        const popup = this.config.popup;
+        return `
+            <h2>Popup Editor</h2>
+            <div class="form-section">
+                <div class="form-group">
+                    <label>
+                        <input type="checkbox" ${popup.enabled ? 'checked' : ''} onchange="AdminEditor.updateConfig('popup.enabled', this.checked)">
+                        Enable Popup
+                    </label>
+                </div>
+                
+                <div class="form-group">
+                    <label>Title</label>
+                    <input type="text" value="${popup.title}" onchange="AdminEditor.updateConfig('popup.title', this.value)">
+                </div>
+                
+                <div class="form-group">
+                    <label>Description</label>
+                    <textarea rows="4" onchange="AdminEditor.updateConfig('popup.description', this.value)">${popup.description}</textarea>
+                </div>
+                
+                <div class="form-group">
+                    <label>Image</label>
+                    <input type="text" value="${popup.image}" onchange="AdminEditor.updateConfig('popup.image', this.value)">
+                </div>
+                
+                <div class="form-group">
+                    <label>Button Text</label>
+                    <input type="text" value="${popup.buttonText}" onchange="AdminEditor.updateConfig('popup.buttonText', this.value)">
+                </div>
+                
+                <div class="form-group">
+                    <label>Button Link</label>
+                    <input type="text" value="${popup.buttonLink}" onchange="AdminEditor.updateConfig('popup.buttonLink', this.value)">
+                </div>
+                
+                <h3>Colors</h3>
+                <div class="color-grid">
+                    <div class="form-group">
+                        <label>Background Color</label>
+                        <input type="color" value="${this.hexToRgba(popup.backgroundColor)}" onchange="AdminEditor.updateConfig('popup.backgroundColor', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Text Color</label>
+                        <input type="color" value="${popup.textColor}" onchange="AdminEditor.updateConfig('popup.textColor', this.value)">
+                    </div>
+                    <div class="form-group">
+                        <label>Button Color</label>
+                        <input type="color" value="${popup.buttonColor}" onchange="AdminEditor.updateConfig('popup.buttonColor', this.value)">
+                    </div>
+                </div>
+                
+                <div class="form-group">
+                    <label>Show Again Duration (days)</label>
+                    <input type="number" value="${popup.showAgainDuration}" min="1" max="30" onchange="AdminEditor.updateConfig('popup.showAgainDuration', parseInt(this.value))">
+                </div>
+                
+                <button type="button" class="btn-secondary" onclick="AdminEditor.testPopup()">Test Popup</button>
+            </div>
+        `;
+    },
+    
+    /**
+     * Render GitHub Settings
+     */
+    renderGitHubSettings: function() {
+        const github = this.config.github;
+        return `
+            <h2>GitHub Publish Panel</h2>
+            <div class="form-section">
+                <div class="form-group">
+                    <label>Repository URL</label>
+                    <input type="text" id="github-repo" value="${github.repoUrl}" placeholder="https://github.com/username/repo" onchange="AdminEditor.updateConfig('github.repoUrl', this.value)">
+                </div>
+                
+                <div class="form-group">
+                    <label>GitHub Username</label>
+                    <input type="text" id="github-username" value="${github.username}" placeholder="username" onchange="AdminEditor.updateConfig('github.username', this.value)">
+                </div>
+                
+                <div class="form-group">
+                    <label>Personal Access Token</label>
+                    <input type="password" id="github-token" value="${github.token}" placeholder="ghp_xxxxxxxxxxxx" onchange="AdminEditor.updateConfig('github.token', this.value)">
+                    <small>Create a token with 'repo' scope at GitHub Settings > Developer settings > Personal access tokens</small>
+                </div>
+                
+                <div class="form-group">
+                    <label>Branch</label>
+                    <input type="text" id="github-branch" value="${github.branch}" placeholder="main" onchange="AdminEditor.updateConfig('github.branch', this.value)">
+                </div>
+                
+                <div class="button-group">
+                    <button type="button" class="btn-secondary" onclick="AdminEditor.testGitHubConnection()">Test Connection</button>
+                    <button type="button" class="btn-primary" onclick="AdminEditor.publishToGitHub()">Publish Website</button>
+                </div>
+                
+                <div id="github-status" class="status-message"></div>
+            </div>
+        `;
+    },
+    
+    /**
+     * Setup section-specific event listeners
+     */
+    setupSectionListeners: function() {
+        // This is called after rendering each section
+        // Additional event listeners can be added here
+    },
+    
+    /**
+     * Update configuration value
+     */
+    updateConfig: function(path, value) {
+        const keys = path.split('.');
+        let obj = this.config;
+        
+        for (let i = 0; i < keys.length - 1; i++) {
+            const key = keys[i];
+            // Handle array indices
+            const match = key.match(/^(\w+)\[(\d+)\]$/);
+            if (match) {
+                if (!obj[match[1]]) obj[match[1]] = [];
+                obj = obj[match[1]];
+                i++;
+                key = keys[i];
+            }
+            obj = obj[key];
+        }
+        
+        const lastKey = keys[keys.length - 1];
+        const arrayMatch = lastKey.match(/^(\w+)\[(\d+)\]$/);
+        
+        if (arrayMatch) {
+            obj[arrayMatch[1]][parseInt(arrayMatch[2])] = value;
+        } else {
+            obj[lastKey] = value;
+        }
+        
+        this.hasChanges = true;
+    },
+    
+    /**
+     * Add menu item
+     */
+    addMenuItem: function() {
+        const newItem = {
+            text: 'New Item',
+            link: '#section',
+            order: this.config.navigation.menu.length + 1
+        };
+        this.config.navigation.menu.push(newItem);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Update menu item
+     */
+    updateMenuItem: function(index, field, value) {
+        this.config.navigation.menu[index][field] = value;
+        this.hasChanges = true;
+    },
+    
+    /**
+     * Remove menu item
+     */
+    removeMenuItem: function(index) {
+        if (confirm('Remove this menu item?')) {
+            this.config.navigation.menu.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Add service
+     */
+    addService: function() {
+        const newService = {
+            title: 'New Service',
+            icon: '✨',
+            content: 'Service description here.'
+        };
+        this.config.services.items.push(newService);
+        this.hasChanges = true;
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Remove service
+     */
+    removeService: function(index) {
+        if (confirm('Remove this service?')) {
+            this.config.services.items.splice(index, 1);
+            this.hasChanges = true;
+            this.renderCurrentSection();
+        }
+    },
+    
+    /**
+     * Switch content tab
+     */
+    switchContentTab: function(tab) {
+        const self = AdminEditor;
+        document.querySelectorAll('.tab-btn').forEach(btn => {
+            btn.classList.toggle('active', btn.dataset.tab === tab);
+        });
+        
+        // Hide all panels
+        document.querySelectorAll('.content-tab-panel').forEach(panel => {
+            panel.style.display = 'none';
+        });
+        
+        // Show selected panel
+        const panel = document.getElementById('tab-' + tab);
+        if (panel) {
+            panel.style.display = 'block';
+        } else {
+            // Render the panel if not exists
+            const contentArea = document.getElementById('content-editor-area');
+            switch(tab) {
+                case 'introduction':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'overview':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'services':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'team':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'gallery':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'contact':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'footer':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                case 'clients':
+                    contentArea.innerHTML = self.renderIntroductionEditor() + self.renderOverviewEditor() + self.renderServicesEditor() + self.renderTeamEditor() + self.renderGalleryEditor() + self.renderContactEditor() + self.renderFooterEditor() + self.renderClientsEditor();
+                    break;
+                default:
+                    contentArea.innerHTML = '<p>Editor coming soon for this section.</p>';
+            }
+        }
+    },
+    
+    /**
+     * Crop and upload image
+     */
+    cropImage: function(input, type, index) {
+        const file = input.files[0];
+        if (!file) return;
+        
+        // Create cropper modal
+        this.createCropperModal(file, type, index);
+    },
+    
+    /**
+     * Create cropper modal
+     */
+    createCropperModal: function(file, type, index) {
+        const reader = new FileReader();
+        reader.onload = function(e) {
+            const imgData = e.target.result;
+            
+            // Create modal
+            const modal = document.createElement('div');
+            modal.id = 'cropper-modal';
+            modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:10000;display:flex;justify-content:center;align-items:center;flex-direction:column;';
+            
+            const modalContent = document.createElement('div');
+            modalContent.style.cssText = 'background:white;padding:20px;border-radius:8px;max-width:90%;max-height:90%;overflow:auto;';
+            
+            const title = document.createElement('h3');
+            title.textContent = 'Crop Image';
+            title.style.marginTop = '0';
+            
+            const imgContainer = document.createElement('div');
+            imgContainer.style.cssText = 'max-width:100%;max-height:400px;overflow:hidden;margin:15px 0;';
+            
+            const img = document.createElement('img');
+            img.src = imgData;
+            img.id = 'cropper-image';
+            img.style.cssText = 'max-width:100%;max-height:400px;';
+            
+            imgContainer.appendChild(img);
+            
+            // Crop controls
+            const controls = document.createElement('div');
+            controls.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap;margin-bottom:15px;';
+            
+            const aspectLabel = document.createElement('label');
+            aspectLabel.textContent = 'Aspect Ratio: ';
+            controls.appendChild(aspectLabel);
+            
+            const aspectSelect = document.createElement('select');
+            aspectSelect.id = 'aspect-ratio';
+            aspectSelect.style.cssText = 'padding:5px;margin-bottom:5px;';
+            aspectSelect.innerHTML = `
+                <option value="0">Free</option>
+                <option value="1">1:1</option>
+                <option value="4/3">4:3</option>
+                <option value="16/9">16:9</option>
+                <option value="3/4">3:4</option>
+            `;
+            controls.appendChild(aspectSelect);
+            
+            const buttonGroup = document.createElement('div');
+            buttonGroup.style.cssText = 'display:flex;gap:10px;margin-top:10px;';
+            
+            const cropBtn = document.createElement('button');
+            cropBtn.textContent = 'Apply Crop';
+            cropBtn.className = 'btn btn-primary';
+            cropBtn.onclick = function() { AdminEditor.applyCrop(img, type, index, modal); };
+            
+            const cancelBtn = document.createElement('button');
+            cancelBtn.textContent = 'Cancel';
+            cancelBtn.className = 'btn btn-secondary';
+            cancelBtn.onclick = function() { modal.remove(); };
+            
+            const resetBtn = document.createElement('button');
+            resetBtn.textContent = 'Reset';
+            resetBtn.className = 'btn btn-secondary';
+            resetBtn.onclick = function() { 
+                if (img.cropper) {
+                    img.cropper.reset();
+                }
+            };
+            
+            buttonGroup.appendChild(cropBtn);
+            buttonGroup.appendChild(resetBtn);
+            buttonGroup.appendChild(cancelBtn);
+            
+            modalContent.appendChild(title);
+            modalContent.appendChild(controls);
+            modalContent.appendChild(imgContainer);
+            modalContent.appendChild(buttonGroup);
+            modal.appendChild(modalContent);
+            document.body.appendChild(modal);
+            
+            // Initialize Cropper.js if available, otherwise use simple crop
+            if (typeof Cropper !== 'undefined') {
+                const cropper = new Cropper(img, {
+                    aspectRatio: NaN,
+                    viewMode: 1,
+                    ready: function() {
+                        aspectSelect.addEventListener('change', function() {
+                            const value = this.value;
+                            if (value === '0') {
+                                cropper.setAspectRatio(NaN);
+                            } else {
+                                cropper.setAspectRatio(eval(value));
+                            }
+                        });
+                    }
+                });
+                img.cropper = cropper;
+            } else {
+                // Simple crop without library - use canvas
+                AdminEditor.setupSimpleCrop(img, modal, type, index);
+            }
+        };
+        reader.readAsDataURL(file);
+    },
+    
+    /**
+     * Setup simple crop without external library
+     */
+    setupSimpleCrop: function(img, modal, type, index) {
+        const modalContent = modal.querySelector('div');
+        const imgContainer = modalContent.querySelector('div');
+        
+        // Add crop coordinates inputs
+        const cropControls = document.createElement('div');
+        cropControls.id = 'simple-crop-controls';
+        cropControls.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:15px 0;';
+        cropControls.innerHTML = `
+            <div>
+                <label>X Position: <input type="number" id="crop-x" value="0" min="0" style="width:60px;"></label>
+            </div>
+            <div>
+                <label>Y Position: <input type="number" id="crop-y" value="0" min="0" style="width:60px;"></label>
+            </div>
+            <div>
+                <label>Width: <input type="number" id="crop-width" value="200" min="50" style="width:60px;"></label>
+            </div>
+            <div>
+                <label>Height: <input type="number" id="crop-height" value="200" min="50" style="width:60px;"></label>
+            </div>
+        `;
+        
+        // Insert before button group
+        const buttonGroup = modalContent.querySelector('div:last-child');
+        modalContent.insertBefore(cropControls, buttonGroup);
+        
+        // Update crop button
+        const cropBtn = buttonGroup.querySelector('button:first-child');
+        cropBtn.onclick = function() {
+            const x = parseInt(document.getElementById('crop-x').value) || 0;
+            const y = parseInt(document.getElementById('crop-y').value) || 0;
+            const width = parseInt(document.getElementById('crop-width').value) || 200;
+            const height = parseInt(document.getElementById('crop-height').value) || 200;
+            
+            AdminEditor.applySimpleCrop(img.src, x, y, width, height, type, index, modal);
+        };
+    },
+    
+    /**
+     * Apply simple crop using canvas
+     */
+    applySimpleCrop: function(imgData, x, y, width, height, type, index, modal) {
+        const canvas = document.createElement('canvas');
+        const ctx = canvas.getContext('2d');
+        
+        const img = new Image();
+        img.onload = function() {
+            canvas.width = width;
+            canvas.height = height;
+            
+            // Draw cropped portion
+            ctx.drawImage(img, x, y, width, height, 0, 0, width, height);
+            
+            // Get cropped data as base64
+            const croppedData = canvas.toDataURL('image/jpeg', 0.9);
+            
+            // Update config
+            AdminEditor.saveCroppedImage(croppedData, type, index);
+            
+            // Close modal
+            modal.remove();
+        };
+        img.src = imgData;
+    },
+    
+    /**
+     * Apply crop (with Cropper.js)
+     */
+    applyCrop: function(img, type, index, modal) {
+        if (img.cropper) {
+            const canvas = img.cropper.getCroppedCanvas({
+                maxWidth: 1200,
+                maxHeight: 1200,
+                imageSmoothingEnabled: true,
+                imageSmoothingQuality: 'high'
+            });
+            
+            const croppedData = canvas.toDataURL('image/jpeg', 0.9);
+            this.saveCroppedImage(croppedData, type, index);
+            modal.remove();
+        } else {
+            // Use simple crop
+            this.applySimpleCrop(img.src, 
+                parseInt(document.getElementById('crop-x').value) || 0,
+                parseInt(document.getElementById('crop-y').value) || 0,
+                parseInt(document.getElementById('crop-width').value) || 200,
+                parseInt(document.getElementById('crop-height').value) || 200,
+                type, index, modal);
+        }
+    },
+    
+    /**
+     * Save cropped image to config
+     */
+    saveCroppedImage: function(base64Data, type, index) {
+        // In a real implementation, this would upload to server
+        // For demo, we'll use the base64 data directly or save locally
+        
+        console.log('Image cropped:', type, index);
+        
+        // Update the config based on type
+        switch(type) {
+            case 'hero':
+                this.updateConfig('hero.backgroundImage', base64Data);
+                break;
+            case 'intro':
+                this.updateConfig('introduction.image', base64Data);
+                break;
+            case 'popup':
+                this.updateConfig('popup.image', base64Data);
+                break;
+            case 'team':
+                this.updateConfig('team.members[' + index + '].image', base64Data);
+                break;
+            case 'gallery':
+                this.updateConfig('gallery.images[' + index + '].src', base64Data);
+                break;
+            case 'client':
+                this.updateConfig('clients.items[' + index + '].logo', base64Data);
+                break;
+        }
+        
+        this.hasChanges = true;
+        this.showNotification('Image cropped and applied!', 'success');
+        
+        // Re-render to show changes
+        this.renderCurrentSection();
+    },
+    
+    /**
+     * Upload image
+     */
+    uploadImage: function(input, type, index) {
+        const file = input.files[0];
+        if (!file) return;
+        
+        const reader = new FileReader();
+        reader.onload = function(e) {
+            const base64 = e.target.result;
+            // In a real implementation, this would upload to server
+            // For now, we'll use localStorage for preview
+            console.log('Image uploaded:', type, index);
+            AdminEditor.showNotification('Image uploaded! In production, this would be saved to the server.', 'info');
+        };
+        reader.readAsDataURL(file);
+    },
+    
+    /**
+     * Preview theme
+     */
+    previewTheme: function() {
+        // Save current config and open preview
+        const previewWindow = window.open('index.html', '_blank');
+        this.showNotification('Preview will open in a new tab with current settings', 'info');
+    },
+    
+    /**
+     * Test popup
+     */
+    testPopup: function() {
+        // Reset popup to show
+        localStorage.removeItem('edc_popup_dismissed');
+        
+        // Open index.html to test
+        const previewWindow = window.open('index.html', '_blank');
+        this.showNotification('Popup will appear when the page loads', 'info');
+    },
+    
+    /**
+     * Test GitHub connection
+     */
+    async testGitHubConnection() {
+        const statusDiv = document.getElementById('github-status');
+        statusDiv.innerHTML = '<p>Testing connection...</p>';
+        statusDiv.className = 'status-message info';
+        
+        // Update config from inputs
+        this.config.github.repoUrl = document.getElementById('github-repo').value;
+        this.config.github.token = document.getElementById('github-token').value;
+        
+        GitHubPublisher.setConfig(this.config.github);
+        const result = await GitHubPublisher.testConnection();
+        
+        if (result.success) {
+            statusDiv.innerHTML = `<p class="success">✓ ${result.message}</p>`;
+            statusDiv.className = 'status-message success';
+        } else {
+            statusDiv.innerHTML = `<p class="error">✗ ${result.message}</p>`;
+            statusDiv.className = 'status-message error';
+        }
+    },
+    
+    /**
+     * Publish to GitHub
+     */
+    async publishToGitHub() {
+        // First save config
+        await this.saveConfig(false);
+        
+        const statusDiv = document.getElementById('github-status');
+        statusDiv.innerHTML = '<p>Publishing to GitHub...</p>';
+        statusDiv.className = 'status-message info';
+        
+        // Update config from inputs
+        this.config.github.repoUrl = document.getElementById('github-repo').value;
+        this.config.github.token = document.getElementById('github-token').value;
+        this.config.github.branch = document.getElementById('github-branch').value;
+        
+        GitHubPublisher.setConfig(this.config.github);
+        
+        const files = [
+            { path: 'index.html', message: 'Update index.html' },
+            { path: 'data/site-config.json', message: 'Update site configuration' },
+            { path: 'css/style.css', message: 'Update styles' }
+        ];
+        
+        GitHubPublisher.publish(
+            files,
+            (progress) => {
+                statusDiv.innerHTML = `<p>${progress}</p>`;
+            },
+            (results) => {
+                const allSuccess = results.every(r => r.success);
+                if (allSuccess) {
+                    statusDiv.innerHTML = '<p class="success">✓ All files published successfully!</p>';
+                    statusDiv.className = 'status-message success';
+                } else {
+                    const errors = results.filter(r => !r.success).map(r => r.error).join(', ');
+                    statusDiv.innerHTML = `<p class="error">✗ Some files failed: ${errors}</p>`;
+                    statusDiv.className = 'status-message error';
+                }
+            },
+            (error) => {
+                statusDiv.innerHTML = `<p class="error">✗ ${error}</p>`;
+                statusDiv.className = 'status-message error';
+            }
+        );
+    },
+    
+    /**
+     * Preview site
+     */
+    previewSite: function() {
+        // Save current config
+        this.saveConfig(false).then(() => {
+            window.open('index.html', '_blank');
+        });
+    },
+    
+    /**
+     * Setup auto-save
+     */
+    setupAutoSave: function() {
+        // Auto-save every 5 minutes
+        setInterval(() => {
+            if (this.hasChanges) {
+                this.saveConfig(false);
+                console.log('Auto-saved configuration');
+            }
+        }, 300000);
+    },
+    
+    /**
+     * Show notification
+     */
+    showNotification: function(message, type = 'info') {
+        const notification = document.createElement('div');
+        notification.className = `notification notification-${type}`;
+        notification.textContent = message;
+        
+        document.body.appendChild(notification);
+        
+        setTimeout(() => {
+            notification.classList.add('show');
+        }, 10);
+        
+        setTimeout(() => {
+            notification.classList.remove('show');
+            setTimeout(() => notification.remove(), 300);
+        }, 3000);
+    },
+    
+    /**
+     * Convert hex to rgba
+     */
+    hexToRgba: function(hex) {
+        if (hex.startsWith('rgba')) return hex;
+        
+        const r = parseInt(hex.slice(1, 3), 16);
+        const g = parseInt(hex.slice(3, 5), 16);
+        const b = parseInt(hex.slice(5, 7), 16);
+        
+        return `rgba(${r}, ${g}, ${b}, 0.85)`;
+    }
+};
+
+// Make globally available
+window.AdminEditor = AdminEditor;

[Please review the diff. You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build.]
Important: You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
server.js
js/admin-editor.js

## 🤖 Assistant #58

_2026-03-12 06:37:03Z_

Now let me restart the server to apply all the changes:

<minimax:tool_call>
<execute_command>
<command>wmic process where "name='node.exe'" delete</command>
</execute_command>

## 💬 User #59

_2026-03-12 06:37:03Z_

[execute_command for 'wmic process where "name='node.exe'" delete'] Result:

Command executed.
Output:
Deleting instance \\BRYLLE\ROOT\CIMV2:Win32_Process.Handle="30084"
Instance deletion successful.
Deleting instance \\BRYLLE\ROOT\CIMV2:Win32_Process.Handle="5344"
Instance deletion successful.
Deleting instance \\BRYLLE\ROOT\CIMV2:Win32_Process.Handle="20964"
Instance deletion successful.
Deleting instance \\BRYLLE\ROOT\CIMV2:Win32_Process.Handle="11308"
Instance deletion successful.

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
server.js
js/admin-editor.js

## 🤖 Assistant #60

_2026-03-12 06:37:03Z_

<minimax:tool_call>
<execute_command>
<command>cmd /c "cd /d c:\Users\ACER\Desktop\EDC,LTD && node server.js"</command>
</execute_command>

## 💬 User #61

_2026-03-12 06:37:03Z_

[execute_command for 'cmd /c "cd /d c:\Users\ACER\Desktop\EDC,LTD && node server.js"'] Result:

Command is still running in the user's terminal.
Here's the output so far:
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   EDC Website Server                                       ║
║   Running at: http://localhost:3000                       ║
║                                                            ║
║   Public Website: http://localhost:3000/index.html       ║
║   Admin Panel:    http://localhost:3000/admin.html       ║
║                                                            ║
║   Press Ctrl+C to stop the server                          ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝

You will be updated on the terminal status and new output in the future.

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
index.html
server.js
js/admin-editor.js

# Actively Running Terminals
## Original command: `cmd /c "cd /d c:\Users\ACER\Desktop\EDC,LTD && node server.js"`

## 🤖 Assistant #62

_2026-03-12 06:37:03Z_

The server is now running. Let me summarize the fixes I made:

<minimax:tool_call>
<attempt_completion>
<parameter name="result">**Fixed the following issues:**

1. **404 Error (Fixed):** Added a catch-all route in server.js to serve files that exist or fall back to index.html for SPA-like behavior.

2. **JavaScript Error - "renderClientsEditor is not a function" (Fixed):** 
   - The issue was in the `switchContentTab` function where `this` didn't refer to the AdminEditor object when called from inline onclick handlers
   - Fixed by using `const self = AdminEditor;` to properly reference the object

3. **Image Upload Support (Enhanced):**
   - Updated server.js to accept all common image types: jpeg, jpg, png, gif, webp, svg, bmp, tiff, ico, avif, heic, heif

**Server is now running at:**
- **Website:** http://localhost:3000/index.html
- **Admin Panel:** http://localhost:3000/admin.html

Please refresh the admin panel to test the fixes!</parameter>
</attempt_completion>

