---
title: "Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy: Cross"
created: 2026-03-07T05:11:40.759Z
updated: 2026-03-07T05:16:35.933Z
source: "Blackbox AI"
model: "minimax-m2-minimax-m2"
---

# Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy: Cross

**Created**: 3/7/2026, 1:11:40 PM
**Messages**: 32 (User: 16, Assistant: 16)
**Session ID**: `1772860300733`
**Model**: minimax-m2-minimax-m2


---

## 💬 User #1

_2026-03-12 06:37:03Z_

<task>
Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy: Cross origin requests are only supported for protocol schemes: chrome, chrome-extension, chrome-untrusted, data, http, https, isolated-app.Understand this error
/C:/api/config:1  Failed to load resource: net::ERR_FAILEDUnderstand this error
admin-editor.js:37 Error loading config: TypeError: Failed to fetch
    at Object.loadConfig (admin-editor.js:30:36)
    at Object.init (admin-editor.js:17:20)
    at HTMLDocument.<anonymous> (admin.html:120:25)
loadConfig @ admin-editor.js:37Understand this error
admin-editor.js:180 Uncaught (in promise) TypeError: Cannot read properties of null (reading 'site')
</task>

Environment details:

# VSCode Visible Files
js/load-site.js

# VSCode Open Tabs
admin.html
js/admin-editor.js
index.html
js/load-site.js

# Current Working Directory (c:/Users/ACER/Desktop/EDC,LTD) Files
admin.html
index.html
navbar.html
package-lock.json
package.json
README.md
server.js
css/
css/admin.css
css/style.css
data/
data/site-config.json
images/
images/intro.jpg
images/gallery/
js/
js/admin-editor.js
js/animations.js
js/github-publisher.js
js/load-site.js
js/navbar-loader.js
js/popup.js

## 🤖 Assistant #2

_2026-03-12 06:37:03Z_

💭 思考过程：
The user is encountering a CORS (Cross-Origin Resource Sharing) error when trying to fetch a local file using the `file://` protocol. This is a common issue when developing web applications that try to access local files directly from the browser.

Let me understand the error:
1. The error message says: "Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy"
2. This means the JavaScript code is trying to fetch a file using the file:// protocol, which browsers block for security reasons.
3. The code is in `admin-editor.js` and it's trying to load a config file.

Let me first read the relevant files to understand the code structure and find where this issue is occurring.

I'll analyze this CORS error and explore the relevant files to understand and fix the issue.


🔧 工具调用: read_file

## 💬 User #3

_2026-03-12 06:37:03Z_

📋 工具结果: /**
 * ============================================
 * ADMIN EDITOR - Visual Content Editor
 * Allows editing all site configuration from admin panel
 * ============================================
 */

const AdminEditor = {
    config: null,
    currentSection: 'general',
    hasChanges: false,
    
    /**
     * Initialize the admin editor
     */
    init: async function() {
        await this.loadConfig();
        this.setupEventListeners();
        this.renderCurrentSecti...

Environment details:

# VSCode Visible Files
js/load-site.js

# VSCode Open Tabs
admin.html
js/admin-editor.js
index.html
js/load-site.js

## 🤖 Assistant #4

_2026-03-12 06:37:03Z_

💭 思考过程：
Now I understand the issue. The error is:
1. CORS policy error when trying to fetch from 'file:///C:/api/config'
2. The code in `admin-editor.js` is trying to fetch from `/api/config` which is a server-side route

Let me also check the server.js to see what API endpoints are available and understand how the config is being served.

Let me also check the server.js to understand the API endpoints and the load-site.js file to see how it handles config loading:


🔧 工具调用: read_file

## 💬 User #5

_2026-03-12 06:37:03Z_

📋 工具结果: /**
 * ============================================
 * EDC WEBSITE BACKEND SERVER
 * Local server for handling admin operations
 * ============================================
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.us...

Environment details:

# VSCode Visible Files
js/load-site.js

# VSCode Open Tabs
admin.html
js/admin-editor.js
index.html
js/load-site.js

## 🤖 Assistant #6

_2026-03-12 06:37:03Z_

💭 思考过程：
Now I understand the issue clearly:

**The Problem:**
The error `Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy` indicates that the user is trying to open `admin.html` directly from the file system (file:// protocol) instead of through the local server (http://localhost:3000).

When you open an HTML file directly in the browser using `file://`, the browser's origin is set to `null`, and the browser's CORS policy prevents fetching resources from relative paths like `/api/config`.

**The Solution:**
The user needs to run the server first and then access the admin panel through `http://localhost:3000/admin` instead of opening the file directly.

Let me also check if there's a package.json to see what dependencies are available and verify how to start the server.

Now I understand the issue completely. Let me also check the package.json to confirm the project setup:


🔧 工具调用: read_file

## 💬 User #7

_2026-03-12 06:37:03Z_

📋 工具结果: {
  "name": "edc-website",
  "version": "1.0.0",
  "description": "English Development Consultants Co. Ltd. - Responsive Company Profile Website with Admin Dashboard",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "node server.js"
  },
  "keywords": [
    "company-profile",
    "education",
    "consulting",
    "admin-dashboard",
    "responsive"
  ],
  "author": "EDC",
  "license": "MIT",
  "dependencies": {
    "body-parser": "^1.20.2",
  ...

Environment details:

# VSCode Visible Files
js/load-site.js

# VSCode Open Tabs
admin.html
js/admin-editor.js
index.html
js/load-site.js

## 🤖 Assistant #8

_2026-03-12 06:37:03Z_

💭 思考过程：
Now I have a complete understanding of the issue. Let me summarize and create a plan.

## Issue Analysis

The error message is:
```
Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy
```

This is happening because:

1. **The JavaScript code is trying to fetch `/api/config`** (a relative URL) expecting it to go to a server
2. **The browser is interpreting the relative URL as `file:///`** instead of `http://localhost:3000`
3. **The page is being opened directly as a file** (e.g., `file:///C:/.../admin.html`) instead of through the server (e.g., `http://localhost:3000/admin.html`)

## Root Cause

The user is opening `admin.html` directly in the browser by double-clicking the file, rather than accessing it through the running Node.js server.

## Solution

The solution is simple - the user needs to:

1. **Start the server** by running `npm start` or `node server.js`
2. **Access the admin page through the server** at `http://localhost:3000/admin.html` (or `http://localhost:3000/admin`)

The server.js already has the correct API endpoints at `/api/config` and `/api/save-config` that work with CORS enabled.

Let me provide the complete solution to the user.

Now I have a complete understanding of the issue. Let me provide you with the analysis and solution:

## **Issue Analysis**

The CORS error occurs because:

1. **You're opening `admin.html` directly as a file** (e.g., `file:///C:/.../admin.html`) instead of through the server
2. **The browser treats the relative URL `/api/config`** as `file:///C:/api/config` when opening as a file
3. **The `file://` protocol doesn't support CORS** - it's only allowed for `http`, `https`, `chrome`, etc.

## **Solution**

You need to **run the server** and access the admin panel through it. Here's what to do:

**Step 1: Start the server**
```bash
cd "c:/Users/ACER/Desktop/EDC,LTD"
npm start
```

**Step 2: Open the admin page through the server**
- Go to: `http://localhost:3000/admin.html`
- OR: `http://localhost:3000/admin`

The server is already configured with:
- **CORS enabled** in `server.js` (line 12: `app.use(cors());`)
- **API endpoint** at `/api/config` that reads from `data/site-config.json`
- **Static file serving** from the project root

## **If you want to also fix the JavaScript error "Cannot read properties of null"**

This secondary error happens because `loadConfig()` returns `null` when the fetch fails, and then the code tries to access `this.config.site.name` without checking if `this.config` is null first.

Let me fix that too for a better user experience:


🔧 工具调用: edit_file

## 💬 User #9

_2026-03-12 06:37:03Z_

📋 工具结果: The content was successfully saved to c:/Users/ACER/Desktop/EDC,LTD/js/admin-editor.js.[Please review the changes carefully and make sure they are correct  You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build. Edit the file again if necessary.][Diff of the changes applied]
@@ -1,1042 +1,1045 @@
-/**
- * ============================================
- * ADMIN EDITOR - Visual Content E...

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

## 🤖 Assistant #10

_2026-03-12 06:37:03Z_

💭 思考过程：
The edit was applied successfully. The code now checks if the config is null before proceeding with rendering. Now let me provide the final solution summary to the user.

The fix has been applied. Now let me provide you with the complete solution:


🔧 工具调用: attempt_completion

## 💬 User #11

_2026-03-12 06:37:03Z_

📋 工具结果: Command executed.
Output:
At line:1 char:36
+ cd "c:/Users/ACER/Desktop/EDC,LTD" && npm start
+                                    ~~
The token '&&' is not a valid statement separator in this version.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : InvalidEndOfLine

The user has provided feedback on the results. Consider their input to continue the task, and then attempt completion again.
<feedback>
admin.html:1 Access to fetch ...

[attempt_completion] Result:

Command executed.
Output:
At line:1 char:36
+ cd "c:/Users/ACER/Desktop/EDC,LTD" && npm start
+                                    ~~
The token '&&' is not a valid statement separator in this version.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : InvalidEndOfLine

The user has provided feedback on the results. Consider their input to continue the task, and then attempt completion again.
<feedback>
admin.html:1 Access to fetch at 'file:///C:/api/config' from origin 'null' has been blocked by CORS policy: Cross origin requests are only supported for protocol schemes: chrome, chrome-extension, chrome-untrusted, data, http, https, isolated-app.
admin-editor.js:34 
 GET file:///C:/api/config net::ERR_FAILED
loadConfig	@	admin-editor.js:34
init	@	admin-editor.js:17
(anonymous)	@	admin.html:120
admin-editor.js:41 Error loading config: TypeError: Failed to fetch
    at Object.loadConfig (admin-editor.js:34:36)
    at Object.init (admin-editor.js:17:35)
    at HTMLDocument.<anonymous> (admin.html:120:25)
loadConfig	@	admin-editor.js:41
await in loadConfig		
init	@	admin-editor.js:17
(anonymous)	@	admin.html:120
</feedback>

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

## 🤖 Assistant #12

_2026-03-12 06:37:03Z_

💭 思考过程：
The user is still getting the same error. They're still opening the file directly instead of through the server. The PowerShell command I tried to run failed because of the `&&` syntax. Let me try a different approach - I'll run the command properly using Windows command syntax.

The server is not running yet. Let me start it for you:


🔧 工具调用: execute_command

## 💬 User #13

_2026-03-12 06:37:03Z_

📋 工具结果: Command executed.
Output:
At line:1 char:36
+ cd "c:/Users/ACER/Desktop/EDC,LTD" & node server.js
+                                    ~
The ampersand (&) character is not allowed. The & operator is reserved for future use; wrap an ampersand in double quotation marks ("&")
to pass it as part of a string.
    + CategoryInfo          : ParserError: (:) [], ParentContainsErrorRecordException
    + FullyQualifiedErrorId : AmpersandNotAllowed

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

## 🤖 Assistant #14

_2026-03-12 06:37:03Z_

💭 思考过程：
The issue is with the PowerShell command syntax on Windows. Let me try a different approach to run the server.

🔧 工具调用: execute_command

## 💬 User #15

_2026-03-12 06:37:03Z_

📋 工具结果: Command is still running in the user's terminal.
Here's the output so far:
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   EDC Website Server                                       ║
║   Running at: http://localhost:3000                       ║
║                                                            ║
║   Public Website: http://localhost:3000/index.html       ║
║   Admin Panel:    http://localhost:3000/admin.ht...

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #16

_2026-03-12 06:37:03Z_

💭 思考过程：
The server is now running. The user needs to access the admin panel through the server URL now. Let me provide the final completion result with instructions.

The server is now running. Let me complete the task:


🔧 工具调用: attempt_completion

## 💬 User #17

_2026-03-12 06:37:03Z_

📋 工具结果: The user has provided feedback on the results. Consider their input to continue the task, and then attempt completion again.
<feedback>
animations.js:1 Uncaught SyntaxError: Identifier 'styleSheet' has already been declared (at animations.js:1:1)Understand this error
logo.png:1  Failed to load resource: the server responded with a status of 404 (Not Found)Understand this error
images/favicon.png:1  Failed to load resource: the server responded with a status of 404 (Not Found)
</feedback>

[attempt_completion] Result:

The user has provided feedback on the results. Consider their input to continue the task, and then attempt completion again.
<feedback>
animations.js:1 Uncaught SyntaxError: Identifier 'styleSheet' has already been declared (at animations.js:1:1)Understand this error
logo.png:1  Failed to load resource: the server responded with a status of 404 (Not Found)Understand this error
images/favicon.png:1  Failed to load resource: the server responded with a status of 404 (Not Found)
</feedback>

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #18

_2026-03-12 06:37:03Z_

💭 思考过程：
The user has new errors now:
1. `animations.js:1 Uncaught SyntaxError: Identifier 'styleSheet' has already been declared`
2. `logo.png:1 Failed to load resource: 404 (Not Found)`
3. `images/favicon.png:1 Failed to load resource: 404 (Not Found)`

These are different issues now - the CORS error is fixed (since they're now getting 404 errors which means the server is responding). Let me check the animations.js file to fix the duplicate variable declaration.

The CORS issue is fixed! Now there are other issues to address. Let me fix the JavaScript syntax error in animations.js:


🔧 工具调用: read_file

## 💬 User #19

_2026-03-12 06:37:03Z_

📋 工具结果: /**
 * ============================================
 * ANIMATIONS - Scroll animations and effects
 * Customizable animation settings
 * ============================================
 */

document.addEventListener('DOMContentLoaded', function() {
    initScrollAnimations();
    initParallax();
    initHoverAnimations();
    initCounterAnimations();
    initImageEffects();
});

/**
 * Initialize scroll-triggered animations
 * Elements with class "animate-on-scroll" will fade in whe...

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #20

_2026-03-12 06:37:03Z_

💭 思考过程：
I can see the animations.js file. The issue is that the code at the end is trying to create a `styleSheet` variable but there's likely another script that's also creating a variable with the same name. Looking at the error message "Identifier 'styleSheet' has already been declared", it seems like there's a conflict.

Let me check the index.html to see what scripts are being loaded and if there are any other scripts that might be creating a styleSheet variable.

Let me check the index.html to see what scripts are loaded:


🔧 工具调用: read_file

## 💬 User #21

_2026-03-12 06:37:03Z_

📋 工具结果: <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="English Development Consultants Co. Ltd. - Education consulting and teacher recruitment in Thailand">
    <title>English Development Consultants Co. Ltd.</title>
    
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- Favicon - Replace with your own favicon -->
    <link rel="ic...

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #22

_2026-03-12 06:37:03Z_

💭 思考过程：
Let me check the load-site.js and navbar-loader.js to see if they also create a stylesheet, causing the duplicate identifier error.

Let me check the other JS files that might be creating stylesheets:


🔧 工具调用: read_file

## 💬 User #23

_2026-03-12 06:37:03Z_

📋 工具结果: /**
 * ============================================
 * LOAD SITE - Dynamic Site Loader
 * Loads content and settings from site-config.json
 * ============================================
 */

let siteConfig = null;

/**
 * Initialize the site by loading configuration
 */
async function initSite() {
    try {
        // Load site configuration
        await loadSiteConfig();
        
        // Apply theme settings
        applyTheme();
        
        // Load all sections
 ...

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #24

_2026-03-12 06:37:03Z_

💭 思考过程：
I don't see another `styleSheet` variable in load-site.js. Let me check the navbar-loader.js and popup.js files to see if any of them also create a stylesheet:

Let me check the other JS files:


🔧 工具调用: search_files

## 💬 User #25

_2026-03-12 06:37:03Z_

📋 工具结果: Found 6 results.

js/animations.js
│----
│const styleSheet = document.createElement('style');
│----
│styleSheet.textContent = revealStyles;
│----
│document.head.appendChild(styleSheet);
│
│// Inject styles
│----

js/popup.js
│----
│const styleSheet = document.createElement('style');
│----
│styleSheet.textContent = popupStyles;
│----
│document.head.appendChild(styleSheet);
│
│----

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #26

_2026-03-12 06:37:03Z_

💭 思考过程：
I see the issue now. Both `animations.js` and `popup.js` declare a variable named `styleSheet` with `const`. When both scripts are loaded, the second one will fail because `styleSheet` is already declared in the first script (they're in the same global scope).

The solution is to wrap these in an IIFE (Immediately Invoked Function Expression) to isolate the variable scope, or rename one of them.

Let me fix both files by wrapping them in IIFEs.

Found the issue! Both `animations.js` and `popup.js` declare a `const styleSheet` variable in the global scope, causing a conflict. Let me fix both files by wrapping them in IIFEs (Immediately Invoked Function Expressions) to isolate the variable scope:


🔧 工具调用: read_file

## 💬 User #27

_2026-03-12 06:37:03Z_

📋 工具结果: /**
 * ============================================
 * POPUP SYSTEM - Fullscreen Event Popup
 * Customizable popup with animations and persistence
 * ============================================
 */

const PopupSystem = {
    /**
     * Initialize popup system
     */
    init: function(config) {
        if (!config || !config.enabled) return;
        
        this.config = config;
        this.popupKey = 'edc_popup_dismissed';
        
        // Check if popup should be shown ...

Environment details:

# VSCode Visible Files
js/admin-editor.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #28

_2026-03-12 06:37:03Z_

💭 思考过程：
Now I understand the issue. Both `animations.js` and `popup.js` create a `const styleSheet` variable at the global level. When both scripts are loaded, the second one throws an error because `styleSheet` is already declared.

Let me fix both files by:
1. Renaming the variable in one or both files to avoid the conflict
2. Or wrapping them in an IIFE to scope them locally

The easiest fix is to rename the variable in one of them. Let me rename the one in `animations.js` to `animationStylesheet`.

Now I understand the issue. Both files declare `const styleSheet` in the global scope. Let me fix this by renaming the variable in `animations.js`:


🔧 工具调用: edit_file

## 💬 User #29

_2026-03-12 06:37:03Z_

📋 工具结果: The content was successfully saved to c:/Users/ACER/Desktop/EDC,LTD/js/animations.js.[Please review the changes carefully and make sure they are correct  You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build. Edit the file again if necessary.][Diff of the changes applied]
@@ -1,301 +1,300 @@
-/**
- * ============================================
- * ANIMATIONS - Scroll animations and ...

Environment details:

# VSCode Visible Files
js/animations.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js
js/animations.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #30

_2026-03-12 06:37:03Z_

💭 思考过程：
Good, I've fixed the animations.js file. Now let me also fix the popup.js file with the same issue.

Now let me fix the popup.js file with the same issue:


🔧 工具调用: edit_file

## 💬 User #31

_2026-03-12 06:37:03Z_

📋 工具结果: The content was successfully saved to c:/Users/ACER/Desktop/EDC,LTD/js/popup.js.[Please review the changes carefully and make sure they are correct  You should ignore if you have introduced any redundant indendation issues / redundant blank lines or formatting issues as long as it does not impact the logic/ build. Edit the file again if necessary.][Diff of the changes applied]
@@ -1,347 +1,346 @@
-/**
- * ============================================
- * POPUP SYSTEM - Fullscreen Event Popup
-...

Environment details:

# VSCode Visible Files
js/popup.js

# VSCode Open Tabs
admin.html
index.html
js/admin-editor.js
js/animations.js
js/popup.js

# Actively Running Terminals
## Original command: `node "c:/Users/ACER/Desktop/EDC,LTD/server.js"`

## 🤖 Assistant #32

_2026-03-12 06:37:03Z_

💭 思考过程：
I've fixed both files. Now let me provide the completion message. The server is already running, and I've fixed:
1. The JavaScript syntax error (duplicate `styleSheet` variable)
2. The code now should work properly

The remaining 404 errors for logo.png and favicon.png are because those image files don't exist in the images folder. The code has fallback handlers for these, so they shouldn't break the site.

All fixes have been applied. Let me complete the task:


🔧 工具调用: attempt_completion

