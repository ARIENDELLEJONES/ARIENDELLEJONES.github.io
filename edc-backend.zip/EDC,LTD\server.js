/**
 * ============================================
 * EDC WEBSITE BACKEND SERVER
 * Local server for handling admin operations
 * ============================================
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(__dirname));

// Ensure data and images directories exist
const dataDir = path.join(__dirname, 'data');
const imagesDir = path.join(__dirname, 'images');

if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

if (!fs.existsSync(imagesDir)) {
    fs.mkdirSync(imagesDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let dest = imagesDir;
        
        // Create subdirectories if needed
        if (file.fieldname === 'gallery') {
            dest = path.join(imagesDir, 'gallery');
            if (!fs.existsSync(dest)) {
                fs.mkdirSync(dest, { recursive: true });
            }
        } else if (file.fieldname === 'team') {
            dest = imagesDir;
        }
        
        cb(null, dest);
    },
    filename: function (req, file, cb) {
        // Generate unique filename
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        let filename = file.fieldname + '-' + uniqueSuffix + ext;
        
        // If team member, use team1, team2, etc.
        if (file.fieldname === 'team' && req.body.teamIndex !== undefined) {
            filename = 'team' + (parseInt(req.body.teamIndex) + 1) + ext;
        }
        
        cb(null, filename);
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: function (req, file, cb) {
        // Allow all common image types
        const allowedTypes = /jpeg|jpg|png|gif|webp|svg|bmp|tiff|ico|avif|heic|heif/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed!'));
        }
    }
});

// ============================================
// API ROUTES
// ============================================

// Get site configuration
app.get('/api/config', (req, res) => {
    const configPath = path.join(dataDir, 'site-config.json');
    
    fs.readFile(configPath, 'utf8', (err, data) => {
        if (err) {
            // If config doesn't exist, create default
            const defaultConfig = getDefaultConfig();
            fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
                if (err) {
                    return res.status(500).json({ error: 'Failed to create config' });
                }
                return res.json(defaultConfig);
            });
        } else {
            try {
                const config = JSON.parse(data);
                res.json(config);
            } catch (parseError) {
                res.status(500).json({ error: 'Invalid JSON in config file' });
            }
        }
    });
});

// Save site configuration
app.post('/api/save-config', (req, res) => {
    const configPath = path.join(dataDir, 'site-config.json');
    const config = req.body;
    
    // Add timestamp
    config.lastUpdated = new Date().toISOString();
    
    fs.writeFile(configPath, JSON.stringify(config, null, 2), (err) => {
        if (err) {
            console.error('Error saving config:', err);
            return res.status(500).json({ error: 'Failed to save configuration' });
        }
        
        console.log('Configuration saved successfully');
        res.json({ success: true, message: 'Configuration saved' });
    });
});

// Upload single image
app.post('/api/upload-image', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    res.json({ 
        success: true, 
        filename: req.file.filename,
        path: 'images/' + req.file.filename
    });
});

// Upload multiple images (gallery)
app.post('/api/upload-gallery', upload.array('images', 20), (req, res) => {
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
    }
    
    const filenames = req.files.map(file => ({
        filename: file.filename,
        path: 'images/gallery/' + file.filename
    }));
    
    res.json({ success: true, files: filenames });
});

// Upload team member photo
app.post('/api/upload-team', upload.single('photo'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const teamIndex = req.body.teamIndex || 0;
    const ext = path.extname(req.file.originalname);
    const newFilename = 'team' + (parseInt(teamIndex) + 1) + ext;
    
    // Rename file to team1.jpg, team2.jpg, etc.
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, newFilename);
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: newFilename,
            path: 'images/' + newFilename
        });
    });
});

// Upload hero image
app.post('/api/upload-hero', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Rename to hero.jpg
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, 'hero.jpg');
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: 'hero.jpg',
            path: 'images/hero.jpg'
        });
    });
});

// Upload intro image
app.post('/api/upload-intro', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Rename to intro.jpg
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, 'intro.jpg');
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: 'intro.jpg',
            path: 'images/intro.jpg'
        });
    });
});

// Upload popup image
app.post('/api/upload-popup', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Rename to popup.jpg
    const oldPath = req.file.path;
    const newPath = path.join(imagesDir, 'popup.jpg');
    
    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to rename file' });
        }
        
        res.json({ 
            success: true, 
            filename: 'popup.jpg',
            path: 'images/popup.jpg'
        });
    });
});

// List all images
app.get('/api/images', (req, res) => {
    const images = [];
    
    function walkDir(dir) {
        if (!fs.existsSync(dir)) return;
        
        const files = fs.readdirSync(dir);
        files.forEach(file => {
            const filePath = path.join(dir, file);
            const stat = fs.statSync(filePath);
            
            if (stat.isDirectory()) {
                walkDir(filePath);
            } else {
                const ext = path.extname(file).toLowerCase();
                if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.tiff', '.ico', '.avif', '.heic', '.heif'].includes(ext)) {
                    images.push({
                        name: file,
                        path: path.relative(__dirname, filePath).replace(/\\/g, '/'),
                        size: stat.size,
                        modified: stat.mtime
                    });
                }
            }
        });
    }
    
    walkDir(imagesDir);
    res.json(images);
});

// Delete image
app.delete('/api/images/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(imagesDir, filename);
    
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found' });
    }
    
    fs.unlink(filePath, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to delete file' });
        }
        res.json({ success: true, message: 'File deleted' });
    });
});

// Get file content (for GitHub publishing)
app.get('/api/file/:filename', (req, res) => {
    const filename = req.params.filename;
    let filePath;
    
    if (filename === 'index.html') {
        filePath = path.join(__dirname, 'index.html');
    } else if (filename === 'style.css') {
        filePath = path.join(__dirname, 'css', 'style.css');
    } else if (filename === 'site-config.json') {
        filePath = path.join(dataDir, 'site-config.json');
    } else {
        filePath = path.join(__dirname, filename);
    }
    
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found' });
    }
    
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to read file' });
        }
        res.send(data);
    });
});

// Save file content
app.post('/api/save-file', (req, res) => {
    const { filename, content } = req.body;
    
    if (!filename || content === undefined) {
        return res.status(400).json({ error: 'Missing filename or content' });
    }
    
    let filePath;
    
    if (filename === 'index.html') {
        filePath = path.join(__dirname, 'index.html');
    } else if (filename === 'style.css') {
        filePath = path.join(__dirname, 'css', 'style.css');
    } else if (filename === 'site-config.json') {
        filePath = path.join(dataDir, 'site-config.json');
    } else {
        filePath = path.join(__dirname, filename);
    }
    
    // Ensure directory exists
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFile(filePath, content, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to save file' });
        }
        res.json({ success: true, message: 'File saved' });
    });
});

// Reset configuration to default
app.post('/api/reset-config', (req, res) => {
    const configPath = path.join(dataDir, 'site-config.json');
    const defaultConfig = getDefaultConfig();
    
    fs.writeFile(configPath, JSON.stringify(defaultConfig, null, 2), (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to reset configuration' });
        }
        res.json({ success: true, message: 'Configuration reset to default' });
    });
});

// Serve admin.html
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Serve index.html (default)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Catch-all route for any other path - serve index.html
app.get('*', (req, res) => {
    const filePath = path.join(__dirname, req.path);
    
    // Check if file exists
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        return res.sendFile(filePath);
    }
    
    // Otherwise serve index.html for SPA-like behavior
    res.sendFile(path.join(__dirname, 'index.html'));
});

// ============================================
// DEFAULT CONFIGURATION
// ============================================

function getDefaultConfig() {
    return {
        site: {
            name: "English Development Consultants Co. Ltd.",
            description: "Education consulting and teacher recruitment in Thailand",
            logo: "images/logo.png",
            favicon: "images/favicon.png"
        },
        navigation: {
            enabled: true,
            logo: {
                text: "EDC",
                link: "index.html"
            },
            menu: [
                { text: "Home", link: "#home", order: 1 },
                { text: "Introduction", link: "#introduction", order: 2 },
                { text: "Company Overview", link: "#overview", order: 3 },
                { text: "Services", link: "#services", order: 4 },
                { text: "Clients", link: "#clients", order: 5 },
                { text: "Team", link: "#team", order: 6 },
                { text: "Gallery", link: "#gallery", order: 7 },
                { text: "Contact", link: "#contact", order: 8 }
            ],
            applyButton: {
                text: "Apply Now",
                link: "http://54.252.186.9",
                enabled: true
            },
            style: {
                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                fontSize: "16px",
                textColor: "#1a202c",
                backgroundColor: "#ffffff",
                hoverColor: "#38a169",
                mobileStyle: "hamburger"
            }
        },
        hero: {
            enabled: true,
            title: "English Development Consultants Co. Ltd.",
            tagline: "Be Part of Our Team",
            buttonText: "Apply Now",
            buttonLink: "http://54.252.186.9",
            backgroundImage: "images/hero.jpg",
            overlayColor: "rgba(26, 54, 93, 0.85)",
            textColor: "#ffffff"
        },
        introduction: {
            enabled: true,
            title: "Welcome to EDC",
            content: [
                "English Development Consultants Co. Ltd. (EDC) is a leading education consulting and teacher recruitment company operating in Thailand.",
                "With years of experience in the education sector, we understand the importance of quality English language education.",
                "Partner with us to transform English language education in Thailand."
            ],
            image: "images/intro.jpg",
            imageAlt: "EDC Office"
        },
        overview: {
            enabled: true,
            title: "Company Overview",
            subtitle: "Our core values drive everything we do",
            mission: {
                title: "Our Mission",
                icon: "🎯",
                content: "To provide exceptional education consulting services and recruit highly qualified English language teachers."
            },
            vision: {
                title: "Our Vision",
                icon: "👁️",
                content: "To become the most trusted education consulting company in Thailand and Southeast Asia."
            }
        },
        services: {
            enabled: true,
            title: "Our Services",
            subtitle: "Comprehensive solutions for all your education needs",
            items: [
                { title: "Teacher Recruitment", icon: "👨‍🏫", content: "We specialize in recruiting qualified English teachers from around the world." },
                { title: "Training Programs", icon: "📚", content: "We offer comprehensive training programs for teachers." },
                { title: "Educational Consulting", icon: "💼", content: "Our expert consultants provide guidance on curriculum development." },
                { title: "Curriculum Support", icon: "📋", content: "We assist educational institutions in developing English language curricula." }
            ]
        },
        clients: {
            enabled: true,
            title: "Our Clients",
            subtitle: "Trusted by leading educational institutions",
            items: [
                { name: "School 1", logo: "" },
                { name: "School 2", logo: "" },
                { name: "School 3", logo: "" },
                { name: "School 4", logo: "" }
            ]
        },
        team: {
            enabled: true,
            title: "Our Team",
            subtitle: "Meet the dedicated professionals behind EDC",
            members: [
                { name: "John Smith", position: "Managing Director", image: "images/team1.jpg" },
                { name: "Sarah Johnson", position: "Head of Recruitment", image: "images/team2.jpg" },
                { name: "Michael Chen", position: "Training Coordinator", image: "images/team3.jpg" },
                { name: "Emily Davis", position: "Consultant", image: "images/team4.jpg" }
            ]
        },
        gallery: {
            enabled: true,
            title: "Gallery",
            subtitle: "Highlights from our programs and activities",
            images: [
                { src: "images/gallery/1.jpg", alt: "Gallery Image 1" },
                { src: "images/gallery/2.jpg", alt: "Gallery Image 2" },
                { src: "images/gallery/3.jpg", alt: "Gallery Image 3" },
                { src: "images/gallery/4.jpg", alt: "Gallery Image 4" },
                { src: "images/gallery/5.jpg", alt: "Gallery Image 5" },
                { src: "images/gallery/6.jpg", alt: "Gallery Image 6" },
                { src: "images/gallery/7.jpg", alt: "Gallery Image 7" },
                { src: "images/gallery/8.jpg", alt: "Gallery Image 8" }
            ]
        },
        contact: {
            enabled: true,
            title: "Contact Us",
            subtitle: "Get in touch with us for inquiries",
            company: "English Development Consultants Co. Ltd.",
            phone: "+66 2 123 4567",
            email: "info@edc-thailand.com",
            address: "Bangkok, Thailand",
            form: { enabled: true, emailTo: "info@edc-thailand.com" }
        },
        footer: {
            enabled: true,
            about: {
                title: "About EDC",
                content: "English Development Consultants Co. Ltd. is a leading education consulting and teacher recruitment company in Thailand."
            },
            quickLinks: [
                { text: "Home", link: "#home" },
                { text: "Services", link: "#services" },
                { text: "Contact", link: "#contact" }
            ],
            services: [
                { text: "Teacher Recruitment", link: "#services" },
                { text: "Training Programs", link: "#services" }
            ],
            social: { facebook: "#", twitter: "#", linkedin: "#", instagram: "#" },
            copyright: "© 2024 English Development Consultants Co. Ltd. All rights reserved."
        },
        popup: {
            enabled: false,
            title: "Welcome to EDC!",
            description: "Join our team of dedicated educators and make a difference in English language education in Thailand.",
            image: "images/popup.jpg",
            buttonText: "Learn More",
            buttonLink: "#introduction",
            backgroundColor: "rgba(26, 54, 93, 0.95)",
            textColor: "#ffffff",
            buttonColor: "#38a169",
            showAgainDuration: 1
        },
        theme: {
            colors: {
                primary: "#1a365d",
                primaryLight: "#2c5282",
                primaryDark: "#0d1b2a",
                secondary: "#38a169",
                secondaryLight: "#48bb78",
                secondaryDark: "#276749",
                backgroundLight: "#f7fafc",
                backgroundWhite: "#ffffff",
                textDark: "#1a202c",
                textGray: "#4a5568",
                textLight: "#718096",
                borderColor: "#e2e8f0"
            },
            fonts: {
                primary: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                headings: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
            },
            buttons: {
                primary: "#1a365d",
                secondary: "#38a169",
                hover: "#2c5282"
            }
        },
        github: {
            repoUrl: "",
            username: "",
            token: "",
            branch: "main"
        },
        lastUpdated: new Date().toISOString()
    };
}

// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   EDC Website Server                                       ║
║   Running at: http://localhost:${PORT}                       ║
║                                                            ║
║   Public Website: http://localhost:${PORT}/index.html       ║
║   Admin Panel:    http://localhost:${PORT}/admin.html       ║
║                                                            ║
║   Press Ctrl+C to stop the server                          ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
    `);
});

