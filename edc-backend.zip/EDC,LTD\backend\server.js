const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs-extra');

const configRoutes = require('./routes/config');
const uploadRoutes = require('./routes/upload');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors({ origin: '*' })); // Allow admin.html local
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static frontend files from parent dir
app.use(express.static(path.join(__dirname, '..')));

// Ensure uploads dir exists
const uploadsDir = path.join(__dirname, '..', 'images', 'uploads');
fs.ensureDirSync(uploadsDir);

// API Routes
app.use('/api/config', configRoutes);
app.use('/api/upload', uploadRoutes);

// Catch-all for SPA (serve index.html)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Error handler
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`EDC,LTD Backend running on http://localhost:${PORT}`);
  console.log(`Config API: http://localhost:${PORT}/api/config`);
  console.log(`Upload API: http://localhost:${PORT}/api/upload`);
  console.log(`Frontend: http://localhost:${PORT}`);
});
